%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% put the location of the downloaded "RBM thermometry repository" here:
path='C:\Users\Aspect\Dropbox\RBM thermometry repository\';


Figure5_HOT_nu_vs_T_summary
Figure5_PRESS_nu_vs_T_summary

marker_size=7;
frame_size=[4 4];
fs=17;
%PRESS
figure
errorbar(T_234,v_diff_fit_234,v_diff_fit_234_std,'ro','LineWidth',2,'MarkerSize',marker_size);
hold on
errorbar(T_236,v_diff_fit_236,v_diff_fit_236_std,'k*','LineWidth',2,'MarkerSize',marker_size);
errorbar(T_242,v_diff_fit_242_3c,v_diff_fit_242_3c_std,'ms','MarkerSize',marker_size);
errorbar(T_242,v_diff_fit_242_4d,v_diff_fit_242_4d_std,'md','MarkerSize',marker_size);
errorbar(T_243,v_diff_fit_243_3c,v_diff_fit_243_3c_std,'g<','MarkerSize',marker_size);
errorbar(T_243,v_diff_fit_243_4d,v_diff_fit_243_4d_std,'g>','MarkerSize',marker_size);
errorbar(T_244,v_diff_fit_244_3c,v_diff_fit_244_3c_std,'c<','MarkerSize',marker_size);
errorbar(T_244,v_diff_fit_244_4d,v_diff_fit_244_4d_std,'c>','MarkerSize',marker_size);

plot(fit_range_234,feval(cfun_PRESS_234,fit_range_234),'r','LineWidth',2);
plot(fit_range_236,feval(cfun_PRESS_236,fit_range_236),'k','LineWidth',2);
plot(fit_range_242,feval(cfun_PRESS_242_3c,fit_range_242),'m','LineWidth',2);
plot(fit_range_242,feval(cfun_PRESS_242_4d,fit_range_242),'m','LineWidth',2);
plot(fit_range_243,feval(cfun_PRESS_243_3c,fit_range_243),'g','LineWidth',2);
plot(fit_range_243,feval(cfun_PRESS_243_4d,fit_range_243),'g','LineWidth',2);
plot(fit_range_244,feval(cfun_PRESS_244_3c,fit_range_244),'c','LineWidth',2);
plot(fit_range_244,feval(cfun_PRESS_244_4d,fit_range_244),'c','LineWidth',2);
xlim([34 50]);
ylim([890 1240]);
set(gca,'FontSize',fs);
ylabel('\Delta\nu (Hz)','FontSize',fs);
xlabel('Temperature (\circC)','FontSize',fs);
title({'Localized Spectroscopy (PRESS)'},'FontSize',fs);
axis square

%HOT
figure
errorbar(lux_T_233,v_ave_233,v_std_233,'bx','MarkerSize',15,'LineWidth',2);
hold on
errorbar(lux_T_234,v_ave_234,v_std_234,'ro','LineWidth',2,'MarkerSize',marker_size);
errorbar(lux_T_236,v_ave_236,v_std_236,'k*','LineWidth',2,'MarkerSize',marker_size);
errorbar(lux_T_242_3c,v_ave_242_3c,v_std_242_3c,'ms','MarkerSize',marker_size);
errorbar(lux_T_242_4d,v_ave_242_4d,v_std_242_4d,'md','MarkerSize',marker_size);
errorbar(lux_T_243_3c,v_ave_243_3c,v_std_243_3c,'g<','MarkerSize',marker_size);
errorbar(lux_T_243_4d,v_ave_243_4d,v_std_243_4d,'g>','MarkerSize',marker_size);
errorbar(lux_T_244_3c,v_ave_244_3c,v_std_244_3c,'c<','MarkerSize',marker_size);
errorbar(lux_T_244_4d,v_ave_244_4d,v_std_244_4d,'c>','MarkerSize',marker_size);

plot(fit_range_233,feval(cfun_HOT_233,fit_range_233),'b','LineWidth',2);
plot(fit_range_234,feval(cfun_HOT_234,fit_range_234),'r','LineWidth',2);
plot(fit_range_236,feval(cfun_HOT_236,fit_range_236),'k','LineWidth',2);
plot(fit_range_242,feval(cfun_HOT_242_3c,fit_range_242),'m','LineWidth',2);
plot(fit_range_242,feval(cfun_HOT_242_4d,fit_range_242),'m','LineWidth',2);
plot(fit_range_243,feval(cfun_HOT_243_3c,fit_range_243),'g','LineWidth',2);
plot(fit_range_243,feval(cfun_HOT_243_4d,fit_range_243),'g','LineWidth',2);
plot(fit_range_244,feval(cfun_HOT_244_3c,fit_range_244),'c','LineWidth',2);
plot(fit_range_244,feval(cfun_HOT_244_4d,fit_range_244),'c','LineWidth',2);
xlim([34 50]);
ylim([950 1050]);
set(gca,'FontSize',fs);
% ylabel('\omega_0_,_w-\omega_0_,_f (Hz)');
% h_l=legend('sample 1','sample 2','sample 3','sample 4, voxel a','sample 4, voxel b','sample 5, voxel a','sample 5, voxel b','sample 6, voxel a','sample 6, voxel b');
% set(h_l,'FontSize',15);
% ylabel('\nu_0_,_w-\nu_0_,_f (Hz)','FontSize',20);
ylabel('\Delta\nu (Hz)','FontSize',fs);
xlabel('Temperature (\circC)','FontSize',fs);
title('iZQC','FontSize',fs);
axis square

f_l=figure
errorbar(0,0,0,'bx','MarkerSize',15,'LineWidth',2);
hold on
errorbar(0,0,0,'ro','LineWidth',2,'MarkerSize',marker_size);
errorbar(0,0,0,'k*','LineWidth',2,'MarkerSize',marker_size);
errorbar(0,0,0,'ms','MarkerSize',marker_size);
errorbar(0,0,0,'md','MarkerSize',marker_size);
errorbar(0,0,0,'g<','MarkerSize',marker_size);
errorbar(0,0,0,'g>','MarkerSize',marker_size);
errorbar(0,0,0,'c<','MarkerSize',marker_size);
errorbar(0,0,0,'c>','MarkerSize',marker_size);
h_l=legend('sample 1','sample 2','sample 3','sample 4, voxel a','sample 4, voxel b','sample 5, voxel a','sample 5, voxel b','sample 6, voxel a','sample 6, voxel b');
set(gca,'FontSize',fs-6);
axis off

%box plot
% subplot(1,3,3);
figure
m=[m_press;m_hot]';
boxplot(m,{'PRESS','HOT'},'widths',0.5,'whisker',3,'color','k');
set(gca,'FontSize',18);
hold on
scatter(ones(size(m_press)),m_press,'kx','SizeData',100);
scatter(2*ones(size(m_hot)),m_hot,'kx','SizeData',100);
ylabel('\alpha (Hz/\circC)');
std_press=std(m_press(1:end-2))/mean(m_press(1:end-2));
std_hot=std(m_hot)/mean(m_hot); 

% %Show the PRESS maxima data
% figure
% scatter(T_234,-v_diff_max_234,'ro','LineWidth',2,'SizeData',marker_size);
% hold on
% scatter(T_236,-v_diff_max_236,'k*','LineWidth',2,'SizeData',marker_size);
% scatter(T_242,-v_diff_max_242_3c,'ms','SizeData',marker_size);
% scatter(T_242,-v_diff_max_242_4d,'md','SizeData',marker_size);
% scatter(T_243,-v_diff_max_243_3c,'g<','SizeData',marker_size);
% scatter(T_243,-v_diff_max_243_4d,'g>','SizeData',marker_size);
% scatter(T_244,-v_diff_max_244_3c,'c<','SizeData',marker_size);
% scatter(T_244,-v_diff_max_244_4d,'c>','SizeData',marker_size);
% 
% plot(fit_range_234,-feval(cfun_PRESS_max_234,fit_range_234),'r','LineWidth',2);
% plot(fit_range_236,-feval(cfun_PRESS_max_236,fit_range_236),'k','LineWidth',2);
% plot(fit_range_242,-feval(cfun_PRESS_max_242_3c,fit_range_242),'m','LineWidth',2);
% plot(fit_range_242,-feval(cfun_PRESS_max_242_4d,fit_range_242),'m','LineWidth',2);
% plot(fit_range_243,-feval(cfun_PRESS_max_243_3c,fit_range_243),'g','LineWidth',2);
% plot(fit_range_243,-feval(cfun_PRESS_max_243_4d,fit_range_243),'g','LineWidth',2);
% plot(fit_range_244,-feval(cfun_PRESS_max_244_3c,fit_range_244),'c','LineWidth',2);
% plot(fit_range_244,-feval(cfun_PRESS_max_244_4d,fit_range_244),'c','LineWidth',2);
% 
% title('\Delta\nu from maxima in PRESS spectra','FontSize',19);