%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


getDirScanInfo('RMD243',[9 13 16 19 22 25]); %need to add Sc43 back in, right now it doesn't recon properly

%load marrow rois
R_marrow=Rois();
R_marrow.loadRois(strcat(path,'ROIs\Figure 5\RMD243 marrow region.roi'));
m_marrow=squeeze(R_marrow.getMasks());

%define parameters for probe ROI
fov=[35 35];
voxel_size=fov(1)/size(RMD243_Sc13_HOT_SLI,5); %in mm/voxel
roi_thickness=1.5;%mm
roi_id=1;%mm
r_inc=round(roi_thickness/voxel_size); %2mm roi thickness 
r_init=round(roi_id/voxel_size); %1.5mm id of roi
r_max=round((2*roi_thickness+roi_id)/voxel_size);
im_size=[128 128];
probe_location=[61 53];

%generate probe ROI
[masks_return,ir_return] = makeRadialMasksC(probe_location(1),probe_location(2),r_inc,r_max,im_size,r_init,m_marrow);
for mask_num=1:size(masks_return,1)
    masks_return(mask_num,:,:)=masks_return(mask_num,:,:).*reshape(m_marrow,1,128,128);
end
R_probe=Rois(masks_return,'input_type','masks');
m_probe=squeeze(R_probe.getMasks());
m_probe=m_probe.*m_marrow;

%generate anatomical image
rare=abs(squeeze(RMD243_Sc9_rare(2,:,:)));
rare=rare/max(max(rare));

%Tair = 36
t36=zeros(1,8);
for ii=1:8
    t36(ii)=sum(sum(squeeze(RMD243_Sc13_HOT_SLI_t(ii,1,1,:,:)).*m_probe))/sum(sum(m_probe));
end

%Tair = 39
t39=zeros(1,8);
for ii=1:8
    t39(ii)=sum(sum(squeeze(RMD243_Sc16_HOT_SLI_t(ii,1,1,:,:)).*m_probe))/sum(sum(m_probe));
end

%Tair = 42
t42=zeros(1,8);
for ii=1:8
    t42(ii)=sum(sum(squeeze(RMD243_Sc19_HOT_SLI_t(ii,1,1,:,:)).*m_probe))/sum(sum(m_probe));
end

%Tair = 45
t45=zeros(1,8);
for ii=1:8
    t45(ii)=sum(sum(squeeze(RMD243_Sc22_HOT_SLI_t(ii,1,1,:,:)).*m_probe))/sum(sum(m_probe));
end

%Tair = 48
t48=zeros(1,8);
for ii=1:8
    t48(ii)=sum(sum(squeeze(RMD243_Sc25_HOT_SLI_t(ii,1,1,:,:)).*m_probe))/sum(sum(m_probe));
end

figure
subplot(1,2,1);
imagesc(squeeze(abs(RMD243_Sc13_HOT_SLI(1,1,1,:,:))));
axis image off
colormap gray
R_probe.outlineRois('linewidth',2,'color','r');
subplot(1,2,2);
imagesc(squeeze(abs(RMD243_Sc13_HOT_SLI(1,1,2,:,:))));
axis image off
colormap gray
R_probe.outlineRois('linewidth',2,'color','r');
set(gcf,'Name','sample5b: ZQSQ-HOT');

%compute v vs T curve:
v_ave_243_4d=[mean(t36) mean(t39) mean(t42) mean(t45) mean(t48)];
v_std_243_4d=[std(t36) std(t39) std(t42) std(t45) std(t48)];
lux_T_243_4d=[35.6 38.6 41.4 44.3 46.9];
f=fittype('m*x+b');
[cfun_243_4d,gof]=fit(lux_T_243_4d',v_ave_243_4d',f);

figure,errorbar(lux_T_243_4d,v_ave_243_4d,v_std_243_4d,'bx','MarkerSize',15);
hold on
plot(cfun_243_4d);
set(gca,'FontSize',15);
xlabel('temperature (\circC)','FontSize',15);
ylabel('iZQC frequency (Hz)','FontSize',15);
set(gcf,'Name','sample5b: ZQSQ-HOT');