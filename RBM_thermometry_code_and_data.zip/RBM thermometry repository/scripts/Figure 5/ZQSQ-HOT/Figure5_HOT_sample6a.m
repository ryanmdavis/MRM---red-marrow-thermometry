%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


getDirScanInfo('RMD244',[4 9 13 16 19 22]); %need to add Sc43 back in, right now it doesn't recon properly

%load marrow rois
R_marrow=Rois();
R_marrow.loadRois(strcat(path,'ROIs\Figure 5\RMD244 marrow region.roi'));
m_marrow=squeeze(R_marrow.getMasks());

%plot ranges
y_lim=[20 120];
x_lim=[22 122];

%define parameters for probe ROI
fov=[35 35];
voxel_size=fov(1)/size(RMD244_Sc9_HOT_SLI,5); %in mm/voxel
roi_thickness=1.5;%mm
roi_id=1;%mm
r_inc=round(roi_thickness/voxel_size); %2mm roi thickness 
r_init=round(roi_id/voxel_size); %1.5mm id of roi
r_max=round((2*roi_thickness+roi_id)/voxel_size);
im_size=[128 128];
probe_location=[79 73];

%generate probe ROI
[masks_return,ir_return] = makeRadialMasksC(probe_location(1),probe_location(2),r_inc,r_max,im_size,r_init,m_marrow);
for mask_num=1:size(masks_return,1)
    masks_return(mask_num,:,:)=masks_return(mask_num,:,:).*reshape(m_marrow,1,128,128);
end
R_probe=Rois(masks_return,'input_type','masks');
m_probe=squeeze(R_probe.getMasks());
m_probe=m_probe.*m_marrow;

%generate anatomical image
rare=abs(squeeze(RMD244_Sc4_rare(2,:,:)));
rare=rare/max(max(rare));
figure,imagesc(rare)
axis square off
R_probe.outlineRois('color','w','linewidth',2);
colormap gray
ylim(y_lim);
xlim(x_lim);
set(gcf,'Name','sample6a: ZQSQ-HOT')

%Tair = 36
t36=zeros(1,8);
for ii=1:8
    t36(ii)=sum(sum(squeeze(RMD244_Sc9_HOT_SLI_t(ii,1,1,:,:)).*m_probe))/sum(sum(m_probe));
end

%Tair = 39
t39=zeros(1,8);
for ii=1:8
    t39(ii)=sum(sum(squeeze(RMD244_Sc13_HOT_SLI_t(ii,1,1,:,:)).*m_probe))/sum(sum(m_probe));
end

%Tair = 42
t42=zeros(1,8);
for ii=1:8
    t42(ii)=sum(sum(squeeze(RMD244_Sc16_HOT_SLI_t(ii,1,1,:,:)).*m_probe))/sum(sum(m_probe));
end

%Tair = 45
t45=zeros(1,8);
for ii=1:8
    t45(ii)=sum(sum(squeeze(RMD244_Sc19_HOT_SLI_t(ii,1,1,:,:)).*m_probe))/sum(sum(m_probe));
end

%Tair = 48
t48=zeros(1,8);
for ii=1:8
    t48(ii)=sum(sum(squeeze(RMD244_Sc22_HOT_SLI_t(ii,1,1,:,:)).*m_probe))/sum(sum(m_probe));
end

figure
subplot(1,2,1);
imagesc(squeeze(abs(RMD244_Sc9_HOT_SLI(1,1,1,:,:))));
axis square off
colormap gray
R_probe.outlineRois('linewidth',2,'color','r');
subplot(1,2,2);
imagesc(squeeze(abs(RMD244_Sc9_HOT_SLI(1,1,2,:,:))));
axis square off
colormap gray
R_probe.outlineRois('linewidth',2,'color','r');
set(gcf,'Name','sample6a: ZQSQ-HOT');

%compute v vs T curve:
v_ave_244_3c=[mean(t36) mean(t39) mean(t42) mean(t45) mean(t48)];
v_std_244_3c=[std(t36) std(t39) std(t42) std(t45) std(t48)];
lux_T_244_3c=[37.0 39.7 42.5 45.2 48.0];
f=fittype('m*x+b');
[cfun_244_3c,gof]=fit(lux_T_244_3c',v_ave_244_3c',f);

figure,errorbar(lux_T_244_3c,v_ave_244_3c,v_std_244_3c,'kx','MarkerSize',15,'LineWidth',2);
hold on
plot(36:49,feval(cfun_244_3c,36:49),'r','LineWidth',2);
set(gca,'FontSize',15);
xlabel('T_l_u_x (\circC)','FontSize',19);
ylabel('iZQC frequency (Hz)','FontSize',19);
set(gca,'FontSize',19);
xlim([35 50]);
ylim([970 1010]);
axis square
set(gcf,'Name','sample6a: ZQSQ-HOT')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% display frequency overlays
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
t37=squeeze(mean(RMD244_Sc9_HOT_SLI_t(:,1,1,:,:),1));
t40=squeeze(mean(RMD244_Sc13_HOT_SLI_t(:,1,1,:,:),1));
t43=squeeze(mean(RMD244_Sc16_HOT_SLI_t(:,1,1,:,:),1));
t46=squeeze(mean(RMD244_Sc19_HOT_SLI_t(:,1,1,:,:),1));
t49=squeeze(mean(RMD244_Sc22_HOT_SLI_t(:,1,1,:,:),1));

frequency_range=[960 1020];
rare_rgb=intensity2RGB(rare,gray,[0 0.8]);
%t37
t37_rgb=intensity2RGB(t37,jet,frequency_range);
t37_overlay=superpose2RGB(t37_rgb,rare_rgb,m_marrow);
%t40
t40_rgb=intensity2RGB(t40,jet,frequency_range);
t40_overlay=superpose2RGB(t40_rgb,rare_rgb,m_marrow);
%t43
t43_rgb=intensity2RGB(t43,jet,frequency_range);
t43_overlay=superpose2RGB(t43_rgb,rare_rgb,m_marrow);
%t46
t46_rgb=intensity2RGB(t46,jet,frequency_range);
t46_overlay=superpose2RGB(t46_rgb,rare_rgb,m_marrow);
%t49
t49_rgb=intensity2RGB(t49,jet,frequency_range);
t49_overlay=superpose2RGB(t49_rgb,rare_rgb,m_marrow);

roi_color='w';
lw=2;
fs=18;
figure
subplot(2,3,1);
imagesc(t37_overlay);
title(strcat('T_l_u_x=',num2str(lux_T_244_3c(1),'%2.1f'),'\circC'),'FontSize',fs);
axis square off
R_probe.outlineRois('color',roi_color,'linewidth',lw);
ylim(y_lim);
xlim(x_lim);

subplot(2,3,2);
imagesc(t40_overlay);
title(strcat('T_l_u_x=',num2str(lux_T_244_3c(2)),'\circC'),'FontSize',fs);
axis square off
R_probe.outlineRois('color',roi_color,'linewidth',lw);
ylim(y_lim);
xlim(x_lim);    

subplot(2,3,3);
imagesc(t43_overlay);
title(strcat('T_l_u_x=',num2str(lux_T_244_3c(3)),'\circC'),'FontSize',fs);
axis square off
R_probe.outlineRois('color',roi_color,'linewidth',lw);
ylim(y_lim);
xlim(x_lim);

subplot(2,3,4);
imagesc(t46_overlay);
title(strcat('T_l_u_x=',num2str(lux_T_244_3c(4)),'\circC'),'FontSize',fs);
axis square off
R_probe.outlineRois('color',roi_color,'linewidth',lw);
ylim(y_lim);
xlim(x_lim);

subplot(2,3,5);
imagesc(t49_overlay);
title(strcat('T_l_u_x=',num2str(lux_T_244_3c(5),'%2.1f'),'\circC'),'FontSize',fs);
axis square off
R_probe.outlineRois('color',roi_color,'linewidth',lw);
ylim(y_lim);
xlim(x_lim);
set(gcf,'Name','sample6a: ZQSQ-HOT')

subplot(2,3,6);
imagesc(ones(64),frequency_range);
colorbar
title('colorbar units: Hz','FontSize',15);
axis square

%make temperature image
path_cell=loadDataPath;
load(strcat(path_cell{1},'\hot calibration curves'),'T_of_nu');T37=T_of_nu(t37,7);
T_37_rgb=intensity2RGB(T37,hot,[32 42]);
T_37_overlay=superpose2RGB(T_37_rgb,rare_rgb,m_marrow);
figure,imagesc(T_37_overlay,[32 42]);
axis image off
xlim(x_lim);
ylim(y_lim);
colorbar
colormap hot
set(gca,'FontSize',19);
set(gcf,'Name','sample6a: ZQSQ-HOT')
title('colorbar units: \circC','FontSize',18);
