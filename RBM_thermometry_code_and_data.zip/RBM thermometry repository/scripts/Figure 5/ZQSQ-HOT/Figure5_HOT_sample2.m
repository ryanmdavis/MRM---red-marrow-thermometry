%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


getDirScanInfo('RMD234',[4 5 9 12 14 16 18 20 22]);

%load marrow ROIs
R_marrow=Rois();
R_marrow.loadRois(strcat(path,'ROIs\Figure 5\RMD234 marrow region.roi'));
m_marrow=squeeze(R_marrow.getMasks());

%define parameters for probe ROI
fov=[35 35];
voxel_size=fov(1)/size(RMD233_Sc10_HOT_SLI_t,5); %in mm/voxel
roi_thickness=1.5;%mm
roi_id=1;%mm
r_inc=round(roi_thickness/voxel_size); %2mm roi thickness 
r_init=round(roi_id/voxel_size); %1.5mm id of roi
r_max=round((2*roi_thickness+roi_id)/voxel_size);
im_size=[size(RMD233_Sc10_HOT_SLI_t,4) size(RMD233_Sc10_HOT_SLI_t,5)];
probe_location=[80 73];

%generate probe ROI
[masks_return,ir_return] = makeRadialMasksC(probe_location(1),probe_location(2),r_inc,r_max,im_size,r_init,m_marrow);
for mask_num=1:size(masks_return,1)
    masks_return(mask_num,:,:)=masks_return(mask_num,:,:).*reshape(m_marrow,1,128,128);
end
R_probe=Rois(masks_return,'input_type','masks');
m_probe=squeeze(R_probe.getMasks());
m_probe=m_probe.*m_marrow;



%anatomical image
rare=abs(RMD234_Sc5_rare);
rare=rare/max(max(rare));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Display anatomical images
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure,subplot(2,1,1);
imagesc(RMD234_Sc4_rare);
axis image off
%plot lins on row 46 to row 77
line([46 46],[1 128],'LineWidth',2,'color','r');
line([77 77],[1 128],'LineWidth',2,'color','r');
title('Coronal T_2-weighted image','FontSize',15);

subplot(2,1,2);
imagesc(RMD234_Sc5_rare);
axis image off
R_probe.outlineRois('linewidth',2,'color','r');
colormap gray
title('Axial T_2-weighted image','FontSize',15);
set(gcf,'Name','sample 2: ZQSQ-HOT')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate average ROI temperatures
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%37C
t37=zeros(1,8);
for ii=1:8
    t37(ii)=sum(sum(squeeze(RMD234_Sc9_HOT_SLI_t(ii,1,1,:,:)).*m_probe))/sum(sum(m_probe));
end

%39C
t39=zeros(1,8);
for ii=1:8
    t39(ii)=sum(sum(squeeze(RMD234_Sc12_HOT_SLI_t(ii,1,1,:,:)).*m_probe))/sum(sum(m_probe));
end

%41C
t41=zeros(1,8);
for ii=1:8
    t41(ii)=sum(sum(squeeze(RMD234_Sc14_HOT_SLI_t(ii,1,1,:,:)).*m_probe))/sum(sum(m_probe));
end

%43C
t43=zeros(1,8);
for ii=1:8
    t43(ii)=sum(sum(squeeze(RMD234_Sc16_HOT_SLI_t(ii,1,1,:,:)).*m_probe))/sum(sum(m_probe));
end

%45C
t45=zeros(1,8);
for ii=1:8
    t45(ii)=sum(sum(squeeze(RMD234_Sc18_HOT_SLI_t(ii,1,1,:,:)).*m_probe))/sum(sum(m_probe));
end

%47C
t47=zeros(1,8);
for ii=1:8
    t47(ii)=sum(sum(squeeze(RMD234_Sc20_HOT_SLI_t(ii,1,1,:,:)).*m_probe))/sum(sum(m_probe));
end

%49C
t49=zeros(1,8);
for ii=1:8
    t49(ii)=sum(sum(squeeze(RMD234_Sc22_HOT_SLI_t(ii,1,1,:,:)).*m_probe))/sum(sum(m_probe));
end

lux_T_234=[mean([36.3 36.6 36.6 36.6]) mean([38.5 38.5 38.8 38.8 38.8 38.9]) mean([41.2 41.2 41.3 41.3 41.3]) mean([43.1 43.3 43.2 43.3]) mean([45.5 45.6 45.7 45.8]) mean([47.7 48.0 48.1 48.1]) mean([50.4 50.5 50.5])];
v_ave_234=[mean(t37) mean(t39) mean(t41) mean(t43) mean(t45) mean(t47) mean(t49)];
v_std_234=[std(t37) std(t39) std(t41) std(t43) std(t45) std(t47) std(t49)];
figure,errorbar(lux_T_234,v_ave_234,v_std_234,'bx','MarkerSize',14,'LineWidth',2)
set(gcf,'Name','sample 2: ZQSQ-HOT')

ft=fittype('m*x+b');
[cfun,gof]=fit(lux_T_234',v_ave_234',ft);
hold on
plot(cfun)
set(gca,'FontSize',18);
legend('data','linear fit');
xlabel('T_l_u_x (\circC)');
ylabel('iZQC frequency (Hz)');
axis square

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate and Display frequency images
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
nu_range=[950 1020];

marrow_rgb=intensity2RGB(rare,gray,[0 0.8]);
nu_37_rgb=imageToBlackBackgroundB(squeeze(RMD234_Sc9_HOT_SLI_t(1,1,1,:,:)),m_marrow,nu_range,jet);
nu_37=superpose2RGB(nu_37_rgb,marrow_rgb,m_marrow);

nu_39_rgb=imageToBlackBackgroundB(squeeze(RMD234_Sc12_HOT_SLI_t(1,1,1,:,:)),m_marrow,nu_range,jet);
nu_39=superpose2RGB(nu_39_rgb,marrow_rgb,m_marrow);

nu_41_rgb=imageToBlackBackgroundB(squeeze(RMD234_Sc14_HOT_SLI_t(1,1,1,:,:)),m_marrow,nu_range,jet);
nu_41=superpose2RGB(nu_41_rgb,marrow_rgb,m_marrow);

nu_43_rgb=imageToBlackBackgroundB(squeeze(RMD234_Sc16_HOT_SLI_t(1,1,1,:,:)),m_marrow,nu_range,jet);
nu_43=superpose2RGB(nu_43_rgb,marrow_rgb,m_marrow);

nu_45_rgb=imageToBlackBackgroundB(squeeze(RMD234_Sc18_HOT_SLI_t(1,1,1,:,:)),m_marrow,nu_range,jet);
nu_45=superpose2RGB(nu_45_rgb,marrow_rgb,m_marrow);

nu_47_rgb=imageToBlackBackgroundB(squeeze(RMD234_Sc20_HOT_SLI_t(1,1,1,:,:)),m_marrow,nu_range,jet);
nu_47=superpose2RGB(nu_47_rgb,marrow_rgb,m_marrow);

nu_49_rgb=imageToBlackBackgroundB(squeeze(RMD234_Sc22_HOT_SLI_t(1,1,1,:,:)),m_marrow,nu_range,jet);
nu_49=superpose2RGB(nu_49_rgb,marrow_rgb,m_marrow);

image_lim=[26 128];

figure
subplot(2,4,1);
imagesc(nu_37);
axis image off
title('T_l_u_x = 36.5\circ C','FontSize',15);
R_probe.outlineRois('linewidth',2,'color','m');
xlim(image_lim);
ylim(image_lim);

subplot(2,4,2);
imagesc(nu_39);
axis image off
title('T_l_u_x = 38.7\circ C','FontSize',15);
R_probe.outlineRois('linewidth',2,'color','m');
xlim(image_lim);
ylim(image_lim);

subplot(2,4,3);
imagesc(nu_41);
axis image off
title('T_l_u_x = 41.3\circ C','FontSize',15);
R_probe.outlineRois('linewidth',2,'color','m');
xlim(image_lim);
ylim(image_lim);

subplot(2,4,4);
imagesc(nu_43);
axis image off
title('T_l_u_x = 43.2\circ C','FontSize',15);
R_probe.outlineRois('linewidth',2,'color','m');
xlim(image_lim);
ylim(image_lim);

subplot(2,4,5);
imagesc(nu_45);
axis image off
title('T_l_u_x = 45.7\circ C','FontSize',15);
R_probe.outlineRois('linewidth',2,'color','m');
xlim(image_lim);
ylim(image_lim);

subplot(2,4,6);
imagesc(nu_47);
axis image off
title('T_l_u_x = 48.0\circ C','FontSize',15);
R_probe.outlineRois('linewidth',2,'color','m');
xlim(image_lim);
ylim(image_lim);

subplot(2,4,7);
imagesc(nu_49);
axis image off
title('T_l_u_x = 50.5\circ C','FontSize',15);
R_probe.outlineRois('linewidth',2,'color','m');
xlim(image_lim);
ylim(image_lim);

subplot(2,4,8);
imagesc(ones(64),nu_range);
colorbar
title('colorbar units: Hz')
set(gca,'FontSize',15);
set(gcf,'Name','sample 2: ZQSQ-HOT')