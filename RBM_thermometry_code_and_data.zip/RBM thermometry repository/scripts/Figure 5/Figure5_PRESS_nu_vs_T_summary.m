%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


Figure5_PRESS_sample2
Figure5_PRESS_sample3
Figure5_PRESS_sample4a
Figure5_PRESS_sample4b
Figure5_PRESS_sample5a
Figure5_PRESS_sample5b
Figure5_PRESS_sample6a
Figure5_PRESS_sample6b

f=fittype('m*x+b');
sp=[-3 1150];
[cfun_PRESS_234,gof_234]=fit(T_234',v_diff_fit_234',f,'StartPoint',sp);
[cfun_PRESS_236,gof_236]=fit(T_236',v_diff_fit_236',f,'StartPoint',sp);
[cfun_PRESS_242_3c,gof_242_3c]=fit(T_242',v_diff_fit_242_3c',f,'StartPoint',sp);
[cfun_PRESS_242_4d,gof_242_4d]=fit(T_242',v_diff_fit_242_4d',f,'StartPoint',sp);
[cfun_PRESS_243_3c,gof_243_3c]=fit(T_243',v_diff_fit_243_3c',f,'StartPoint',sp);
[cfun_PRESS_243_4d,gof_243_4d]=fit(T_243',v_diff_fit_243_4d',f,'StartPoint',sp);
[cfun_PRESS_244_3c,gof_244_3c]=fit(T_244',v_diff_fit_244_3c',f,'StartPoint',sp);
[cfun_PRESS_244_4d,gof_244_4d]=fit(T_244',v_diff_fit_244_4d',f,'StartPoint',sp);

%maximum points
[cfun_PRESS_max_234,gof_max_234]=fit(T_234',v_diff_max_234',f,'StartPoint',sp);
[cfun_PRESS_max_236,gof_max_236]=fit(T_236',v_diff_max_236',f,'StartPoint',sp);
[cfun_PRESS_max_242_3c,gof_max_242_3c]=fit(T_242',v_diff_max_242_3c',f,'StartPoint',sp);
[cfun_PRESS_max_242_4d,gof_max_242_4d]=fit(T_242',v_diff_max_242_4d',f,'StartPoint',sp);
[cfun_PRESS_max_243_3c,gof_max_243_3c]=fit(T_243',v_diff_max_243_3c',f,'StartPoint',sp);
[cfun_PRESS_max_243_4d,gof_max_243_4d]=fit(T_243',v_diff_max_243_4d',f,'StartPoint',sp);
[cfun_PRESS_max_244_3c,gof_max_244_3c]=fit(T_244',v_diff_max_244_3c',f,'StartPoint',sp);
[cfun_PRESS_max_244_4d,gof_max_244_4d]=fit(T_244',v_diff_fit_244_4d',f,'StartPoint',sp);

%ommitted cfun_PRESS_236.m 
m_press=[cfun_PRESS_234.m cfun_PRESS_242_3c.m cfun_PRESS_242_4d.m cfun_PRESS_243_3c.m cfun_PRESS_243_4d.m cfun_PRESS_244_3c.m cfun_PRESS_244_4d.m nan nan];

%fit with y intercept at 37C
f_37=fittype('m*(x-37)+b');
sp=[-3 1150];
[cfun_37_PRESS_234,gof_234]=fit(T_234',v_diff_fit_234',f_37,'StartPoint',sp);
[cfun_37_PRESS_236,gof_236]=fit(T_236',v_diff_fit_236',f_37,'StartPoint',sp);
[cfun_37_PRESS_242_3c,gof_242_3c]=fit(T_242',v_diff_fit_242_3c',f_37,'StartPoint',sp);
[cfun_37_PRESS_242_4d,gof_242_4d]=fit(T_242',v_diff_fit_242_4d',f_37,'StartPoint',sp);
[cfun_37_PRESS_243_3c,gof_243_3c]=fit(T_243',v_diff_fit_243_3c',f_37,'StartPoint',sp);
[cfun_37_PRESS_243_4d,gof_243_4d]=fit(T_243',v_diff_fit_243_4d',f_37,'StartPoint',sp);
[cfun_37_PRESS_244_3c,gof_244_3c]=fit(T_244',v_diff_fit_244_3c',f_37,'StartPoint',sp);
[cfun_37_PRESS_244_4d,gof_244_4d]=fit(T_244',v_diff_fit_244_4d',f_37,'StartPoint',sp);
m_37_press=[cfun_37_PRESS_234.m cfun_PRESS_236.m cfun_37_PRESS_242_3c.m cfun_37_PRESS_242_4d.m cfun_37_PRESS_243_3c.m cfun_37_PRESS_243_4d.m cfun_37_PRESS_244_3c.m cfun_37_PRESS_244_4d.m];
b_37_press=[cfun_37_PRESS_234.b cfun_PRESS_236.b cfun_37_PRESS_242_3c.b cfun_37_PRESS_242_4d.b cfun_37_PRESS_243_3c.b cfun_37_PRESS_243_4d.b cfun_37_PRESS_244_3c.b cfun_37_PRESS_244_4d.b];

fit_range_234=36.5:0.1:50.5;
fit_range_236=37:0.2:44.4;
fit_range_242=34:0.2:50;
fit_range_243=35:0.2:47;
fit_range_244=35:0.2:49;

figure
errorbar(T_234,v_diff_fit_234,v_diff_fit_234_std,'ro','LineWidth',2);
hold on
% errorbar(T_236,v_diff_fit_236,v_diff_fit_236_std,'k*','LineWidth',2);
errorbar(T_242,v_diff_fit_242_3c,v_diff_fit_242_3c_std,'ms','MarkerSize',15);
errorbar(T_242,v_diff_fit_242_4d,v_diff_fit_242_4d_std,'md','MarkerSize',15);
errorbar(T_243,v_diff_fit_243_3c,v_diff_fit_243_3c_std,'g<','MarkerSize',15);
errorbar(T_243,v_diff_fit_243_4d,v_diff_fit_243_4d_std,'g>','MarkerSize',15);
errorbar(T_244,v_diff_fit_244_3c,v_diff_fit_244_3c_std,'c<','MarkerSize',15);
errorbar(T_244,v_diff_fit_244_4d,v_diff_fit_244_4d_std,'c>','MarkerSize',15);

plot(fit_range_234,feval(cfun_PRESS_234,fit_range_234),'r','LineWidth',2);
% plot(fit_range_236,feval(cfun_PRESS_236,fit_range_236),'k','LineWidth',2);
plot(fit_range_242,feval(cfun_PRESS_242_3c,fit_range_242),'m','LineWidth',2);
plot(fit_range_242,feval(cfun_PRESS_242_4d,fit_range_242),'m','LineWidth',2);
plot(fit_range_243,feval(cfun_PRESS_243_3c,fit_range_243),'g','LineWidth',2);
plot(fit_range_243,feval(cfun_PRESS_243_4d,fit_range_243),'g','LineWidth',2);
plot(fit_range_244,feval(cfun_PRESS_244_3c,fit_range_244),'c','LineWidth',2);
plot(fit_range_244,feval(cfun_PRESS_244_4d,fit_range_244),'c','LineWidth',2);
