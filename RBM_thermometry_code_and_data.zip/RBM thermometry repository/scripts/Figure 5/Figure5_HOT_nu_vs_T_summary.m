%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


Figure5_HOT_sample1
Figure5_HOT_sample2
Figure5_HOT_sample3
Figure5_HOT_sample4a
Figure5_HOT_sample4b
Figure5_HOT_sample5a
Figure5_HOT_sample5b
Figure5_HOT_sample6a
Figure5_HOT_sample6b

f=fittype('m*x+b');
[cfun_HOT_233,gof_233]=fit(lux_T_233',v_ave_233',f);
[cfun_HOT_234,gof_234]=fit(lux_T_234',v_ave_234',f);
[cfun_HOT_236,gof_236]=fit(lux_T_236',v_ave_236',f);
[cfun_HOT_242_3c,gof_242_3c]=fit(lux_T_242_3c',v_ave_242_3c',f);
[cfun_HOT_242_4d,gof_242_4d]=fit(lux_T_242_4d',v_ave_242_4d',f);
[cfun_HOT_243_3c,gof_243_3c]=fit(lux_T_243_3c',v_ave_243_3c',f);
[cfun_HOT_243_4d,gof_243_4d]=fit(lux_T_243_4d',v_ave_243_4d',f);
[cfun_HOT_244_3c,gof_244_3c]=fit(lux_T_244_3c',v_ave_244_3c',f);
[cfun_HOT_244_4d,gof_244_4d]=fit(lux_T_244_4d',v_ave_244_4d',f);
b=[cfun_HOT_233.b cfun_HOT_234.b cfun_HOT_236.b cfun_HOT_242_3c.b cfun_HOT_242_4d.b cfun_HOT_243_3c.b cfun_HOT_243_4d.b cfun_HOT_244_3c.b cfun_HOT_244_4d.b];
m=[cfun_HOT_233.m cfun_HOT_234.m cfun_HOT_236.m cfun_HOT_242_3c.m cfun_HOT_242_4d.m cfun_HOT_243_3c.m cfun_HOT_243_4d.m cfun_HOT_244_3c.m cfun_HOT_244_4d.m];


fit_range_233=36.6:0.1:40.4;
fit_range_234=36.5:0.1:50.5;
fit_range_236=37:0.2:44.4;
fit_range_242=34:0.2:50;
fit_range_243=35:0.2:47;
fit_range_244=35:0.2:49;

figure
errorbar(lux_T_233,v_ave_233,v_std_233,'bx','MarkerSize',15,'LineWidth',2);
hold on
errorbar(lux_T_234,v_ave_234,v_std_234,'ro','LineWidth',2);
errorbar(lux_T_236,v_ave_236,v_std_236,'k*','LineWidth',2);
errorbar(lux_T_242_3c,v_ave_242_3c,v_std_242_3c,'ms','MarkerSize',15);
errorbar(lux_T_242_4d,v_ave_242_4d,v_std_242_4d,'md','MarkerSize',15);
errorbar(lux_T_243_3c,v_ave_243_3c,v_std_243_3c,'g<','MarkerSize',15);
errorbar(lux_T_243_4d,v_ave_243_4d,v_std_243_4d,'g>','MarkerSize',15);
errorbar(lux_T_244_3c,v_ave_244_3c,v_std_244_3c,'c<','MarkerSize',15);
errorbar(lux_T_244_4d,v_ave_244_4d,v_std_244_4d,'c>','MarkerSize',15);

plot(fit_range_233,feval(cfun_HOT_233,fit_range_233),'b','LineWidth',2);
plot(fit_range_234,feval(cfun_HOT_234,fit_range_234),'r','LineWidth',2);
plot(fit_range_236,feval(cfun_HOT_236,fit_range_236),'k','LineWidth',2);
plot(fit_range_242,feval(cfun_HOT_242_3c,fit_range_242),'m','LineWidth',2);
plot(fit_range_242,feval(cfun_HOT_242_4d,fit_range_242),'m','LineWidth',2);
plot(fit_range_243,feval(cfun_HOT_243_3c,fit_range_243),'g','LineWidth',2);
plot(fit_range_243,feval(cfun_HOT_243_4d,fit_range_243),'g','LineWidth',2);
plot(fit_range_244,feval(cfun_HOT_244_3c,fit_range_244),'c','LineWidth',2);
plot(fit_range_244,feval(cfun_HOT_244_4d,fit_range_244),'c','LineWidth',2);

axis square
set(gca,'FontSize',20)
legend('RMD233','RMD234','RMD236','RMD242-3c','RMD242-4d','RMD243-3c','RMD243-4d','RMD244-3c','RMD244-4d');
xlabel('temperature (\circC)','FontSize',20);
ylabel('iZQC frequency (Hz)','FontSize',20);
title({'frequency vs temperature in','rib marrow samples'},'FontSize',20);
xlim([36 51]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%intercept vs slope y-intercept corresponds to T = 37C
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
f_37=fittype('m*(x-37)+b');
[cfun_HOT_37C_233,gof_37C_233]=fit(lux_T_233',v_ave_233',f_37);
[cfun_HOT_37C_234,gof_37C_234]=fit(lux_T_234',v_ave_234',f_37);
[cfun_HOT_37C_236,gof_37C_236]=fit(lux_T_236',v_ave_236',f_37);
[cfun_HOT_37C_242_3c,gof_37C_242_3c]=fit(lux_T_242_3c',v_ave_242_3c',f_37);
[cfun_HOT_37C_242_4d,gof_37C_242_4d]=fit(lux_T_242_4d',v_ave_242_4d',f_37);
[cfun_HOT_37C_243_3c,gof_37C_243_3c]=fit(lux_T_243_3c',v_ave_243_3c',f_37);
[cfun_HOT_37C_243_4d,gof_37C_243_4d]=fit(lux_T_243_4d',v_ave_243_4d',f_37);
[cfun_HOT_37C_244_3c,gof_37C_244_3c]=fit(lux_T_244_3c',v_ave_244_3c',f_37);
[cfun_HOT_37C_244_4d,gof_37C_244_4d]=fit(lux_T_244_4d',v_ave_244_4d',f_37);
b_37c=[cfun_HOT_37C_233.b cfun_HOT_37C_234.b cfun_HOT_37C_236.b cfun_HOT_37C_242_3c.b cfun_HOT_37C_242_4d.b cfun_HOT_37C_243_3c.b cfun_HOT_37C_243_4d.b cfun_HOT_37C_244_3c.b cfun_HOT_37C_244_4d.b];
m_37c=[cfun_HOT_37C_233.m cfun_HOT_37C_234.m cfun_HOT_37C_236.m cfun_HOT_37C_242_3c.m cfun_HOT_37C_242_4d.m cfun_HOT_37C_243_3c.m cfun_HOT_37C_243_4d.m cfun_HOT_37C_244_3c.m cfun_HOT_37C_244_4d.m];

%find confidence intervals of m and b
ci_b=[ci95(cfun_HOT_37C_233,1) ci95(cfun_HOT_37C_234,1) ci95(cfun_HOT_37C_236,1) ci95(cfun_HOT_37C_242_3c,1) ci95(cfun_HOT_37C_242_4d,1) ci95(cfun_HOT_37C_243_3c,1) ci95(cfun_HOT_37C_243_4d,1) ci95(cfun_HOT_37C_244_3c,1) ci95(cfun_HOT_37C_244_4d,1)];
ci_m=[ci95(cfun_HOT_37C_233,2) ci95(cfun_HOT_37C_234,2) ci95(cfun_HOT_37C_236,2) ci95(cfun_HOT_37C_242_3c,2) ci95(cfun_HOT_37C_242_4d,2) ci95(cfun_HOT_37C_243_3c,2) ci95(cfun_HOT_37C_243_4d,2) ci95(cfun_HOT_37C_244_3c,2) ci95(cfun_HOT_37C_244_4d,2)];


plot_range=2:9;
m_hot=m;
figure
h_err=errorbarxy(b_37c(plot_range),m_37c(plot_range),ci_b(plot_range)/2,ci_m(plot_range)/2);
xlabel('\Delta\nu_3_7_{\circC}','FontSize',15)
ylabel('\alpha (Hz/\circC)','FontSize',15);
set(gca,'FontSize',15);
axis square
set(h_err.hMain,'LineStyle','d');
set(gca,'LineWidth',2);
xlim([975 1025]);
ylim([-3.5 -1.5]);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%intercept vs slope y-intercept, 1 dof
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
f_37C_1dof=fittype('m*(x-60.6)+936.8');
[cfun_HOT_37C_1dof_233,gof_37C_1dof_233]=fit(lux_T_233',v_ave_233',f_37C_1dof);
[cfun_HOT_37C_1dof_234,gof_37C_1dof_234]=fit(lux_T_234',v_ave_234',f_37C_1dof);
[cfun_HOT_37C_1dof_236,gof_37C_1dof_236]=fit(lux_T_236',v_ave_236',f_37C_1dof);
[cfun_HOT_37C_1dof_242_3c,gof_37C_1dof_242_3c]=fit(lux_T_242_3c',v_ave_242_3c',f_37C_1dof);
[cfun_HOT_37C_1dof_242_4d,gof_37C_1dof_242_4d]=fit(lux_T_242_4d',v_ave_242_4d',f_37C_1dof);
[cfun_HOT_37C_1dof_243_3c,gof_37C_1dof_243_3c]=fit(lux_T_243_3c',v_ave_243_3c',f_37C_1dof);
[cfun_HOT_37C_1dof_243_4d,gof_37C_1dof_243_4d]=fit(lux_T_243_4d',v_ave_243_4d',f_37C_1dof);
[cfun_HOT_37C_1dof_244_3c,gof_37C_1dof_244_3c]=fit(lux_T_244_3c',v_ave_244_3c',f_37C_1dof);
[cfun_HOT_37C_1dof_244_4d,gof_37C_1dof_244_4d]=fit(lux_T_244_4d',v_ave_244_4d',f_37C_1dof);
m_1dof=[cfun_HOT_37C_1dof_233.m cfun_HOT_37C_1dof_234.m cfun_HOT_37C_1dof_236.m cfun_HOT_37C_1dof_242_3c.m cfun_HOT_37C_1dof_242_4d.m cfun_HOT_37C_1dof_243_3c.m cfun_HOT_37C_1dof_243_4d.m cfun_HOT_37C_1dof_244_3c.m cfun_HOT_37C_1dof_244_4d.m];

%find confidence intervals of m and b
ci_m_1dof=[ci95(cfun_HOT_37C_1dof_233,1) ci95(cfun_HOT_37C_1dof_234,1) ci95(cfun_HOT_37C_1dof_236,1) ci95(cfun_HOT_37C_1dof_242_3c,1) ci95(cfun_HOT_37C_1dof_242_4d,1) ci95(cfun_HOT_37C_1dof_243_3c,1) ci95(cfun_HOT_37C_1dof_243_4d,1) ci95(cfun_HOT_37C_1dof_244_3c,1) ci95(cfun_HOT_37C_1dof_244_4d,1)];

figure
errorbar(lux_T_233,v_ave_233,v_std_233,'bx','MarkerSize',15,'LineWidth',2);
hold on
errorbar(lux_T_234,v_ave_234,v_std_234,'ro','LineWidth',2);
errorbar(lux_T_236,v_ave_236,v_std_236,'k*','LineWidth',2);
errorbar(lux_T_242_3c,v_ave_242_3c,v_std_242_3c,'ms','MarkerSize',15);
errorbar(lux_T_242_4d,v_ave_242_4d,v_std_242_4d,'md','MarkerSize',15);
errorbar(lux_T_243_3c,v_ave_243_3c,v_std_243_3c,'g<','MarkerSize',15);
errorbar(lux_T_243_4d,v_ave_243_4d,v_std_243_4d,'g>','MarkerSize',15);
errorbar(lux_T_244_3c,v_ave_244_3c,v_std_244_3c,'c<','MarkerSize',15);
errorbar(lux_T_244_4d,v_ave_244_4d,v_std_244_4d,'c>','MarkerSize',15);

plot(fit_range_233,feval(cfun_HOT_37C_1dof_233,fit_range_233),'b','LineWidth',2);
plot(fit_range_234,feval(cfun_HOT_37C_1dof_234,fit_range_234),'r','LineWidth',2);
plot(fit_range_236,feval(cfun_HOT_37C_1dof_236,fit_range_236),'k','LineWidth',2);
plot(fit_range_242,feval(cfun_HOT_37C_1dof_242_3c,fit_range_242),'m','LineWidth',2);
plot(fit_range_242,feval(cfun_HOT_37C_1dof_242_4d,fit_range_242),'m','LineWidth',2);
plot(fit_range_243,feval(cfun_HOT_37C_1dof_243_3c,fit_range_243),'g','LineWidth',2);
plot(fit_range_243,feval(cfun_HOT_37C_1dof_243_4d,fit_range_243),'g','LineWidth',2);
plot(fit_range_244,feval(cfun_HOT_37C_1dof_244_3c,fit_range_244),'c','LineWidth',2);
plot(fit_range_244,feval(cfun_HOT_37C_1dof_244_4d,fit_range_244),'c','LineWidth',2);

axis square
set(gca,'FontSize',15)
% legend('sample 1','sample 2','sample 3','sample 4a','sample 4b','RMD243-3c','RMD243-4d','RMD244-3c','RMD244-4d');
xlabel('temperature (\circC)');
ylabel('iZQC frequency (Hz)');
title({'frequency vs T in rib marrow samples;','linear fits have 1 DOF'});
xlim([36 51]);

%find point of intersection of all of the lines.  result is that they
%intersect at 69 C, or 936Hz
fofT=@(b,m,num,T) m(num)*(T-37)+b(num);
T_=1;
T_range=0:0.5:70;
clear std_nu
for T=T_range
    num_=1;
    for num=plot_range;
        nu_int(num_)=(fofT(b_37c,m_37c,num,T))^2;
        num_=num_+1;
    end
    std_nu(T_)=std(nu_int);
    T_=T_+1;
end

%find frequency of intersection
[~,i_min]=min(std_nu);
intersect_T=T_range(i_min);
num_=1;
for exp_num=plot_range
    nus(num_)= fofT(b,m,exp_num,intersect_T);
    num_=num_+1;
end
nu_avg=mean(nus);