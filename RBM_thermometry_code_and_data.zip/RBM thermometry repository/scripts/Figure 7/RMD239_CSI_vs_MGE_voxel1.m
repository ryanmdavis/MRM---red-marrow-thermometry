%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


getDirScanInfo('RMD239',[15 16],'tau_min','tau_max','tau_inc');
frame_size = [3.5 3.5];
fs=19;

voxel=[75 86];

t_mge=(0:11)*2.1; %ms
td_mge=squeeze(abs(RMD239_Sc16_MGE(1,:,voxel(1),voxel(2))));

t_hot=0:15/47:15;
td_hot=RMD239_Sc15_HOT_SLI(1,:,1,voxel(1),voxel(2));

f=fittype('a*exp(-x/t)');
[cfun_mge,gof_mge]=fit(t_mge',abs(td_mge)'/max(abs(td_mge)),f,'StartPoint',[1 3]);
[cfun_hot,gof_hot]=fit(t_hot',abs(td_hot)'/max(abs(td_hot)),f,'StartPoint',[1 3]);
fit_x=0:0.1:5;
figure
scatter(t_hot,abs(td_hot)/max(abs(td_hot)),'kx','SizeData',100);
hold on
scatter(t_mge,abs(td_mge)/max(abs(td_mge)),'b');
plot(fit_x,feval(cfun_mge,fit_x),'b','LineWidth',2);
plot(fit_x,feval(cfun_hot,fit_x),'k','LineWidth',2);
xlabel('time (ms)','FontSize',fs);
ylabel('signal (a.u.)','FontSize',fs);
title('RMD238 - voxel 1','FontSize',fs);
set(gca,'FontSize',fs);
legend('HOT','MGE');
axis square
xlim([0 5]);
ylim([0 1.1]);