%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


frame_size=[2.5 5];

T2s_hot=[4.6 4.47 4.12 4.51 5.42 5.4 6.01 4.70 5.54];
T2s_mge=[1.88 2.59 1.5 2.55 2.5 2.64 1.99 3.82 2.89];

T2s=[T2s_hot;T2s_mge]';
figure,boxplot(T2s,'colors','kk','Labels',{'HOT','MGE'},'widths',0.8,'whisker',20);
set(gca,'FontSize',fs);
ylabel('T_2* (ms)');
hold on
scatter(ones(1,size(T2s_hot,2)),T2s_hot,'kx','SizeData',200);
scatter(2*ones(1,size(T2s_mge,2)),T2s_mge,'kx','SizeData',200);

h=ttest(T2s_hot,T2s_mge);


% %summary of voxel decay for HOT and MGE
% %RMD238
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% voxel (52,87) 
% cfun_hot = 
% 
%      General model:
%      cfun_hot(x) = a*exp(-x/t)
%      Coefficients (with 95% confidence bounds):
%        a =       1.011  (0.9492, 1.073)
%        t =       4.359  (3.964, 4.753)
%        
% 
% cfun_mge = 
% 
%      General model:
%      cfun_mge(x) = a*exp(-x/t)
%      Coefficients (with 95% confidence bounds):
%        a =      0.9945  (0.9585, 1.03)
%        t =       1.882  (1.724, 2.04)
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
% voxel(52,71)
% cfun_hot = 
% 
%      General model:
%      cfun_hot(x) = a*exp(-x/t)
%      Coefficients (with 95% confidence bounds):
%        a =       1.029  (0.9806, 1.077)
%        t =       4.476  (4.166, 4.787)
%        
% cfun_mge = 
% 
%      General model:
%      cfun_mge(x) = a*exp(-x/t)
%      Coefficients (with 95% confidence bounds):
%        a =      0.9953  (0.9733, 1.017)
%        t =       2.594  (2.477, 2.71)
%        
%        
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\
% voxel(70,73)
% cfun_hot = 
% 
%      General model:
%      cfun_hot(x) = a*exp(-x/t)
%      Coefficients (with 95% confidence bounds):
%        a =       1.076  (1.02, 1.132)
%        t =       4.125  (3.81, 4.441)
%        
%  cfun_mge = 
% 
%      General model:
%      cfun_mge(x) = a*exp(-x/t)
%      Coefficients (with 95% confidence bounds):
%        a =       0.999  (0.9862, 1.012)
%        t =       1.501  (1.45, 1.551)
%        
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %RMD237
% voxel(60,78)
% cfun_hot = 
% 
%      General model:
%      cfun_hot(x) = a*exp(-x/t)
%      Coefficients (with 95% confidence bounds):
%        a =       1.065  (1.002, 1.129)
%        t =       4.506  (4.107, 4.905)
%        
% cfun_mge = 
% 
%      General model:
%      cfun_mge(x) = a*exp(-x/t)
%      Coefficients (with 95% confidence bounds):
%        a =       1.004  (0.9794, 1.029)
%        t =       2.552  (2.425, 2.68)
%  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  voxel(72,73)
%  cfun_hot = 
% 
%      General model:
%      cfun_hot(x) = a*exp(-x/t)
%      Coefficients (with 95% confidence bounds):
%        a =      0.9032  (0.8133, 0.993)
%        t =       5.425  (4.611, 6.238)
%        
% cfun_mge = 
% 
%      General model:
%      cfun_mge(x) = a*exp(-x/t)
%      Coefficients (with 95% confidence bounds):
%        a =       1.007  (0.9756, 1.038)
%        t =       2.497  (2.338, 2.656)
%        
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% voxel(52,56)
% cfun_hot = 
% 
%      General model:
%      cfun_hot(x) = a*exp(-x/t)
%      Coefficients (with 95% confidence bounds):
%        a =       1.015  (0.9318, 1.099)
%        t =       5.415  (4.743, 6.086)
% 
% cfun_mge = 
% 
%      General model:
%      cfun_mge(x) = a*exp(-x/t)
%      Coefficients (with 95% confidence bounds):
%        a =      0.9846  (0.9249, 1.044)
 %        t =       2.636  (2.313, 2.959)

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % RMD239
% % voxel(75,86)
% cfun_hot = 
% 
%      General model:
%      cfun_hot(x) = a*exp(-x/t)
%      Coefficients (with 95% confidence bounds):
%        a =      0.9946  (0.9333, 1.056)
%        t =       6.006  (5.434, 6.579)
%        
% cfun_mge = 
% 
%      General model:
%      cfun_mge(x) = a*exp(-x/t)
%      Coefficients (with 95% confidence bounds):
%        a =       0.996  (0.9373, 1.055)
%        t =       1.994  (1.729, 2.26)
%        
% %voxel(80,49)
% cfun_hot = 
% 
%      General model:
%      cfun_hot(x) = a*exp(-x/t)
%      Coefficients (with 95% confidence bounds):
%        a =       1.036  (0.9769, 1.096)
%        t =       4.703  (4.299, 5.107)
% 
% cfun_mge = 
% 
%      General model:
%      cfun_mge(x) = a*exp(-x/t)
%      Coefficients (with 95% confidence bounds):
%        a =       1.005  (0.9694, 1.04)
%        t =       3.233  (3.017, 3.45)
%        
% %voxel(58,69)
% cfun_hot = 
% 
%      General model:
%      cfun_hot(x) = a*exp(-x/t)
%      Coefficients (with 95% confidence bounds):
%        a =      0.9898  (0.9179, 1.062)
%        t =       5.539  (4.927, 6.152)
% 
% cfun_mge = 
% 
%      General model:
%      cfun_mge(x) = a*exp(-x/t)
%      Coefficients (with 95% confidence bounds):
%        a =       1.006  (0.9482, 1.064)
%        t =       2.885  (2.56, 3.211)
