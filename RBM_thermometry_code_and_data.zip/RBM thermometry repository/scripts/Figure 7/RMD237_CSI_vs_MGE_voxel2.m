%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


% getDirScanInfo('RMD237',[22 37]);

voxel=[72 73];

t=(0:(15/63):15); %ms
t_mge=(0:11)*2.1; %ms
td=RMD237_Sc37_HOT_SLI(1,:,1,voxel(1),voxel(2));
td_se=RMD237_Sc37_HOT_SLI(1,:,2,voxel(1),voxel(2));
td_fill=zeros(1,512);
td_fill_se=zeros(1,512);
td_fill(1:64)=td;
td_fill_se(1:64)=td_se;
s_zq=fftshift(fft(fftshift(td_fill)));
s_se=fftshift(fft(fftshift(td_fill_se)));
bw_f1=64/0.015;
hz=-0.5*bw_f1:bw_f1/511:0.5*bw_f1;
td_mge=squeeze(RMD237_Sc22_MGE(1,:,voxel(1),voxel(2)));

f=fittype('a*exp(-x/t)');
[cfun_mge,gof_mge]=fit(t_mge',abs(td_mge)'/max(abs(td_mge)),f,'StartPoint',[1 3]);
[cfun_hot,gof_hot]=fit(t',abs(td)'/max(abs(td)),f,'StartPoint',[1 3]);
fit_x=0:0.1:5;
figure
scatter(t,abs(td)/max(abs(td)));
hold on
scatter(t_mge,abs(td_mge)/max(abs(td_mge)),'r');
plot(fit_x,feval(cfun_mge,fit_x),'r');
plot(fit_x,feval(cfun_hot,fit_x)),'b';
xlabel('evolution time (ms)','FontSize',15);
ylabel('normalized signal intensity (a.u.)','FontSize',15);
title('RMD237 - voxel 2','FontSize',15);
set(gca,'FontSize',15);
legend('HOT','Multiple Gradient Echo (MGE)');
axis square
xlim([0 5]);
ylim([0 1.1]);
% text(0.2,0.15,{'T_2^*_,_M_G_E=2.6ms(2.4ms,2.6ms)','T_2^*_,_H_O_T=4.5ms(4.1ms,4.9ms)'},'FontSize',15);

figure,subplot(1,2,1);
imagesc(squeeze(abs(RMD237_Sc37_HOT_SLI(1,1,1,:,:))));
axis image off
title('iZQC image','FontSize',15);
subplot(1,2,2);
imagesc(squeeze(abs(RMD237_Sc22_MGE(1,1,:,:))));
axis image off
colormap gray

title('MGE image','FontSize',15);