%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


%% reconstruct data
getDirScanInfo('RMD238',[4 21],'PVM_SpecSWH','tau_inc','tau_min','tau_max');
fs=18;

%% press data
hz_press=-0.5*4006.41:4006.41/2047:0.5*4006.41;
s_press = exponentialAppodNMRSpect(RMD238_Sc4_spects,4006,5);

%% hot data
td_hot=RMD238_Sc21_HOT_RARE_Ni(1,:,1,60,76);
td_hot_fill = zeros(1,2048);    
td_hot_fill(1:64)=td_hot;
s_hot=fftshift(fft(fftshift(td_hot_fill)));
bw_hot=64/0.015;
hz_hot=-0.5*bw_hot:bw_hot/2047:0.5*bw_hot;
s_hot = exponentialAppodNMRSpect(s_hot,bw_hot,5);

%% display spectra
fs = 18;
f_h=figure
plot(hz_press,abs(s_press)/max(abs(s_press)),'k','LineWidth',1);
hold on
plot(hz_hot,abs(s_hot)/max(abs(s_hot)),'b','LineWidth',1)
set(gca,'FontSize',fs);
set(gca,'xdir','reverse');
axis square
xlim([-2000 2000]);
ylim([0 1]);
xlabel('resonance frequency (Hz)','FontSize',fs);
ylabel('signal intensity (a.u.)','FontSize',fs);

%% generate legend
f_l=figure,plot(1,1,'k');
hold on
plot(1,1,'b');
set(gca,'FontSize',fs);
legend('PRESS','ZQSQ-HOT');
axis off