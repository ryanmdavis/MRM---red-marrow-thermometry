%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% put the location of the downloaded "RBM thermometry repository" here:
path='C:\Users\Aspect\Dropbox\RBM thermometry repository\';



m_threshold=0.33;
hist_bins=0:0.5:11;
figure
%RMD233
getDirScanInfo('RMD233',9);
close
R_marrow=Rois();
R_marrow.loadRois(strcat(path,'ROIs\Figure 5\RMD233 marrow region.roi'));
m_233=squeeze(R_marrow.getMasks());
t_233=squeeze(RMD233_Sc9_HOT_SLI_t(:,1,1,:,:));
i_233=abs(squeeze(RMD233_Sc9_HOT_SLI(1,1,1,:,:)));
m_233(i_233<m_threshold*max(max(i_233)))=0;
std_233=squeeze(std(t_233,0,1));
clear RMD* R_marrow
subplot(2,3,1),hist(std_233(boolean(m_233)),hist_bins);
xlim([0 10]);

%RMD234
getDirScanInfo('RMD234',9);
close
R_marrow=Rois();
R_marrow.loadRois(strcat(path,'ROIs\Figure 5\RMD234 marrow region.roi'));
m_234=squeeze(R_marrow.getMasks());
t_234=squeeze(RMD234_Sc9_HOT_SLI_t(:,1,1,:,:));
i_234=abs(squeeze(RMD234_Sc9_HOT_SLI(1,1,1,:,:)));
m_234(i_234<m_threshold*max(max(i_234)))=0;
std_234=squeeze(std(t_234,0,1));
clear RMD* R_marrow
subplot(2,3,2),hist(std_234(boolean(m_234)),hist_bins);
xlim([0 10]);


%RMD236
getDirScanInfo('RMD236',14);
close
R_marrow=Rois();
R_marrow.loadRois(strcat(path,'ROIs\Figure 5\RMD236 marrow region.roi'));
m_236=squeeze(R_marrow.getMasks());
t_236=squeeze(RMD236_Sc14_HOT_SLI_t(:,1,1,:,:));
i_236=abs(squeeze(RMD236_Sc14_HOT_SLI(1,1,1,:,:)));
m_236(i_236<m_threshold*max(max(i_236)))=0;
std_236=squeeze(std(t_236,0,1));
clear RMD* R_marrow
subplot(2,3,3),hist(std_236(boolean(m_236)),hist_bins);
xlim([0 10]);


%RMD242
getDirScanInfo('RMD242',18);
close
R_marrow=Rois();
R_marrow.loadRois(strcat(path,'ROIs\Figure 5\RMD242 marrow region.roi'));
m_242=squeeze(R_marrow.getMasks());
t_242=squeeze(RMD242_Sc18_HOT_SLI_t(:,1,1,:,:));
i_242=abs(squeeze(RMD242_Sc18_HOT_SLI(1,1,1,:,:)));
m_242(i_242<m_threshold*max(max(i_242)))=0;
std_242=squeeze(std(t_242,0,1));
clear RMD* R_marrow
subplot(2,3,4),hist(std_242(boolean(m_242)),hist_bins);
xlim([0 10]);


%RMD243
getDirScanInfo('RMD243',13);
close
R_marrow=Rois();
R_marrow.loadRois(strcat(path,'ROIs\Figure 5\RMD243 marrow region.roi'));
m_243=squeeze(R_marrow.getMasks());
t_243=squeeze(RMD243_Sc13_HOT_SLI_t(:,1,1,:,:));
i_243=abs(squeeze(RMD243_Sc13_HOT_SLI(1,1,1,:,:)));
m_243(i_243<m_threshold*max(max(i_243)))=0;
std_243=squeeze(std(t_243,0,1));
clear RMD* R_marrow
subplot(2,3,5),hist(std_243(boolean(m_243)),hist_bins);
xlim([0 10]);


%RMD244
getDirScanInfo('RMD244',9);
close
R_marrow=Rois();
R_marrow.loadRois(strcat(path,'ROIs\Figure 5\RMD244 marrow region.roi')); %3c and 4d are same marrow region
m_244=squeeze(R_marrow.getMasks());
t_244=squeeze(RMD244_Sc9_HOT_SLI_t(:,1,1,:,:));
i_244=abs(squeeze(RMD244_Sc9_HOT_SLI(1,1,1,:,:)));
m_244(i_244<m_threshold*max(max(i_244)))=0;
std_244=squeeze(std(t_244,0,1));
clear RMD* R_marrow
subplot(2,3,6),hist(std_244(boolean(m_244)),hist_bins);
xlim([0 10]);

std_all=[std_233(boolean(m_233))' std_234(boolean(m_234))' std_236(boolean(m_236))' std_242(boolean(m_242))' std_243(boolean(m_243))' std_244(boolean(m_244))'];


fs=18;
figure,hist(std_all,hist_bins);
h_hist = findobj(gca,'Type','patch');
set(h_hist,'FaceColor','k','EdgeColor','w')
xlim([0 10]);
set(gca,'FontSize',fs);
xlabel('temperature precision (\circC)','FontSize',fs);
ylabel('number of voxels','FontSize',fs);
axis square
% set(gca,'box','off');