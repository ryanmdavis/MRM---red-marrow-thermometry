% The data and MATLAB scripts you just downloaded accompany the manuscript:
% Davis RM, Warren WS.  "Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow", MRM, 2015

% TO RUN THE CODE: navigate to the "~\RBM thermometry repository\scripts" 
% folder, and run the script associated with a given figure (2-8)

% The code won't run unless you:
% 1) add the location of the folder "RBM thermometry repository" and all
%       subfolders (besides /.git folder) to your path.  Use the set path 
%       tool in the MATLAB main window do do this.
% 2) find the function file "~\RBM thermometry repository\getDirScanInfo_dir\loadDataPath.m" 
%     and change the directory in line 6 to the location of "RBM thermometry repository" 
%     e.g. DATA_PATH={'C:\Users\<your user name>\RBM thermometry repository\data'};
% 3) For some figures (2,3,5,8) you must put the location of "RBM thermometry repository" into the
%     "path" variable at the top of the FigureX.m file.
% 4) If the code is not running, recheck the above 3 points.  Take note if there
%    should be a slash in the path.


% NOTE:  some Figures will take a long time to run due to the
% large dataset size.  The rate limiting step is the
% conversion of phase difference images into temperature based on the
% calibration curve.  Right now the algorigthm converting phase to temperature 
% is fairly slow and will be imporved in the fugure.
% Some of the datasets are both multi-echo (extra echoes are discarded in
% this manuscript) and timecourses, meaning that a large number of
% temperature imgages are calculated during reconstruction.  For these
% large datestes, recon should take less than 5 minutes, so please be patient.

%If you are having problems, contact me at rmd12@duke.edu