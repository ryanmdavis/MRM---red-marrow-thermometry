%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


function new_obj = resizeRois(obj,factor)
    masks = obj.getMasks;
    new_masks = zeros(size(masks,1),size(masks,2) * factor,size(masks,3) * factor);
    for mask_num = 1:size(masks,1)
        new_masks(mask_num,:,:) = reshape(imresize(reshape(masks(mask_num,:,:),size(masks,2),size(masks,3)),factor,'nearest'),1,size(new_masks,2),size(new_masks,3));
    end
    new_obj = Rois(new_masks,'input_type','masks');