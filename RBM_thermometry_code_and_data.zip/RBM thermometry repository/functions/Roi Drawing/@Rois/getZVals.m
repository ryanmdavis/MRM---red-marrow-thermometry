%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


function zvals = getRoiAvgs(obj,img)

zvals = zeros(1,obj.getLength());    
    for roi_num = 1:obj.getLength()
        mask = obj.getSpecRoi(roi_num).getMask();
        masked = mask .* img;
        total = sum(sum(masked));
        zvals(roi_num) = total/obj.getSpecRoi(roi_num).getNumPix();
    end