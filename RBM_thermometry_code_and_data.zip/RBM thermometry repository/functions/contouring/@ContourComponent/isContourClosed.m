%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


function isclosed = isContourClosed(obj)
    num_points = size(obj.row_points,1);
    if (((obj.row_points(1)-obj.row_points(num_points))^2+(obj.col_points(1) - obj.col_points(num_points))^2)^.5) <= 2^.5
        isclosed = boolean(1);
    else
        isclosed = boolean(0);
    end
end
        