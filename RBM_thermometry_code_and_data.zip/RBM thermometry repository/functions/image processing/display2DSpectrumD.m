%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


function display2DSpectrumD(spectrum,f1_bw,f1_plot_center_fq,f1_plot_bw,f2_bw,f2_plot_center_fq,f2_plot_bw,varargin)

imagesc(spectrum);
set(gca,'FontSize',18);
axis image
x_plot_lim = round(1+ (size(spectrum,2)-1)*[(0.5 - 0.5*f2_plot_bw/f2_bw) (0.5 + 0.5*f2_plot_bw/f2_bw)]);
y_plot_lim = round(1+ (size(spectrum,1)-1)*[(0.5 - 0.5*f1_plot_bw/f1_bw) (0.5 + 0.5*f1_plot_bw/f1_bw)]);
xlim(x_plot_lim);
ylim(y_plot_lim);

num_x_ticks = max(size(get(gca,'XTick')));
num_y_ticks = max(size(get(gca,'YTick')));

x_tick_locations = get(gca,'XTick')/size(spectrum,2)-0.5;
y_tick_locations = get(gca,'YTick')/size(spectrum,1)-0.5;

round_digit_f1=round(log10(f1_bw))-2;
round_digit_f2=round(log10(f2_bw))-2;

for x=1:num_x_ticks
    x_ticks{x} = num2str(roundn(x_tick_locations(x) * f2_bw,round_digit_f2));
end

for y=1:num_y_ticks
    y_ticks{y} = num2str(roundn(y_tick_locations(y) * f1_bw,round_digit_f1));
end

set(gca,'XTickLabel',x_ticks);
set(gca,'YTickLabel',y_ticks);