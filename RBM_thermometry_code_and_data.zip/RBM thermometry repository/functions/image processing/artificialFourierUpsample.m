%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


%spatial dimensions must be the last two dimensions of data matrix

function i_up = artificialFourierUpsample(image,upsample_factor)
num_dim = max(size(size(image)));

max_size = max([size(image,num_dim) size(image,num_dim-1)]);
recon_size = max_size*upsample_factor;

k = fftshift(fftshift(fft(fft(fftshift(fftshift(image,num_dim),num_dim-1),[],num_dim),[],num_dim-1),num_dim),num_dim-1);

if upsample_factor > 1
    if num_dim > 2
        i_up = fftshift(fftshift(ifft(ifft(ifftshift(ifftshift(zeroPadImageC(k,[recon_size recon_size]),num_dim),num_dim-1),[],num_dim),[],num_dim-1),num_dim),num_dim-1);
    else
        i_up = fftshift(fftshift(ifft(ifft(ifftshift(ifftshift(zeroPadImage(k,[recon_size recon_size]),num_dim),num_dim-1),[],num_dim),[],num_dim-1),num_dim),num_dim-1);
    end
elseif upsample_factor < 1
   k_size = size(k);
   k_new_size=[k_size(end-1) k_size(end)];
   k_new_size(end)=round(k_new_size(end)*upsample_factor);
   k_new_size(end-1)=round(k_new_size(end-1)*upsample_factor);
   k_new=zeros(k_new_size);
   if num_dim==2
      k_new=k((end/2-k_new_size(1)/2+1):(end/2+k_new_size(1)/2), (end/2-k_new_size(2)/2+1):(end/2+k_new_size(2)/2));
   elseif num_dim==3
       k_new=k(:,(end/2-k_new_size(1)/2+1):(end/2+k_new_size(1)/2), (end/2-k_new_size(2)/2+1):(end/2+k_new_size(2)/2));
   elseif num_dim==4
       k_new=k(:,:,(end/2-k_new_size(1)/2+1):(end/2+k_new_size(1)/2), (end/2-k_new_size(2)/2+1):(end/2+k_new_size(2)/2));
   elseif num_dim==5
       k_new=k(:,:,:,(end/2-k_new_size(1)/2+1):(end/2+k_new_size(1)/2), (end/2-k_new_size(2)/2+1):(end/2+k_new_size(2)/2));
   end
%    i_up = fftshift(fftshift(ifft(ifft(ifftshift(ifftshift(zeroPadImage(k_new,[recon_size recon_size]),num_dim),num_dim-1),[],num_dim),[],num_dim-1),num_dim),num_dim-1);
   i_up = fftshift(fftshift(ifft(ifft(ifftshift(ifftshift(k_new,num_dim),num_dim-1),[],num_dim),[],num_dim-1),num_dim),num_dim-1);
else
    i_up=image;
end
i_up=i_up*upsample_factor^2;