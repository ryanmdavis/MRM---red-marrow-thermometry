%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


%takes a 2 x row x column
%time evolution is in ms
function varargout = imagesToTempNT_PD(pd,time_evolution_ms,varargin)


invar = struct('field_strength_T',7,'cal_curve',[],'dir',[]);
argin = varargin;
invar = generateArgin(invar,argin);
fs=invar.field_strength_T;

[zq_windows,sq_windows] = zqsqCoherenceOrder(size(pd,3));

if isempty(invar.cal_curve)
    path_cell=loadDataPath;
    load(strcat(path_cell{1},'\hot calibration curves'),'T_of_nu');
    vtot = T_of_nu;
else
    vtot = invar.cal_curve;
end

freq_est = 1.030*fs/7;
wrapped_phase = determineWrappedPhase(freq_est,time_evolution_ms);
pd_tot=pd+wrapped_phase;
%looking at nu vs evolution time
if size(pd,2)>1
    p_meth = struct('tau_max',[],'tau_inc',[],'tau_min',[]);
    p_meth = getPVEntry3([invar.dir '\method'],p_meth);
    p_acqp = struct('ACQ_vd_list',[]);
    p_acqp = getPVEntry3([invar.dir '\acqp'],p_acqp);
    d_tau=p_meth.tau_max-p_meth.tau_min;
%     time_evolution_ms=time_evolution_ms+(0:d_tau/(p_meth.tau_inc-1):d_tau);
    time_evolution_ms=time_evolution_ms+parseVdList(p_acqp.ACQ_vd_list)*1000;
    nu_hot=zeros(size(pd_tot));
    for td=1:size(pd,2)
        nu_hot(:,td,:,:,:)=(pd_tot(:,td,:,:,:)+phaseWrapCorrHotImage(freq_est,pd_tot(:,td,:,:,:),time_evolution_ms(td)))/(2 * pi * time_evolution_ms(td) * 0.001);
    end
else
    phase_correction = phaseWrapCorrHotImage(freq_est,pd_tot,time_evolution_ms);
    pd_tot = pd_tot + phase_correction;
    nu_hot = pd_tot ./ (2 * pi * time_evolution_ms * 0.001);
end
t = vtot(nu_hot,fs);
varargout{1}=t;
if nargout ==2
    varargout{2}=nu_hot;
end