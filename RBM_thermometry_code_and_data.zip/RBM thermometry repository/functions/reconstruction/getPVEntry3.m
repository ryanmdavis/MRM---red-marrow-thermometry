%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


%Written by Ryan M Davis
%this function reads scan parameters from Paravision method or acqp files
function fieldss = getPVEntry3(file,fieldss)

% if boolean(exist([file '_format'],'file'))
    

text_temp = textread(file,'%s');
text = '';
for cell_num = 1:size(text_temp,1)
    text = [text text_temp{cell_num} ' '];
end

fields = fieldnames(fieldss);
for field_num = 1:size(fields,1);
    field = ['##$' fields{field_num} '='];
    field_size = size(field,2);
    location = min(strfind(text,field)) + field_size;
    if ~isempty(location)
        delimiters1 = location + min(strfind(text(location:end),'##')); %two for delimiter (##) and one for a space
        delimiters2 = location + min(strfind(text(location:delimiters1(1)),'$$'));
    %     delimiters3 = location + strfind(text(location:delimiters1(1)),' ');
        field_end_location = min([delimiters1 delimiters2]) - 2;
        parentheses_locations = strfind(text(location:field_end_location),')');
        if ~isempty(parentheses_locations)
            location = location + parentheses_locations(1) + 1;
        end
        value = text(location:field_end_location);

        %If the string is truly a double in char form then convert it to a
        %double:
        num_spaces = sum(double(int16(value) == 32));
        if sum(double(int16(value) >= 45)) == size(value,2) - num_spaces && sum(double(int16(value) <= 57)) == size(value,2) && sum(double(int16(value) == 47)) == 0
            value = str2num(value);
        end
        fieldss.(fields{field_num}) = value;
    end
end