%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


function kspace = resortHOTRARE2windows(kspace)
zq_windows = [1 4 5 8 9 12 13 16 17 20 21 24];
sq_windows = [2 3 6 7 10 11 14 15 18 19 22 23];
zq_windows = zq_windows(1:size(kspace,3)/2);
sq_windows = sq_windows(1:size(kspace,3)/2);

kspace_temp = zeros(size(kspace));

kspace_temp(:,:,1:size(kspace,3)/2,:,:) = kspace(:,:,zq_windows,:,:);
kspace_temp(:,:,size(kspace,3)/2+1:size(kspace,3),:,:) = kspace(:,:,sq_windows,:,:);

kspace = kspace_temp;