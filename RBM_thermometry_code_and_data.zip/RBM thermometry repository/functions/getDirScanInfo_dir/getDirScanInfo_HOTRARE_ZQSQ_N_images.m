%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


function [im,k,t]=getDirScanInfo_HOTRARE_ZQSQ_N_images(directory)

sq_ref_image = 1;

p_m = struct('num_echoes',[],'t1',[],'tau_min',[]);
p_m = getPVEntry3([directory '\method'],p_m);
[zq_windows,sq_windows] = zqsqCoherenceOrder(p_m.num_echoes);


[~,k] = reconstructHOT2DSLI(directory);
k=flipdim(k,4);
k=makeKSpaceMatSquare(k);
[max_row,max_col] = maxRowColIndex(squeeze(k(1,1,2,:,:)));
f_surf_norm = reshape(makeFermiSurface([size(k,4) size(k,5)],[6 6],[1 1],[max_row max_col]),1,1,1,size(k,4),size(k,5));
for timepoint = 1:size(k,1);
    for delay_num=1:size(k,2);
        for zq_echo_num=1:size(zq_windows,2) 
            k(timepoint,delay_num,zq_windows(zq_echo_num),:,:) = k(timepoint,delay_num,zq_windows(zq_echo_num),:,:).*f_surf_norm;
            k(timepoint,delay_num,sq_windows(zq_echo_num),:,:) = k(timepoint,delay_num,sq_windows(zq_echo_num),:,:).*f_surf_norm;
        end
    end
end

% [ky0,kx0]=maxRowColIndex(artificialFourierUpsample(squeeze(abs(k(1,1,1,:,:))),4));

%the following correctly phases alternating echoes in the image domain
im=fftshift(fftshift(ifft(ifft(fftshift(fftshift(k,4),5),[],4),[],5),4),5);
im=artificialFourierUpsample(im,4);
pd = zeros(size(im,1),size(im,2),size(im,3)/2,size(im,4),size(im,5));
for timepoint = 1:size(k,1)
    for delay_num=1:size(k,2)
        for zq_echo_num=1:size(zq_windows,2)
            if mod(zq_echo_num,2) %is odd?
                pd(timepoint,delay_num,zq_echo_num,:,:) = im(timepoint,delay_num,zq_windows(zq_echo_num),:,:).*conj(im(timepoint,delay_num,sq_windows(zq_echo_num),:,:))*exp(1i*pi/2);
            else
%                 pd(timepoint,delay_num,zq_echo_num,:,:) = im(timepoint,delay_num,zq_windows(zq_echo_num),:,:).*conj(im(timepoint,delay_num,sq_windows(zq_echo_num),:,:)*exp(-1i*pi/2));
                pd(timepoint,delay_num,zq_echo_num,:,:) = conj(im(timepoint,delay_num,zq_windows(zq_echo_num),:,:).*conj(im(timepoint,delay_num,sq_windows(zq_echo_num),:,:))*exp(-1i*pi/2));
            end
        end
    end
end
[t,nu]=imagesToTempNT_PD(angle(pd),p_m.t1+p_m.tau_min,'dir',directory);
t=nu;