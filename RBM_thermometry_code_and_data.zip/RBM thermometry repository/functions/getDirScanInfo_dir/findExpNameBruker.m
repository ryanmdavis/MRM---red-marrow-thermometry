%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


function exp_name = findExpNameBruker(directory)
i = strfind(directory,'.');
if ~isempty(i)
    last_dot_ind = i(end);
    slash_ind = strfind(directory(1:last_dot_ind),'\');
    last_slash_ind = slash_ind(end);
    exp_name = directory(last_slash_ind+1:last_dot_ind-1);
else
    exp_name = [];
end
