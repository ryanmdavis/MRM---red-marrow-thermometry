%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


function [s,td] = getDirScanInfo_reconSpectrumPfile(directory)
[s,~,td]=reconGeHotSpectra(directory);

%read scan parameters from header
fields = struct('yres',[],'variable_47',[],'variable_42',0,'variable_48',0,'variable_40',0,'variable_41',0);
fields = getGeHdrEntry(strcat(directory,'_header.txt'),fields);

spect_flag=fields.variable_42;
tau=fields.variable_47;
tau_max=fields.variable_48;
opyres=fields.yres;
oprbw=fields.variable_40;
f1_bw=1e6/((tau_max-tau)/opyres);

%2D iZQC spectrum
f_=figure;
scale_figure=2.5;
pos=get(f_,'OuterPosition');
new_pos=[0 0 scale_figure*pos(3) 1.5*pos(4)];
set(gcf,'OuterPosition',new_pos);
subplot(1,3,1);
display2DSpectrumD(abs(squeeze(s(1,1,1,:,:))),f1_bw,0,f1_bw,oprbw,0,f1_bw);
axis image
title('iZQC spectrum','FontSize',15);

%2D SQC spectrum
subplot(1,3,2);
imagesc(abs(squeeze(s(1,1,2,:,:))));
axis image off
title('Spin Echo spectrum','FontSize',15);

%find 1d indirect spectrum
subplot(1,3,3);


[r,c]=maxRowColIndex(abs(squeeze(s(1,1,1,:,:))));
f1_spect=abs(squeeze(s(1,1,1,:,c)));
bw_f1=1e6*fields.yres/(14000-fields.variable_47);
hz_f1=-0.5*bw_f1:bw_f1/(size(s,4)-1):0.5*bw_f1;
plot(hz_f1,f1_spect/max(f1_spect));
xlabel('frequency (Hz)')
ylabel('intensity (a.u.)');
title('iZQC spectrum)');
set(gca,'FontSize',15);
axis square
xlim([-700 700]);
pos=get(gcf,'OuterPosition');
