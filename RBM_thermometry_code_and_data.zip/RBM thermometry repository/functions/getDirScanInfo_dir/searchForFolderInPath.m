%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


function directory = searchForFolderInPath(DATA_PATH,folder_name)

% DATA_PATH = {'C:\Users\Ryan\Documents\Warren Lab Work\Bruker 7T data',
%             'C:\Ryan MR Data\Data'};
%%%Find the file location of the experiment:
data_path_dir_num = 1;
directory = '';
while strcmp(directory,'') && data_path_dir_num <= size(DATA_PATH,1)
    full_dir = getFullDirFromExpNum(folder_name,DATA_PATH{data_path_dir_num});
    if exist(DATA_PATH{data_path_dir_num},'dir') && ~isempty(full_dir)
        directory = full_dir;
    end
    data_path_dir_num = data_path_dir_num + 1;
end