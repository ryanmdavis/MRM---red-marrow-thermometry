%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


getDirScanInfo('RMD243',[14 15 17 18 20 21 23 24 26 27],'PVM_SpecSWH');

%% line broadening
s3c_36c=exponentialAppodNMRSpect(RMD243_Sc14_spects,4006,20);
s3c_39c=exponentialAppodNMRSpect(RMD243_Sc17_spects,4006,20);
s3c_42c=exponentialAppodNMRSpect(RMD243_Sc20_spects,4006,20);
s3c_45c=exponentialAppodNMRSpect(RMD243_Sc23_spects,4006,20);
s3c_48c=exponentialAppodNMRSpect(RMD243_Sc26_spects,4006,20);

s4d_36c=exponentialAppodNMRSpect(RMD243_Sc15_spects,4006,20);
s4d_39c=exponentialAppodNMRSpect(RMD243_Sc18_spects,4006,20);
s4d_42c=exponentialAppodNMRSpect(RMD243_Sc21_spects,4006,20);
s4d_45c=exponentialAppodNMRSpect(RMD243_Sc24_spects,4006,20);
s4d_48c=exponentialAppodNMRSpect(RMD243_Sc27_spects,4006,20);

frame_size = [1.8 1.8];
fs=13;
ms=8;
lw=2;

norm_factor_3c = max(abs([s3c_36c s3c_39c s3c_42c s3c_45c s3c_48c]));
norm_factor_4d = max(abs([s4d_36c s4d_39c s4d_42c s4d_45c s4d_48c]));

bw=4006.4103;
hz=-bw/2:bw/(size(RMD243_Sc14_spects,2)-1):bw/2;

fat_range_hz=[-300 300];
w_range_hz=[700 1300];

%% methylene data for probe sample 5a
h1=figure
plot(hz,abs(s3c_36c)/norm_factor_3c,'k','LineWidth',lw);
hold on
plot(hz,abs(s3c_39c)/norm_factor_3c,'b','LineWidth',lw);
plot(hz,abs(s3c_42c)/norm_factor_3c,'c','LineWidth',lw);
plot(hz,abs(s3c_45c)/norm_factor_3c,'r','LineWidth',lw);
plot(hz,abs(s3c_48c)/norm_factor_3c,'m','LineWidth',lw);
xlim(fat_range_hz);
ylim([0 1]);
set(gca,'FontSize',fs);
set(gca,'xdir','reverse');
xlabel('frequency (Hz)');
ylabel('intensity (a.u.)');
title('-CH_2- peak, sample 5a');
axis square
legend('T_l_u_x = 35.6\circC','T_l_u_x = 38.5\circC','T_l_u_x = 41.4\circC','T_l_u_x = 44.3\circC','T_l_u_x = 46.9\circC');

%% water data for probe sample 5a
h2=figure
plot(hz,abs(s3c_36c)/norm_factor_3c,'k','LineWidth',lw);
hold on
plot(hz,abs(s3c_39c)/norm_factor_3c,'b','LineWidth',lw);
plot(hz,abs(s3c_42c)/norm_factor_3c,'c','LineWidth',lw);
plot(hz,abs(s3c_45c)/norm_factor_3c,'r','LineWidth',lw);
plot(hz,abs(s3c_48c)/norm_factor_3c,'m','LineWidth',lw);
xlim(w_range_hz);
ylim([0 1]);
set(gca,'FontSize',fs);
set(gca,'xdir','reverse');
xlabel('frequency (Hz)');
ylabel('intensity (a.u.)');
axis square
title('H_2O peak, sample 5a');
legend('T_l_u_x = 35.6\circC','T_l_u_x = 38.5\circC','T_l_u_x = 41.4\circC','T_l_u_x = 44.3\circC','T_l_u_x = 46.9\circC');

%% methylene data for probe sample 5b
h3=figure;
plot(hz,abs(s4d_36c)/norm_factor_4d,'k','LineWidth',lw);
hold on
plot(hz,abs(s4d_39c)/norm_factor_4d,'b','LineWidth',lw);
plot(hz,abs(s4d_42c)/norm_factor_4d,'c','LineWidth',lw);
plot(hz,abs(s4d_45c)/norm_factor_4d,'r','LineWidth',lw);
plot(hz,abs(s4d_48c)/norm_factor_4d,'m','LineWidth',lw);
xlim(fat_range_hz);
ylim([0 1]);
set(gca,'FontSize',fs);
set(gca,'xdir','reverse');
xlabel('frequency (Hz)');
ylabel('intensity (a.u.)');
axis square
title('-CH_2- peak, sample 5b');
legend('T_l_u_x = 35.6\circC','T_l_u_x = 38.5\circC','T_l_u_x = 41.4\circC','T_l_u_x = 44.3\circC','T_l_u_x = 46.9\circC');

%% water data for probe sample 5b
h4=figure;
plot(hz,abs(s4d_36c)/norm_factor_4d,'k','LineWidth',lw);
hold on
plot(hz,abs(s4d_39c)/norm_factor_4d,'b','LineWidth',lw);
plot(hz,abs(s4d_42c)/norm_factor_4d,'c','LineWidth',lw);
plot(hz,abs(s4d_45c)/norm_factor_4d,'r','LineWidth',lw);
plot(hz,abs(s4d_48c)/norm_factor_4d,'m','LineWidth',lw);
xlim(w_range_hz);
ylim([0 1]);
set(gca,'FontSize',fs);
set(gca,'xdir','reverse');
xlabel('frequency (Hz)','FontSize',fs);
ylabel('intensity (a.u.)','FontSize',fs);
axis square
legend('T_l_u_x = 35.6\circC','T_l_u_x = 38.5\circC','T_l_u_x = 41.4\circC','T_l_u_x = 44.3\circC','T_l_u_x = 46.9\circC');
title('H_2O peak, sample 5a');

Figure5_PRESS_sample5a;
h5=figure;
cfun_34_3c_fit = feval(cfun_34_3c,hz);
plot(hz,abs(RMD243_Sc14_spects)/max(abs(RMD243_Sc14_spects)),'k','LineWidth',lw);
hold on
plot(hz,cfun_34_3c_fit/max(abs(RMD243_Sc14_spects)),'r','LineWidth',lw);
axis square
set(gca,'FontSize',fs);
xlabel('frequency (Hz)','FontSize',fs);
ylabel('intensity (a.u.)','FontSize',fs);
set(gca,'xdir','reverse');
title('T_l_u_x=35.6\circC,sample 5a','FontSize',18);
xlim([-500 2000]);
ylim([0 1]);
legend off

%% frequency difference data
v_methylene_3c=v_methylene_3c-v_methylene_3c(1);
v_water_3c=v_water_3c-v_water_3c(1);
v_diff_fit_243_3c=v_diff_fit_243_3c-v_diff_fit_243_3c(1);
T_243=[35.6 38.5 41.4 44.3 46.9];
h6=figure;
plot(T_243,v_methylene_3c,'kx','MarkerSize',ms,'LineWidth',lw);
hold on
plot(T_243,v_water_3c,'ko','MarkerSize',ms,'LineWidth',lw);
plot(T_243,v_diff_fit_243_3c,'k+','MarkerSize',ms,'LineWidth',lw);
axis square
ylabel('\nu(T)-\nu(35.6\circC) (Hz)','FontSize',fs);
set(gca,'FontSize',fs)
xlabel('Temperature (\circC)');
xlim([35 50]);
ylim([-30 90]);
legend('\nu_0_,_f','\nu_0_,_w','\nu_0_,_w-\nu_0_,_f')