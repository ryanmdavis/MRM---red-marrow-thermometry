%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


getDirScanInfo('RMD242',[14 18 23 28 33 38 43]); %need to add Sc43 back in, right now it doesn't recon properly

%load marrow rois
R_marrow=Rois();
R_marrow.loadRois(strcat(path,'ROIs\Figure 5\RMD242 marrow region.roi'));
m_marrow=squeeze(R_marrow.getMasks());

%define parameters for probe ROI
fov=[35 35];
voxel_size=fov(1)/size(RMD242_Sc18_HOT_SLI,5); %in mm/voxel
roi_thickness=1.5;%mm
roi_id=1;%mm
r_inc=round(roi_thickness/voxel_size); %2mm roi thickness 
r_init=round(roi_id/voxel_size); %1.5mm id of roi
r_max=round((2*roi_thickness+roi_id)/voxel_size);
im_size=[128 128];
probe_location=[61 69];

%generate probe ROI
[masks_return,ir_return] = makeRadialMasksC(probe_location(1),probe_location(2),r_inc,r_max,im_size,r_init,m_marrow);
for mask_num=1:size(masks_return,1)
    masks_return(mask_num,:,:)=masks_return(mask_num,:,:).*reshape(m_marrow,1,128,128);
end
R_probe=Rois(masks_return,'input_type','masks');
m_probe=squeeze(R_probe.getMasks());
m_probe=m_probe.*m_marrow;

%generate anatomical image
rare=abs(squeeze(RMD242_Sc14_rare(3,:,:)));
rare=rare/max(max(rare));

%Tair = 34
t34=zeros(1,8);
for ii=1:8
    t34(ii)=sum(sum(squeeze(RMD242_Sc18_HOT_SLI_t(ii,1,1,:,:)).*m_probe))/sum(sum(m_probe));
end

%Tair = 37
t37=zeros(1,8);
for ii=1:8
    t37(ii)=sum(sum(squeeze(RMD242_Sc23_HOT_SLI_t(ii,1,1,:,:)).*m_probe))/sum(sum(m_probe));
end

%Tair = 40
t40=zeros(1,8);
for ii=1:8
    t40(ii)=sum(sum(squeeze(RMD242_Sc28_HOT_SLI_t(ii,1,1,:,:)).*m_probe))/sum(sum(m_probe));
end

%Tair = 43
t43=zeros(1,8);
for ii=1:8
    t43(ii)=sum(sum(squeeze(RMD242_Sc33_HOT_SLI_t(ii,1,1,:,:)).*m_probe))/sum(sum(m_probe));
end

%Tair = 46
t46=zeros(1,8);
for ii=1:8
    t46(ii)=sum(sum(squeeze(RMD242_Sc38_HOT_SLI_t(ii,1,1,:,:)).*m_probe))/sum(sum(m_probe));
end

%Tair = 49
t49=zeros(1,8);
for ii=1:8
    t49(ii)=sum(sum(squeeze(RMD242_Sc43_HOT_SLI_t(ii,1,1,:,:)).*m_probe))/sum(sum(m_probe));
end

figure
subplot(1,2,1);
imagesc(squeeze(abs(RMD242_Sc18_HOT_SLI(1,1,1,:,:))));
axis image off
colormap gray
R_probe.outlineRois('linewidth',2,'color','r');
subplot(1,2,2);
imagesc(squeeze(abs(RMD242_Sc18_HOT_SLI(1,1,2,:,:))));
axis image off
colormap gray
R_probe.outlineRois('linewidth',2,'color','r');
set(gcf,'Name','Sample 4a: ZQSQ-HOT');

%compute v vs T curve:
v_ave_242_3c=[mean(t34) mean(t37) mean(t40) mean(t43) mean(t46) mean(t49)];
v_std_242_3c=[std(t34) std(t37) std(t40) std(t43) std(t46) std(t49)];
lux_T_242_3c=[34.9 37.7 40.8 43.6 46.4 49.4];
f=fittype('m*x+b');
[cfun_242_3c,gof]=fit(lux_T_242_3c',v_ave_242_3c',f);

figure,errorbar(lux_T_242_3c,v_ave_242_3c,v_std_242_3c,'bx','MarkerSize',15);
hold on
plot(cfun_242_3c);
set(gca,'FontSize',15);
xlabel('temperature (\circC)','FontSize',15);
ylabel('iZQC frequency (Hz)','FontSize',15);
set(gcf,'Name','Sample 4a: ZQSQ-HOT');