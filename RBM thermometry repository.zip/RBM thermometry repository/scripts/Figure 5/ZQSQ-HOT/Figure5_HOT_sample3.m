%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


%load ZQSQ-HOT images
getDirScanInfo('RMD236',[5 14 16 18 21 23 25]);

%load marrow rois
R_marrow=Rois();
R_marrow.loadRois(strcat(path,'ROIs\Figure 5\RMD236 marrow region.roi'));
m_marrow=squeeze(R_marrow.getMasks());

%define parameters for probe ROI
fov=[35 35];
voxel_size=fov(1)/size(RMD236_Sc14_HOT_SLI_t,5); %in mm/voxel
roi_thickness=1.5;%mm
roi_id=1;%mm
r_inc=round(roi_thickness/voxel_size); %2mm roi thickness 
r_init=round(roi_id/voxel_size); %1.5mm id of roi
r_max=round((2*roi_thickness+roi_id)/voxel_size);
im_size=[size(RMD236_Sc14_HOT_SLI,4) size(RMD236_Sc14_HOT_SLI,5)];
probe_location=[73 55];

%generate probe ROI
[masks_return,ir_return] = makeRadialMasksC(probe_location(1),probe_location(2),r_inc,r_max,im_size,r_init,m_marrow);
for mask_num=1:size(masks_return,1)
    masks_return(mask_num,:,:)=masks_return(mask_num,:,:).*reshape(m_marrow,1,128,128);
end
R_probe=Rois(masks_return,'input_type','masks');
m_probe=squeeze(R_probe.getMasks());
m_probe=m_probe.*m_marrow;

%Sc15 rare
i5=RMD236_Sc5_rare;
rare5=abs(squeeze(i5(2,:,:)));
rare5=rare5/max(max(rare5));
R_5=Rois();
R_5.loadRois(strcat(path,'ROIs\Figure 5\rare5_luxtron.roi'));

%Sc18 rare
i18=RMD236_Sc18_rare;
rare18=squeeze(i18(2,:,:));
R_18=Rois();

%Tair = 35C
t_14=RMD236_Sc14_HOT_SLI_t;
tt_14=squeeze(t_14(:,1,1,:,:));
t14_avg=mean(R_5.getRoiAvgs(squeeze(t_14(:,1,1,:,:))));
t14_stdev=std(R_5.getRoiAvgs(squeeze(t_14(:,1,1,:,:))));

%Tair = 37C
t_16=RMD236_Sc16_HOT_SLI_t;
tt_16=squeeze(t_16(:,1,1,:,:));
t16_avg=mean(R_5.getRoiAvgs(squeeze(t_16(:,1,1,:,:))));
t16_stdev=std(R_5.getRoiAvgs(squeeze(t_16(:,1,1,:,:))));

%Tair = 39C
t_21=RMD236_Sc21_HOT_SLI_t;
tt_21=squeeze(t_21(:,1,1,:,:));
t21_avg=mean(R_5.getRoiAvgs(squeeze(t_21(:,1,1,:,:))));
t21_stdev=std(R_5.getRoiAvgs(squeeze(t_21(:,1,1,:,:))));

%Tair = 43C
t_23=RMD236_Sc23_HOT_SLI_t;
tt_23=squeeze(t_23(:,1,1,:,:));
t23_avg=mean(R_5.getRoiAvgs(squeeze(t_23(:,1,1,:,:))));
t23_stdev=std(R_5.getRoiAvgs(squeeze(t_23(:,1,1,:,:))));

%Tair = 45C
t_25=RMD236_Sc25_HOT_SLI_t;
tt_25=squeeze(t_25(:,1,1,:,:));
t25_avg=mean(R_5.getRoiAvgs(squeeze(t_25(:,1,1,:,:))));
t25_stdev=std(R_5.getRoiAvgs(squeeze(t_25(:,1,1,:,:))));

v_ave_236=[t14_avg t16_avg t21_avg t23_avg t25_avg];
v_std_236=[t14_stdev t16_stdev t21_stdev t23_stdev t25_stdev];
lux_T_236=[37 39.5 41 42.5 44.4];
f=fittype('m*x+b');
[cfun,gof]=fit(lux_T_236',v_ave_236',f);

figure,errorbar(lux_T_236,v_ave_236,v_std_236,'bx','MarkerSize',15);
hold on
plot(cfun);
set(gca,'FontSize',15);
xlabel('temperature (\circC)','FontSize',15);
ylabel('iZQC frequency (Hz)','FontSize',15);
set(gcf,'Name','sample 3: ZQSQ-HOT')

nu_range=[960 1000];

figure,subplot(2,3,1);
imagesc(squeeze(t_14(1,1,1,:,:)),nu_range);
axis image off
title('T_l_u_x=37\circC','FontSize',15);
R_probe.outlineRois('color','m','LineWidth',2);

subplot(2,3,2);
imagesc(squeeze(t_16(1,1,1,:,:)),nu_range);
axis image off
title('T_l_u_x=39.5\circC','FontSize',15);
R_probe.outlineRois('color','m','linewidth',2);


subplot(2,3,3);
imagesc(squeeze(t_21(1,1,1,:,:)),nu_range);
axis image off
title('T_l_u_x=41.0\circC','FontSize',15);
R_probe.outlineRois('color','m','linewidth',2);


subplot(2,3,4);
imagesc(squeeze(t_23(1,1,1,:,:)),nu_range);
axis image off
title('T_l_u_x=42.4\circC','FontSize',15);
R_probe.outlineRois('color','m','linewidth',2);


subplot(2,3,5);
imagesc(squeeze(t_25(1,1,1,:,:)),nu_range);
axis image off
title('T_l_u_x=44.4\circC','FontSize',15);
R_probe.outlineRois('color','m','linewidth',2);


subplot(2,3,6);
imagesc(ones(64),nu_range);
axis off
colorbar
title('Hz','FontSize',15);
set(gca,'FontSize',15);
set(gcf,'Name','sample 3: ZQSQ-HOT')

% figure,subplot(1,2,1)
% imagesc(squeeze(abs(RMD236_Sc14_HOT_SLI(1,1,1,:,:))));
% axis image off
% title('iZQC magnitude image','FontSize',15);
% subplot(1,2,2);
% imagesc(squeeze(abs(RMD236_Sc14_HOT_SLI(1,1,2,:,:))));
% axis image off
% title('SE magnitude image','FontSize',15);
% colormap gray
figure,imagesc(rare5);
axis image off
colormap gray
R_probe.outlineRois('color','w','linewidth',2);
set(gcf,'Name','sample 3: ZQSQ-HOT')