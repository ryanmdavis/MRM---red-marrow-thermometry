%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


getDirScanInfo('RMD233',[6 9 10 11],'read_FOV','phase_FOV');
R_marrow=Rois();
R_marrow.loadRois(strcat(path,'ROIs\Figure 5\RMD233 marrow region.roi'));
% m=(R.getMasks());
m_marrow=squeeze(R_marrow.getMasks());

%define parameters for probe ROI
fov=[35 35];
voxel_size=fov(1)/size(RMD233_Sc10_HOT_SLI_t,5); %in mm/voxel
roi_thickness=1.5;%mm
roi_id=1;%mm
r_inc=round(roi_thickness/voxel_size); %2mm roi thickness 
r_init=round(roi_id/voxel_size); %1.5mm id of roi
r_max=round((2*roi_thickness+roi_id)/voxel_size);
im_size=[size(RMD233_Sc10_HOT_SLI_t,4) size(RMD233_Sc10_HOT_SLI_t,5)];
probe_location=[68 52];

%generate probe ROI
[masks_return,ir_return] = makeRadialMasksC(probe_location(1),probe_location(2),r_inc,r_max,im_size,r_init,m_marrow);
R_probe=Rois(masks_return,'input_type','masks');
m_probe=squeeze(R_probe.getMasks());
m_probe=m_probe.*m_marrow;

%anatomical image
rare=abs(RMD233_Sc6_rare);
rare=rare/max(max(rare));

%37C
t37=zeros(1,8);
for ii=1:8
    t37(ii)=sum(sum(squeeze(RMD233_Sc9_HOT_SLI_t(ii,1,1,:,:)).*m_probe))/sum(sum(m_probe));
end

%39C
t39=zeros(1,8);
for ii=1:8
    t39(ii)=sum(sum(squeeze(RMD233_Sc10_HOT_SLI_t(ii,1,1,:,:)).*m_probe))/sum(sum(m_probe));
end

%41C
t41=zeros(1,8);
for ii=1:8
    t41(ii)=sum(sum(squeeze(RMD233_Sc11_HOT_SLI_t(ii,1,1,:,:)).*m_probe))/sum(sum(m_probe));
end

lux_T_233 = [36.6 38.6 40.4];
v_ave_233 = [mean(t37) mean(t39) mean(t41)];
v_std_233 = [std(t37) std(t39) std(t41)]/2; %divide by 2 to have the error bar width be the standard deviation
nu_range=[985 1030];

%find precision map
precision = squeeze(std(RMD233_Sc9_HOT_SLI_t,[],1));
m_precision = precision < 2;

marrow_rgb=intensity2RGB(rare,gray,[0 0.8]);
nu_37_rgb=imageToBlackBackgroundB(squeeze(RMD233_Sc9_HOT_SLI_t(1,1,1,:,:)),m_marrow,nu_range,jet);
nu_37=superpose2RGB(nu_37_rgb,marrow_rgb,m_marrow);

nu_39_rgb=imageToBlackBackgroundB(squeeze(RMD233_Sc10_HOT_SLI_t(1,1,1,:,:)),m_marrow,nu_range,jet);
nu_39=superpose2RGB(nu_39_rgb,marrow_rgb,m_marrow);

nu_41_rgb=imageToBlackBackgroundB(squeeze(RMD233_Sc11_HOT_SLI_t(1,1,1,:,:)),m_marrow,nu_range,jet);
nu_41=superpose2RGB(nu_41_rgb,marrow_rgb,m_marrow);



figure,subplot(1,2,2);
errorbar(lux_T_233,v_ave_233,v_std_233,'bo','MarkerSize',14,'LineWidth',2);
set(gca,'FontSize',15);
ft=fittype('m*x+b');
[cfun,gof]=fit(lux_T_233',v_ave_233',ft);
hold on
plot(cfun);
legend('data','linear fit');
xlabel('Fiberoptic measurement (/circC)','FontSize',15);
ylabel('\nu_i_Z_Q_C (Hz)','FontSize',15);

subplot(1,2,1);
imagesc(abs(RMD233_Sc6_rare));
axis image off
R_probe.outlineRois('linewidth',4);
colormap gray
title('T_2-weighted Image','FontSize',15);
set(gcf,'Name','sample 1: ZQSQ-HOT')


figure,subplot(1,3,1);
imagesc(nu_37);
axis image off
R_probe.outlineRois('linewidth',2,'color','w');
title({'frequency map (Hz)','T_l_u_x=36.5\circC'},'FontSize',15);

subplot(1,3,2);
imagesc(nu_39);
axis image off
R_probe.outlineRois('linewidth',2,'color','w');
title({'frequency map (Hz)','T_l_u_x=38.6\circC'},'FontSize',15);

subplot(1,3,3);
imagesc(nu_41);
axis image off
R_probe.outlineRois('linewidth',2,'color','w');
title({'frequency map (Hz)','T_l_u_x=40.4\circC'},'FontSize',15);
set(gcf,'Name','sample 1: ZQSQ-HOT')