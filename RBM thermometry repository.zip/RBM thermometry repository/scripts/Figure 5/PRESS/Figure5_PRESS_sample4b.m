%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


getDirScanInfo('RMD242',[20 25 30 35 40 45]);
T_242=[34.9 37.5 40.8 43.6 46.3 49.4];
bw=4006.4103;
%%%%%%%%%%%%%%%%%%%%%
% Define gaussian fit functions
%%%%%%%%%%%%%%%%%%%%%%
f_gaussian=fittype('a1*exp(-(x-u1)^2/(2*s1^2))+a2*exp(-(x-u2)^2/(2*s2^2))+b');

hz=-bw/2:bw/(size(RMD242_Sc20_spects,2)-1):bw/2;

figure

% 34C
RMD242_Sc20_spects=exponentialAppodNMRSpect(RMD242_Sc20_spects/max(RMD242_Sc20_spects),4006,20);
[cfun_34,gof_34]=fit(hz',abs(RMD242_Sc20_spects)',f_gaussian,'startpoint',[0.2 1 0.04 300 200 0 1050]);
subplot(2,3,1);
plot(hz,abs(RMD242_Sc20_spects));
hold on
plot(cfun_34);
axis square
legend(gca,'hide');
xlabel('frequency (Hz)','FontSize',15);
ylabel('signal (a.u.)','FontSize',15);
set(gca,'xdir','reverse');
title('T_l_u_x=37.0\circC','FontSize',15)
xlim([-500 2000])

% 37C
RMD242_Sc25_spects=exponentialAppodNMRSpect(RMD242_Sc25_spects/max(RMD242_Sc25_spects),4006,20);
[cfun_37,gof_37]=fit(hz',abs(RMD242_Sc25_spects)',f_gaussian,'startpoint',[0.2 1 0.04 300 200 0 1050]);
subplot(2,3,2);
plot(hz,abs(RMD242_Sc25_spects));
hold on
plot(cfun_37);
axis square
legend(gca,'hide');
xlabel('frequency (Hz)','FontSize',15);
ylabel('signal (a.u.)','FontSize',15);
set(gca,'xdir','reverse');
title('T_l_u_x=39.5\circC','FontSize',15)
xlim([-500 2000])

% 40C
RMD242_Sc30_spects=exponentialAppodNMRSpect(RMD242_Sc30_spects/max(RMD242_Sc30_spects),4006,20);
[cfun_40,gof_40]=fit(hz',abs(RMD242_Sc30_spects)',f_gaussian,'startpoint',[0.2 1 0.04 300 200 0 1050]);
subplot(2,3,3);
plot(hz,abs(RMD242_Sc30_spects));
hold on
plot(cfun_40);
axis square
legend(gca,'hide');
xlabel('frequency (Hz)','FontSize',15);
ylabel('signal (a.u.)','FontSize',15);
set(gca,'xdir','reverse');
title('T_l_u_x=41.0\circC','FontSize',15)
xlim([-500 2000])

% 43C
RMD242_Sc35_spects=exponentialAppodNMRSpect(RMD242_Sc35_spects/max(RMD242_Sc35_spects),4006,20);
[cfun_43,gof_43]=fit(hz',abs(RMD242_Sc35_spects)',f_gaussian,'startpoint',[0.2 1 0.04 300 200 0 1050]);
subplot(2,3,4);
plot(hz,abs(RMD242_Sc35_spects));
hold on
plot(cfun_43);
axis square
legend(gca,'hide');
xlabel('frequency (Hz)','FontSize',15);
ylabel('signal (a.u.)','FontSize',15);
set(gca,'xdir','reverse');
title('T_l_u_x=42.4\circC','FontSize',15)
xlim([-500 2000])

% 46C
RMD242_Sc40_spects=exponentialAppodNMRSpect(RMD242_Sc40_spects/max(RMD242_Sc40_spects),4006,20);
[cfun_46,gof_46]=fit(hz',abs(RMD242_Sc40_spects)',f_gaussian,'startpoint',[0.2 1 0.04 300 200 0 1050]);
subplot(2,3,5);
plot(hz,abs(RMD242_Sc40_spects));
hold on
plot(cfun_46);
axis square
legend(gca,'hide');
xlabel('frequency (Hz)','FontSize',15);
ylabel('signal (a.u.)','FontSize',15);
set(gca,'xdir','reverse');
title('T_l_u_x=44.3\circC','FontSize',15)
xlim([-500 2000])

% 49C
RMD242_Sc45_spects=exponentialAppodNMRSpect(RMD242_Sc45_spects/max(RMD242_Sc45_spects),4006,20);
[cfun_49,gof_49]=fit(hz',abs(RMD242_Sc45_spects)',f_gaussian,'startpoint',[0.2 1 0.04 300 200 0 1050]);
subplot(2,3,6);
plot(hz,abs(RMD242_Sc45_spects));
hold on
plot(cfun_49);
axis square
legend(gca,'hide');
xlabel('frequency (Hz)','FontSize',15);
ylabel('signal (a.u.)','FontSize',15);
set(gca,'xdir','reverse');
title('T_l_u_x=44.3\circC','FontSize',15)
xlim([-500 2000])


wci=@(ci)(ci(1,6)-ci(2,6))/2;
mci=@(ci)(ci(1,7)-ci(2,7))/2;
v_methylene=[cfun_34.u1  cfun_37.u1  cfun_40.u1  cfun_43.u1  cfun_46.u1 cfun_49.u1];
v_water=[cfun_34.u2  cfun_37.u2  cfun_40.u2  cfun_43.u2  cfun_46.u2 cfun_49.u2];
v_diff_fit_242_4d=v_water-v_methylene;

v_m_ci=[mci(confint(cfun_34)) mci(confint(cfun_37)) mci(confint(cfun_40)) mci(confint(cfun_43)) mci(confint(cfun_46)) mci(confint(cfun_49))];
v_w_ci=[wci(confint(cfun_34)) wci(confint(cfun_37)) wci(confint(cfun_40)) wci(confint(cfun_43)) wci(confint(cfun_46)) wci(confint(cfun_49))];
v_diff_fit_242_4d_std = (v_m_ci.^2 + v_w_ci.^2).^.5;

figure,subplot(1,3,1);
errorbar(T_242,v_water,v_w_ci,'bx','MarkerSize',14,'LineWidth',2);
set(gca,'FontSize',15);
xlabel('T_l_u_x (\circC)','FontSize',15);
ylabel('\nu_H_2_O (Hz)','FontSize',15);
title('Resonance Frequency of Water');
axis square
subplot(1,3,2);
errorbar(T_242,v_methylene,v_m_ci,'bx','MarkerSize',14,'LineWidth',2);
set(gca,'FontSize',15);

xlabel('T_l_u_x (\circC)','FontSize',15);
ylabel('\nu_f_a_t (Hz)','FontSize',15);
title('Resonance Frequency of Fat');
axis square
subplot(1,3,3);
errorbar(T_242,v_methylene-v_water,v_diff_fit_242_4d_std,'bx','MarkerSize',14,'LineWidth',2);
set(gca,'FontSize',15);
axis square
xlabel('T_l_u_x (\circC)','FontSize',15);
ylabel('\nu_f_a_t - \nu_H_2_O (Hz)','FontSize',15);
title('Resonance Frequency Difference');

set(gcf,'Name','sample 4b: PRESS');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Pick out the maximum of each peak
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[hz1_20,hz2_20] = find2MaxInSpectrum(RMD242_Sc20_spects,[1000 1100],[1500 1600],hz);
[hz1_25,hz2_25] = find2MaxInSpectrum(RMD242_Sc25_spects,[1000 1100],[1500 1600],hz);
[hz1_30,hz2_30] = find2MaxInSpectrum(RMD242_Sc30_spects,[1000 1100],[1500 1600],hz);
[hz1_35,hz2_35] = find2MaxInSpectrum(RMD242_Sc35_spects,[1000 1100],[1500 1600],hz);
[hz1_40,hz2_40] = find2MaxInSpectrum(RMD242_Sc40_spects,[1000 1100],[1500 1600],hz);
[hz1_45,hz2_45] = find2MaxInSpectrum(RMD242_Sc45_spects,[1000 1100],[1500 1600],hz);

v_fat=[hz1_20 hz1_25 hz1_30 hz1_35 hz1_40 hz1_45];
v_w=[hz2_20 hz2_25 hz2_30 hz2_35 hz2_40 hz2_45];
v_diff_max_242_4d=v_fat-v_w;

figure,subplot(1,3,1);
scatter(T_242,v_w);
set(gca,'FontSize',15);
xlabel('T_l_u_x (\circC)','FontSize',15);
ylabel('\nu_H_2_O (Hz)','FontSize',15);
title('Resonance Frequency of Water');
axis square

subplot(1,3,2);
scatter(T_242,v_fat);
set(gca,'FontSize',15);
xlabel('T_l_u_x (\circC)','FontSize',15);
ylabel('\nu_f_a_t (Hz)','FontSize',15);
title('Resonance Frequency of Fat');
axis square

subplot(1,3,3);
scatter(T_242,-v_diff_max_242_4d);
set(gca,'FontSize',15);
axis square
xlabel('T_l_u_x (\circC)','FontSize',15);
ylabel('\nu_H_2_O - \nu_f_a_t (Hz)','FontSize',15);
title('Resonance Frequency Difference');
set(gcf,'Name','sample 4b: PRESS');