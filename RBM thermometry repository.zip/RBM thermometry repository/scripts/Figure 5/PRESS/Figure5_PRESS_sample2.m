%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


getDirScanInfo('RMD234',[4 5 7 10 13 15 17 19 21]);

%%%%%%%%%%%%%%%%%%%%%
% Define gaussian fit functions
%%%%%%%%%%%%%%%%%%%%%%
f_gaussian=fittype('a1*exp(-(x-u1)^2/(2*s1^2))+a2*exp(-(x-u2)^2/(2*s2^2))+b');

hz=-2003.2:4006.4/2047:2003.2;

figure

% 37C
s_37=exponentialAppodNMRSpect(RMD234_Sc7_spects,4006.4,5);
s_37=s_37/max(s_37);
[cfun_37,gof_37]=fit(hz',abs(s_37)',f_gaussian,'startpoint',[0.2 1 0.04 300 200 0 1050]);
subplot(2,4,1);
plot(hz,abs(s_37));
hold on
plot(cfun_37);
axis square
legend(gca,'hide');
xlabel('frequency (Hz)','FontSize',15);
ylabel('signal (a.u.)','FontSize',15);
set(gca,'xdir','reverse');
title('T_l_u_x=36.5\circC','FontSize',15)
xlim([-500 2000])

% 39C
hz_39=-3004.8:6009.6/511:3004.8;
s_39=exponentialAppodNMRSpect(RMD234_Sc10_spects,6009.6,5);
s_39=s_39/max(s_39);
[cfun_39,gof_39]=fit(hz_39',abs(s_39)',f_gaussian,'startpoint',[0.2 1 0.04 300 200 0 1050]);
subplot(2,4,2);
plot(hz_39,abs(s_39));
hold on
plot(cfun_39);
axis square
legend(gca,'hide');
xlabel('frequency (Hz)','FontSize',15);
ylabel('signal (a.u.)','FontSize',15);
set(gca,'xdir','reverse');
title('T_l_u_x=38.7\circC','FontSize',15)
xlim([-500 2000])

% 41C
s_41=exponentialAppodNMRSpect(RMD234_Sc13_spects,4006.4,5);
s_41=s_41/max(s_41);
[cfun_41,gof_41]=fit(hz',abs(s_41)',f_gaussian,'startpoint',[0.2 1 0.04 300 200 0 1050]);
subplot(2,4,3);
plot(hz,abs(s_41));
hold on
plot(cfun_41);
axis square
legend(gca,'hide');
xlabel('frequency (Hz)','FontSize',15);
ylabel('signal (a.u.)','FontSize',15);
set(gca,'xdir','reverse');
title('T_l_u_x=41.3\circC','FontSize',15)
xlim([-500 2000])

% 43C
s_43=exponentialAppodNMRSpect(RMD234_Sc15_spects,4006.4,5);
s_43=s_43/max(s_43);
[cfun_43,gof_43]=fit(hz',abs(s_43)',f_gaussian,'startpoint',[0.2 1 0.04 300 200 0 1050]);
subplot(2,4,4);
plot(hz,abs(s_43));
hold on
plot(cfun_43);
axis square
legend(gca,'hide');
xlabel('frequency (Hz)','FontSize',15);
ylabel('signal (a.u.)','FontSize',15);
set(gca,'xdir','reverse');
title('T_l_u_x=43.2\circC','FontSize',15)
xlim([-500 2000])

% 45C
s_45=exponentialAppodNMRSpect(RMD234_Sc17_spects,4006.4,5);
s_45=s_45/max(s_45);
[cfun_45,gof_45]=fit(hz',abs(s_45)',f_gaussian,'startpoint',[0.2 1 0.04 300 200 0 1050]);
subplot(2,4,5);
plot(hz,abs(s_45));
hold on
plot(cfun_45);
axis square
legend(gca,'hide');
xlabel('frequency (Hz)','FontSize',15);
ylabel('signal (a.u.)','FontSize',15);
set(gca,'xdir','reverse');
title('T_l_u_x=45.7\circC','FontSize',15)
xlim([-500 2000])

% 47C
s_47=exponentialAppodNMRSpect(RMD234_Sc19_spects,4006.4,5);
s_47=s_47/max(s_47);
[cfun_47,gof_47]=fit(hz',abs(s_47)',f_gaussian,'startpoint',[0.2 1 0.04 300 200 0 1050]);
subplot(2,4,6);
plot(hz,abs(s_47));
hold on
plot(cfun_47);
axis square
legend(gca,'hide');
xlabel('frequency (Hz)','FontSize',15);
ylabel('signal (a.u.)','FontSize',15);
set(gca,'xdir','reverse');
title('T_l_u_x=48.0\circC','FontSize',15)
xlim([-500 2000])

% 49C
s_49=exponentialAppodNMRSpect(RMD234_Sc21_spects,4006.4,5);
s_49=s_49/max(s_49);
[cfun_49,gof_49]=fit(hz',abs(s_49)',f_gaussian,'startpoint',[0.2 1 0.04 300 200 0 1050]);
subplot(2,4,7);
plot(hz,abs(s_49));
hold on
plot(cfun_49);
axis square
legend(gca,'hide');
xlabel('frequency (Hz)','FontSize',15);
ylabel('signal (a.u.)','FontSize',15);
set(gca,'xdir','reverse');
title('T_l_u_x=50.5\circC','FontSize',15)
xlim([-500 2000])

wci=@(ci)(ci(1,6)-ci(2,6))/2;
mci=@(ci)(ci(1,7)-ci(2,7))/2;
v_methylene=[cfun_37.u1  cfun_39.u1  cfun_41.u1  cfun_43.u1  cfun_45.u1  cfun_47.u1  cfun_49.u1];
v_water=[cfun_37.u2  cfun_39.u2  cfun_41.u2  cfun_43.u2  cfun_45.u2  cfun_47.u2  cfun_49.u2];
v_diff_fit_234=v_water-v_methylene;
T_234=[mean([36.3 36.6 36.6 36.6]) mean([38.5 38.5 38.8 38.8 38.8 38.9]) mean([41.2 41.2 41.3 41.3 41.3]) mean([43.1 43.3 43.2 43.3]) mean([45.5 45.6 45.7 45.8]) mean([47.7 48.0 48.1 48.1]) mean([50.4 50.5 50.5])];
v_m_ci=[mci(confint(cfun_37)) mci(confint(cfun_39)) mci(confint(cfun_41)) mci(confint(cfun_43)) mci(confint(cfun_45)) mci(confint(cfun_47)) mci(confint(cfun_49))];
v_w_ci=[wci(confint(cfun_37)) wci(confint(cfun_39)) wci(confint(cfun_41)) wci(confint(cfun_43)) wci(confint(cfun_45)) wci(confint(cfun_47)) wci(confint(cfun_49))];
v_diff_fit_234_std = (v_m_ci.^2 + v_w_ci.^2).^.5;

figure,subplot(1,3,1);
errorbar(T_234,v_water,v_w_ci,'bx','MarkerSize',14,'LineWidth',2);
set(gca,'FontSize',15);
xlabel('T_l_u_x (\circC)','FontSize',15);
ylabel('\nu_H_2_O (Hz)','FontSize',15);
title('Resonance Frequency of Water');
axis square
subplot(1,3,2);
errorbar(T_234,v_methylene,v_m_ci,'bx','MarkerSize',14,'LineWidth',2);
set(gca,'FontSize',15);

xlabel('T_l_u_x (\circC)','FontSize',15);
ylabel('\nu_f_a_t (Hz)','FontSize',15);
title('Resonance Frequency of Fat');
axis square
subplot(1,3,3);
errorbar(T_234,v_methylene-v_water,v_diff_fit_234_std,'bx','MarkerSize',14,'LineWidth',2);
set(gca,'FontSize',15);
axis square
xlabel('T_l_u_x (\circC)','FontSize',15);
ylabel('\nu_f_a_t - \nu_H_2_O (Hz)','FontSize',15);
title('Resonance Frequency Difference');

set(gcf,'Name','sample 2: PRESS');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Pick out the maximum of each peak
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[hz1_37,hz2_37] = find2MaxInSpectrum(s_37,[860 1100],[1350 1850],hz);
[hz1_39,hz2_39] = find2MaxInSpectrum(s_39,[210 280],[310 400],hz_39);
[hz1_41,hz2_41] = find2MaxInSpectrum(s_41,[860 1100],[1350 1850],hz);
[hz1_43,hz2_43] = find2MaxInSpectrum(s_43,[860 1100],[1350 1850],hz);
[hz1_45,hz2_45] = find2MaxInSpectrum(s_45,[860 1100],[1350 1850],hz);
[hz1_47,hz2_47] = find2MaxInSpectrum(s_47,[860 1100],[1350 1850],hz);
[hz1_49,hz2_49] = find2MaxInSpectrum(s_49,[860 1100],[1350 1850],hz);

v_fat=[hz1_37 hz1_39 hz1_41 hz1_43 hz1_45 hz1_47 hz1_49];
v_w=[hz2_37 hz2_39 hz2_41 hz2_43 hz2_45 hz2_47 hz2_49];
v_diff_max_234=v_fat-v_water;

figure,subplot(1,3,1);
scatter(T_234,v_w);
set(gca,'FontSize',15);
xlabel('T_l_u_x (\circC)','FontSize',15);
ylabel('\nu_H_2_O (Hz)','FontSize',15);
title('Resonance Frequency of Water');
axis square

subplot(1,3,2);
scatter(T_234,v_fat);
set(gca,'FontSize',15);
xlabel('T_l_u_x (\circC)','FontSize',15);
ylabel('\nu_f_a_t (Hz)','FontSize',15);
title('Resonance Frequency of Fat');
axis square

subplot(1,3,3);
scatter(T_234,v_diff_max_234);
set(gca,'FontSize',15);
axis square
xlabel('T_l_u_x (\circC)','FontSize',15);
ylabel('\nu_f_a_t - \nu_H_2_O (Hz)','FontSize',15);
title('Resonance Frequency Difference');

set(gcf,'Name','sample 2: PRESS');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Anatomical images
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure,subplot(1,2,1);
imagesc(RMD234_Sc4_rare);
axis image off
title('Coronal T_2-weighted image','FontSize',15);

subplot(1,2,2);
imagesc(RMD234_Sc5_rare);
axis image off
colormap gray
title('Axial T_2-weighted image','FontSize',15);

set(gcf,'Name','sample 2: PRESS');