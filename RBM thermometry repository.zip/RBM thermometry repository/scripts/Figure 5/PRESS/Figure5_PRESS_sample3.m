%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


getDirScanInfo('RMD236',[13 15 20 22 24]);
T_236=[37 39.5 41 42.6 44.4];
%%%%%%%%%%%%%%%%%%%%%
% Define gaussian fit functions
%%%%%%%%%%%%%%%%%%%%%%
f_gaussian=fittype('a1*exp(-(x-u1)^2/(2*s1^2))+a2*exp(-(x-u2)^2/(2*s2^2))+b');

hz=-4006.42:8012.82/511:4006.42;

figure

% 35C
RMD236_Sc13_spects=RMD236_Sc13_spects/max(RMD236_Sc13_spects);
[cfun_37,gof_37]=fit(hz',abs(RMD236_Sc13_spects)',f_gaussian,'startpoint',[0.2 1 0.04 300 200 0 1050]);
subplot(2,3,1);
plot(hz,abs(RMD236_Sc13_spects));
hold on
plot(cfun_37);
axis square
legend(gca,'hide');
xlabel('frequency (Hz)','FontSize',15);
ylabel('signal (a.u.)','FontSize',15);
set(gca,'xdir','reverse');
title('T_l_u_x=37.0\circC','FontSize',15)
xlim([-500 2000])

% 37C
hz_39=-3004.8:6009.6/511:3004.8;
RMD236_Sc15_spects=RMD236_Sc15_spects/max(RMD236_Sc15_spects);
[cfun_39,gof_39]=fit(hz_39',abs(RMD236_Sc15_spects)',f_gaussian,'startpoint',[0.2 1 0.04 300 200 0 1050]);
subplot(2,3,2);
plot(hz_39,abs(RMD236_Sc15_spects));
hold on
plot(cfun_39);
axis square
legend(gca,'hide');
xlabel('frequency (Hz)','FontSize',15);
ylabel('signal (a.u.)','FontSize',15);
set(gca,'xdir','reverse');
title('T_l_u_x=39.5\circC','FontSize',15)
xlim([-500 2000])

% 39C
RMD236_Sc20_spects=RMD236_Sc20_spects/max(RMD236_Sc20_spects);
[cfun_41,gof_41]=fit(hz',abs(RMD236_Sc20_spects)',f_gaussian,'startpoint',[0.2 1 0.04 300 200 0 1050]);
subplot(2,3,3);
plot(hz,abs(RMD236_Sc20_spects));
hold on
plot(cfun_41);
axis square
legend(gca,'hide');
xlabel('frequency (Hz)','FontSize',15);
ylabel('signal (a.u.)','FontSize',15);
set(gca,'xdir','reverse');
title('T_l_u_x=41.0\circC','FontSize',15)
xlim([-500 2000])

% 43C
RMD236_Sc22_spects=RMD236_Sc22_spects/max(RMD236_Sc22_spects);
[cfun_43,gof_43]=fit(hz',abs(RMD236_Sc22_spects)',f_gaussian,'startpoint',[0.2 1 0.04 300 200 0 1050]);
subplot(2,3,4);
plot(hz,abs(RMD236_Sc22_spects));
hold on
plot(cfun_43);
axis square
legend(gca,'hide');
xlabel('frequency (Hz)','FontSize',15);
ylabel('signal (a.u.)','FontSize',15);
set(gca,'xdir','reverse');
title('T_l_u_x=42.4\circC','FontSize',15)
xlim([-500 2000])

% 45C
RMD236_Sc24_spects=RMD236_Sc24_spects/max(RMD236_Sc24_spects);
[cfun_45,gof_45]=fit(hz',abs(RMD236_Sc24_spects)',f_gaussian,'startpoint',[0.2 1 0.04 300 200 0 1050]);
subplot(2,3,5);
plot(hz,abs(RMD236_Sc24_spects));
hold on
plot(cfun_45);
axis square
legend(gca,'hide');
xlabel('frequency (Hz)','FontSize',15);
ylabel('signal (a.u.)','FontSize',15);
set(gca,'xdir','reverse');
title('T_l_u_x=44.3\circC','FontSize',15)
xlim([-500 2000])

set(gcf,'Name','sample 3: PRESS');


wci=@(ci)(ci(1,6)-ci(2,6))/2;
mci=@(ci)(ci(1,7)-ci(2,7))/2;
v_methylene=[cfun_37.u1  cfun_39.u1  cfun_41.u1  cfun_43.u1  cfun_45.u1];
v_water=[cfun_37.u2  cfun_39.u2  cfun_41.u2  cfun_43.u2  cfun_45.u2];
v_diff_fit_236=v_water-v_methylene;

v_m_ci=[mci(confint(cfun_37)) mci(confint(cfun_39)) mci(confint(cfun_41)) mci(confint(cfun_43)) mci(confint(cfun_45))];
v_w_ci=[wci(confint(cfun_37)) wci(confint(cfun_39)) wci(confint(cfun_41)) wci(confint(cfun_43)) wci(confint(cfun_45))];
v_diff_fit_236_std = (v_m_ci.^2 + v_w_ci.^2).^.5;

figure,subplot(1,3,1);
errorbar(T_236,v_water,v_w_ci,'bx','MarkerSize',14,'LineWidth',2);
set(gca,'FontSize',15);
xlabel('T_l_u_x (\circC)','FontSize',15);
ylabel('\nu_H_2_O (Hz)','FontSize',15);
title('Resonance Frequency of Water');
axis square

subplot(1,3,2);
errorbar(T_236,v_methylene,v_m_ci,'bx','MarkerSize',14,'LineWidth',2);
set(gca,'FontSize',15);
xlabel('T_l_u_x (\circC)','FontSize',15);
ylabel('\nu_f_a_t (Hz)','FontSize',15);
title('Resonance Frequency of Fat');
axis square

subplot(1,3,3);
errorbar(T_236,v_diff_fit_236,v_diff_fit_236_std,'bx','MarkerSize',14,'LineWidth',2);
set(gca,'FontSize',15);
axis square
xlabel('T_l_u_x (\circC)','FontSize',15);
ylabel('\nu_f_a_t - \nu_H_2_O (Hz)','FontSize',15);
title('Resonance Frequency Difference');

set(gcf,'Name','sample 2: PRESS');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Pick out the maximum of each peak
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[hz1_13,hz2_13] = find2MaxInSpectrum(RMD236_Sc13_spects,[200 300],[301 400],hz);
[hz1_15,hz2_15] = find2MaxInSpectrum(RMD236_Sc15_spects,[200 300],[301 400],hz);
[hz1_20,hz2_20] = find2MaxInSpectrum(RMD236_Sc20_spects,[200 300],[301 400],hz);
[hz1_22,hz2_22] = find2MaxInSpectrum(RMD236_Sc22_spects,[200 300],[301 400],hz);
[hz1_24,hz2_24] = find2MaxInSpectrum(RMD236_Sc24_spects,[200 300],[301 400],hz);


v_fat=[hz1_13 hz1_15 hz1_20 hz1_22 hz1_24];
v_w=[hz2_13 hz2_15 hz2_20 hz2_22 hz2_24];
v_diff_max_236=v_fat-v_w;
T_236=[37 39.5 41 42.6 44.4];

figure,subplot(1,3,1);
scatter(T_236,v_w);
set(gca,'FontSize',15);
xlabel('T_l_u_x (\circC)','FontSize',15);
ylabel('\nu_H_2_O (Hz)','FontSize',15);
title('Resonance Frequency of Water');
axis square

subplot(1,3,2);
scatter(T_236,v_fat);
set(gca,'FontSize',15);
xlabel('T_l_u_x (\circC)','FontSize',15);
ylabel('\nu_f_a_t (Hz)','FontSize',15);
title('Resonance Frequency of Fat');
axis square

subplot(1,3,3);
scatter(T_236,-v_diff_max_236);
set(gca,'FontSize',15);
axis square
xlabel('T_l_u_x (\circC)','FontSize',15);
ylabel('\nu_H_2_O - \nu_f_a_t (Hz)','FontSize',15);
title('Resonance Frequency Difference');

set(gcf,'Name','sample 2: PRESS');