%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


getDirScanInfo('RMD243',[14 17 20 23 26]);
T_243=[35.6 38.5 41.4 44.3 46.9];
bw=4006.4103;
%%%%%%%%%%%%%%%%%%%%%
% Define gaussian fit functions
%%%%%%%%%%%%%%%%%%%%%%
f_gaussian=fittype('a1*exp(-(x-u1)^2/(2*s1^2))+a2*exp(-(x-u2)^2/(2*s2^2))+b');

hz=-bw/2:bw/(size(RMD243_Sc14_spects,2)-1):bw/2;

sp=[1 1 0.04 300 200 -50 1050];

figure
% 36C
RMD243_Sc14_spects=exponentialAppodNMRSpect(RMD243_Sc14_spects/max(RMD243_Sc14_spects),4006,20);
[cfun_34_3c,gof_34]=fit(hz',abs(RMD243_Sc14_spects)',f_gaussian,'startpoint',sp);
subplot(2,3,1);
plot(hz,abs(RMD243_Sc14_spects));
hold on
plot(cfun_34_3c);
axis square
legend(gca,'hide');
xlabel('frequency (Hz)','FontSize',15);
ylabel('signal (a.u.)','FontSize',15);
set(gca,'xdir','reverse');
title('T_l_u_x=37.0\circC','FontSize',15);
xlim([-500 2000]);

% 39C
RMD243_Sc17_spects=exponentialAppodNMRSpect(RMD243_Sc17_spects/max(RMD243_Sc17_spects),4006,20);
[cfun_37,gof_37]=fit(hz',abs(RMD243_Sc17_spects)',f_gaussian,'startpoint',sp);
subplot(2,3,2);
plot(hz,abs(RMD243_Sc17_spects));
hold on
plot(cfun_37);
axis square
legend(gca,'hide');
xlabel('frequency (Hz)','FontSize',15);
ylabel('signal (a.u.)','FontSize',15);
set(gca,'xdir','reverse');
title('T_l_u_x=39.5\circC','FontSize',15)
xlim([-500 2000])

% 42C
RMD243_Sc20_spects=exponentialAppodNMRSpect(RMD243_Sc20_spects/max(RMD243_Sc20_spects),4006,20);
[cfun_40,gof_40]=fit(hz',abs(RMD243_Sc20_spects)',f_gaussian,'startpoint',sp);
subplot(2,3,3);
plot(hz,abs(RMD243_Sc20_spects));
hold on
plot(cfun_40);
axis square
legend(gca,'hide');
xlabel('frequency (Hz)','FontSize',15);
ylabel('signal (a.u.)','FontSize',15);
set(gca,'xdir','reverse');
title('T_l_u_x=41.0\circC','FontSize',15)
xlim([-500 2000])

% 45C
RMD243_Sc23_spects=exponentialAppodNMRSpect(RMD243_Sc23_spects/max(RMD243_Sc23_spects),4006,20);
[cfun_43,gof_43]=fit(hz',abs(RMD243_Sc23_spects)',f_gaussian,'startpoint',sp);
subplot(2,3,4);
plot(hz,abs(RMD243_Sc23_spects));
hold on
plot(cfun_43);
axis square
legend(gca,'hide');
xlabel('frequency (Hz)','FontSize',15);
ylabel('signal (a.u.)','FontSize',15);
set(gca,'xdir','reverse');
title('T_l_u_x=42.4\circC','FontSize',15)
xlim([-500 2000])

% 48C
RMD243_Sc26_spects=exponentialAppodNMRSpect(RMD243_Sc26_spects/max(RMD243_Sc26_spects),4006,20);
[cfun_46,gof_46]=fit(hz',abs(RMD243_Sc26_spects)',f_gaussian,'startpoint',sp);
subplot(2,3,5);
plot(hz,abs(RMD243_Sc26_spects));
hold on
plot(cfun_46);
axis square
legend(gca,'hide');
xlabel('frequency (Hz)','FontSize',15);
ylabel('signal (a.u.)','FontSize',15);
set(gca,'xdir','reverse');
title('T_l_u_x=44.3\circC','FontSize',15)
xlim([-500 2000])

set(gcf,'Name','sample 5a: PRESS');

wci=@(ci)(ci(1,6)-ci(2,6))/2;
mci=@(ci)(ci(1,7)-ci(2,7))/2;
v_methylene_3c=[cfun_34_3c.u1  cfun_37.u1  cfun_40.u1  cfun_43.u1  cfun_46.u1];
v_water_3c=[cfun_34_3c.u2  cfun_37.u2  cfun_40.u2  cfun_43.u2  cfun_46.u2];
v_diff_fit_243_3c=v_water_3c-v_methylene_3c;

v_m_ci=[mci(confint(cfun_34_3c)) mci(confint(cfun_37)) mci(confint(cfun_40)) mci(confint(cfun_43)) mci(confint(cfun_46))];
v_w_ci=[wci(confint(cfun_34_3c)) wci(confint(cfun_37)) wci(confint(cfun_40)) wci(confint(cfun_43)) wci(confint(cfun_46))];
v_diff_fit_243_3c_std = (v_m_ci.^2 + v_w_ci.^2).^.5;

figure,subplot(1,3,1);
errorbar(T_243,v_water_3c,v_w_ci,'bx','MarkerSize',14,'LineWidth',2);
set(gca,'FontSize',15);
xlabel('T_l_u_x (\circC)','FontSize',15);
ylabel('\nu_H_2_O (Hz)','FontSize',15);
title('Resonance Frequency of Water');
axis square
subplot(1,3,2);
errorbar(T_243,v_methylene_3c,v_m_ci,'bx','MarkerSize',14,'LineWidth',2);
set(gca,'FontSize',15);

xlabel('T_l_u_x (\circC)','FontSize',15);
ylabel('\nu_f_a_t (Hz)','FontSize',15);
title('Resonance Frequency of Fat');
axis square
subplot(1,3,3);
errorbar(T_243,v_methylene_3c-v_water_3c,v_diff_fit_243_3c_std,'bx','MarkerSize',14,'LineWidth',2);
set(gca,'FontSize',15);
axis square
xlabel('T_l_u_x (\circC)','FontSize',15);
ylabel('\nu_f_a_t - \nu_H_2_O (Hz)','FontSize',15);
title('Resonance Frequency Difference');

set(gcf,'Name','sample 5a: PRESS');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Pick out the maximum of each peak
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[hz1_15,hz2_15] = find2MaxInSpectrum(RMD243_Sc14_spects,[1000 1100],[1500 1600],hz);
[hz1_18,hz2_18] = find2MaxInSpectrum(RMD243_Sc17_spects,[1000 1100],[1500 1600],hz);
[hz1_21,hz2_21] = find2MaxInSpectrum(RMD243_Sc20_spects,[1000 1100],[1500 1600],hz);
[hz1_24,hz2_24] = find2MaxInSpectrum(RMD243_Sc23_spects,[1000 1100],[1500 1600],hz);
[hz1_27,hz2_27] = find2MaxInSpectrum(RMD243_Sc26_spects,[1000 1100],[1500 1600],hz);

v_fat_243_3c=[hz1_15 hz1_18 hz1_21 hz1_24 hz1_27];
v_w_243_3c=[hz2_15 hz2_18 hz2_21 hz2_24 hz2_27];
v_diff_max_243_3c=v_fat_243_3c-v_w_243_3c;

figure,subplot(1,3,1);
scatter(T_243,v_w_243_3c);
set(gca,'FontSize',15);
xlabel('T_l_u_x (\circC)','FontSize',15);
ylabel('\nu_H_2_O (Hz)','FontSize',15);
title('Resonance Frequency of Water');
axis square

subplot(1,3,2);
scatter(T_243,v_fat_243_3c);
set(gca,'FontSize',15);
xlabel('T_l_u_x (\circC)','FontSize',15);
ylabel('\nu_f_a_t (Hz)','FontSize',15);
title('Resonance Frequency of Fat');
axis square

subplot(1,3,3);
scatter(T_243,-v_diff_max_243_3c);
set(gca,'FontSize',15);
axis square
xlabel('T_l_u_x (\circC)','FontSize',15);
ylabel('\nu_H_2_O - \nu_f_a_t (Hz)','FontSize',15);
title('Resonance Frequency Difference');
set(gcf,'Name','sample 5a: PRESS');