%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


%%%%%%%%%%%%%%%%%%%%%%%%%
% RMD179 - Sc 22 - ZQSQ
%%%%%%%%%%%%%%%%%%%%%%%%%
getDirScanInfo('RMD179','tau_inc','tau_min','tau_max','PVM_SpecSWH',22)
f1_proj = sum(abs(RMD179_Sc22_HOT_SLI(1,:,:)),3);
f1_proj = f1_proj - mean(f1_proj(1:300));
f1_bw = 1/(.020/255);
f1_hz = -0.5*f1_bw:f1_bw/1023:0.5*f1_bw;
figure,plot(f1_hz,f1_proj);
title('RMD179 Sc22');
figure,display2DSpectrumD(abs(squeeze(RMD179_Sc22_HOT_SLI(1,:,:))),f1_bw,0,4000,33001,0,4000);
title('RMD179 Sc22');
caxis([0 5e5])
axis square

%%%%%%%%%%%%%%%%%%%%%%%%%%
% RMD177 - Sc13 - HOT 2D - 1win
%%%%%%%%%%%%%%%%%%%%%%%%%%
getDirScanInfo('RMD177','tau_min','tau_max','tau_inc',13)
f1_proj = sum(abs(RMD177_Sc13_HOTspects),2);
f1_proj = f1_proj - mean(f1_proj(1:300));
f2_proj = sum(abs(RMD177_Sc13_HOTspects(340:369,:)),1);
f2_proj = f2_proj - mean(f2_proj(1:200));
f1_bw = 1/(.020/127);
f2_bw = 256/0.052;
f1_hz = -0.5*f1_bw:f1_bw/1023:0.5*f1_bw;
f2_hz = -0.5*f2_bw:f2_bw/2047:0.5*f2_bw;
figure,subplot(1,2,1)
plot(f1_hz,f1_proj/1.72e7);
set(gca,'FontSize',15)
xlabel('evolution frequency (Hz)')
ylabel('signal intensity');
xlim([-2000 500]);
title('Inirect Spectrum - RMD177 Sc13')
subplot(1,2,2)
plot(f2_hz,f2_proj/max(f2_proj))
set(gca,'FontSize',15)
xlabel('evolution frequency (Hz)')
ylabel('signal intensity');
title('Direct Spectrum - RMD177 Sc13')
xlim([-2000 500]);
title('RMD177 Sc13');
figure,display2DSpectrumD(abs(RMD177_Sc13_HOTspects),f1_bw,0,4000,f2_bw,0,4000);
caxis([0 10e4]);
title('RMD177 Sc13');
axis square

%%%%%%%%%%%%%%%%%%%%%%%%%%
% RMD176 - Sc18 - HOT 2D - 1win
%%%%%%%%%%%%%%%%%%%%%%%%%%
getDirScanInfo('RMD176','tau_min','tau_max','tau_inc',18)
f1_proj = sum(abs(RMD176_Sc18_HOTspects),2);
f1_proj = f1_proj - mean(f1_proj(1:100));
f2_proj = sum(abs(RMD176_Sc18_HOTspects(233:298,:)),1);
f2_proj = f2_proj - mean(f2_proj(1:100));
f1_bw = 1/(.030/127);
f2_bw = 256/0.0512;
f1_hz = -0.5*f1_bw:f1_bw/1023:0.5*f1_bw;
f2_hz = -0.5*f2_bw:f2_bw/2047:0.5*f2_bw;
figure,subplot(1,2,1)
plot(f1_hz,f1_proj/3.788e7);
set(gca,'FontSize',15)
xlabel('evolution frequency (Hz)')
ylabel('signal intensity');
xlim([-2000 500]);
title('Indirect Spectrum - RMD176 Sc18')
subplot(1,2,2)
plot(hz2_RMD176_Sc18,f2_proj/max(f2_proj))
set(gca,'FontSize',15)
xlabel('evolution frequency (Hz)')
ylabel('signal intensity');
title('Direct Spectrum - RMD176 Sc18')
xlim([-2000 500]);
figure,display2DSpectrumD(abs(RMD176_Sc18_HOTspects),f1_bw,0,4000,f2_bw,0,4000);
caxis([0 4e5]);
title('RMD176 Sc18');
axis square

%%%%%%%%%%%%%%%%%%%%%%%%%%
% RMD176 - Sc10 - HOT 2D - 1win
%%%%%%%%%%%%%%%%%%%%%%%%%%
getDirScanInfo('RMD176','tau_min','tau_max','tau_inc','PVM_SpecMatrix','PVM_SpecAcquisitionTime',10)
f1_proj = sum(abs(RMD176_Sc10_HOTspects),2);
f1_proj = f1_proj - mean(f1_proj(1:100));
f2_proj = sum(abs(RMD176_Sc10_HOTspects(233:298,:)),1);
f2_proj = f2_proj - mean(f2_proj(1:100));
f1_bw = 1/(.030/127);
f2_bw = 256/0.0512;
f1_hz = -0.5*f1_bw:f1_bw/1023:0.5*f1_bw;
f2_hz = -0.5*f2_bw:f2_bw/2047:0.5*f2_bw;
figure,subplot(1,2,1)
plot(f1_hz,f1_proj/4.64e7);
set(gca,'FontSize',15)
xlabel('evolution frequency (Hz)')
ylabel('signal intensity');
xlim([-2000 500]);
title('Indirect Spectrum - RMD176 Sc10')
subplot(1,2,2)
plot(hz2_RMD176_Sc10,f2_proj/max(f2_proj))
set(gca,'FontSize',15)
xlabel('evolution frequency (Hz)')
ylabel('signal intensity');
title('Direct Spectrum - RMD176 Sc10')
xlim([-2000 500]);
figure,display2DSpectrumD(abs(RMD176_Sc10_HOTspects),f1_bw,0,4000,f2_bw,0,4000);
caxis([0 4e5]);
title('RMD176 Sc10');
axis square

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% RMD 174 - Sc9
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

getDirScanInfo('RMD174','tau_min','tau_max','tau_inc','PVM_SpecMatrix','PVM_SpecAcquisitionTime',9)
f1_proj = sum(abs(RMD174_Sc9_HOTspects),2);
f1_proj = f1_proj - mean(f1_proj(1:100));
f2_proj = sum(abs(RMD174_Sc9_HOTspects(149:224,:)),1);
f2_proj = f2_proj - mean(f2_proj(1:100));
f1_bw = 1/(.040/127);
f2_bw = 256/0.0512;
f1_hz = -0.5*f1_bw:f1_bw/1023:0.5*f1_bw;
f2_hz = -0.5*f2_bw:f2_bw/1023:0.5*f2_bw;
figure,subplot(1,2,1)
plot(f1_hz,f1_proj/2.8e9);
axis square
set(gca,'FontSize',15)
xlabel('evolution frequency (Hz)')
ylabel('signal intensity');
xlim([-2000 500]);
title('Indirect Spectrum - RMD174 Sc9')
subplot(1,2,2)
plot(f2_hz,f2_proj/max(f2_proj))
axis square
set(gca,'FontSize',15)
xlabel('evolution frequency (Hz)')
ylabel('signal intensity');
title('Direct Spectrum - RMD174 Sc9')
xlim([-2000 500]);
figure,display2DSpectrumD(abs(RMD174_Sc9_HOTspects),f1_bw,0,4000,f2_bw,0,4000);
caxis([0 4e7]);
title('RMD174 Sc9');
axis square

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% RMD 172 - Sc40
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

getDirScanInfo('RMD172','tau_min','tau_max','tau_inc','PVM_SpecMatrix','PVM_SpecAcquisitionTime',40)
f1_proj = sum(abs(RMD172_Sc40_HOTspects),2);
f1_proj = f1_proj - mean(f1_proj(1:100));
f2_proj = sum(abs(RMD172_Sc40_HOTspects(662:752,:)),1);
f2_proj = f2_proj - mean(f2_proj(1:100));
f1_bw = 1/(.040/255);
f2_bw = 256/0.0512;
f1_hz = -0.5*f1_bw:f1_bw/2047:0.5*f1_bw;
f2_hz = -0.5*f2_bw:f2_bw/2047:0.5*f2_bw;
figure,subplot(1,2,1)
plot(f1_hz,f1_proj/1.71e7);
axis square
set(gca,'FontSize',15)
xlabel('evolution frequency (Hz)')
ylabel('signal intensity');
xlim([-2000 500]);
title('Indirect Spectrum')
subplot(1,2,2)
plot(hz2_RMD172_Sc40,f2_proj/max(f2_proj))
axis square
set(gca,'FontSize',15)
xlabel('evolution frequency (Hz)')
ylabel('signal intensity');
title('Direct Spectrum - mw peak only')
xlim([-2000 500]);

figure,display2DSpectrumD(abs(RMD172_Sc40_HOTspects),f1_bw,0,4000,f2_bw,0,4000);
caxis([0 4e5]);
title('RMD172 Sc40');
axis square

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% RMD230 Sc91
%%%%%%%%%%%%%%%%%%%%%%%%%%%
getDirScanInfo('RMD230',91,'tau_inc','tau_min','tau_max');
f2_spect=mean(abs(RMD230_Sc91_HOTspects(65:210,:)),1);
f1_spect=mean(abs(RMD230_Sc91_HOTspects(:,110:160)),2);
bw_f1=48/0.01;
bw_f2=5000;
hz_f1=-0.5*bw_f1:bw_f1/383:0.5*bw_f1;
hz_f2=-0.5*bw_f2:bw_f2/255:0.5*bw_f2;
figure,subplot(1,2,1);
plot(hz_f1,f1_spect/(1.943e4*1.364));
axis square
xlabel('resonance frequency (hz)','FontSize',15);
title('indirectly detected spectrum - RMD230 Sc91','FontSize',15);
subplot(1,2,2);
plot(hz_f2,f2_spect/(2.637e4*1.364));
axis square
xlabel('resonance frequency (hz)','FontSize',15);
title('directly detected spectrum - RMD230 Sc91','FontSize',15);

figure,display2DSpectrumD(abs(RMD230_Sc91_HOTspects),f1_bw,0,4000,f2_bw,0,4000);
caxis([0 2e4]);
title('RMD230 Sc91');
axis square

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%RMD231 Sc10
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
getDirScanInfo('RMD231',10,'tau_inc','tau_min','tau_max');
f2_spect=mean(abs(RMD231_Sc10_HOTspects(65:210,:)),1);
f1_spect=mean(abs(RMD231_Sc10_HOTspects(:,110:160)),2);
bw_f1=48/0.01;
bw_f2=5000;
hz_f1=-0.5*bw_f1:bw_f1/383:0.5*bw_f1;
hz_f2=-0.5*bw_f2:bw_f2/255:0.5*bw_f2;
figure,subplot(1,2,1);
plot(hz_f1,f1_spect/(1.943e4*1.364*1.048));
axis square
xlabel('resonance frequency (hz)','FontSize',15);
title('indirectly detected spectrum - RMD231 Sc10','FontSize',15);
subplot(1,2,2);
plot(hz_f2,f2_spect/(2.637e4*1.364*1.08));
axis square
xlabel('resonance frequency (hz)','FontSize',15);
title('directly detected spectrum - RMD231 Sc10','FontSize',15);

figure,display2DSpectrumD(abs(RMD231_Sc10_HOTspects),f1_bw,0,4000,f2_bw,0,4000);
caxis([0 2e4]);
title('RMD231 Sc10');
axis square

figure
% subplot(1,2,1)
fwhm_f1 =  [184 207 170 146 150 190 150 192 209 211];
fwhm_f2 = [279 210 206 394 112 673 NaN 380 326 327];
fwhm_f2_ttest = fwhm_f2([1:6 8:10]);
fwhm_f1_ttest = fwhm_f1([1:6 8:10]);
fwhm = [fwhm_f1;fwhm_f2]';
ivar = ones(10,2);
ivar(:,2) = 2;
boxplot(fwhm,'labels',{'/nu_1','/nu_2'},'widths',0.8,'whisker',20,'colors','kk');
set(gca,'FontSize',19);
hold on
scatter(ivar(:,1),fwhm(:,1),'kx','SizeData',150,'LineWidth',2)
scatter(ivar(:,2),fwhm(:,2),'kx','SizeData',150,'LineWidth',2)
set(gca,'FontSize',19);
ylabel('FWHM (Hz)')

figure,plot(1,1);
xlabel('\nu_1 \nu_2  Hz','FontSize',15);
ylabel('\nu_1 (Hz)','FontSize',15);

% subplot(1,2,2)
figure
fwhm_ratio = fwhm_f2./fwhm_f1;
boxplot(fwhm_ratio,'widths',1)
hold on
scatter(ivar(:,1),fwhm_ratio)
ylabel('FWHM_F_2/FWHM_F_1 (unitless)','FontSize',15);
set(gca,'FontSize',15)
[h,p]=ttest(fwhm_f2_ttest,fwhm_f1_ttest,'tail','both')
[h,p]=ttest(fwhm_f2_ttest,fwhm_f1_ttest,'tail','both');