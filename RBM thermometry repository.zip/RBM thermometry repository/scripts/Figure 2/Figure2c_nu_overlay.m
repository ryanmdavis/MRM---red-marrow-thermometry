%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% put the location of the downloaded "RBM thermometry repository" here:
path='C:\Users\Aspect\Dropbox\RBM thermometry repository\'; 
if ~strcmp(path(end),'\') path = strcat(path,'\'); end %path should end with a slash

getDirScanInfo('RMD238',[3 21]);
fs=18;

%% change recon matrix size of anatomical (RARE) image
rare=squeeze(abs(RMD238_Sc3_rare(2,:,:)));
rare=artificialFourierUpsample(rare,0.5);

%show phase mapping overlay
nu=abs(artificialFourierUpsample(mean(RMD238_Sc21_HOT_RARE_Ni_t(1,1,:,:,:),3),1));
R=Rois();
R.loadRois(strcat(path,'ROIs\Figure 2\marrow region.roi'));
m=squeeze(R.getMasks());
m=round(abs(artificialFourierUpsample(m,0.5)));
rare_rgb=intensity2RGB(rare,gray);
nu_rgb=intensity2RGB(nu,jet,[985 1015]);
nu_overlay_=superpose2RGB(nu_rgb,rare_rgb,m);
figure,imagesc(nu_overlay_,[985 1015]);
% colorbar
axis image off
xlim([33 239]/2);
ylim([26 232]/2);
colormap jet
colorbar
set(gca,'FontSize',fs);
title('colorbar units are Hz','FontSize',fs)