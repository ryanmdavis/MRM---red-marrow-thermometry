%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


%% Load the csi data
getDirScanInfo('RMD238',[3 21]);

%% Change the recon matrix size for the CSI
csi_td=squeeze(RMD238_Sc21_HOT_RARE_Ni(1,:,1,:,:));
csi_td=artificialFourierUpsample(csi_td,0.25);
csi_td_fill=zeros(256,32,32);
csi_td_fill(1:16,:,:)=csi_td(1:16,:,:);
csi=fftshift(fft(fftshift(csi_td_fill,1),[],1),1);
csi=artificialFourierUpsample(csi,0.5);

%% Generate a CSI that can be displayed
[csi_x,csi_y]=displayCSIb(permute(abs(flipdim(csi,2)),[3 2 1]));

%% Generate the anatomical image
rare=squeeze(abs(RMD238_Sc3_rare(2,:,:)));
rare_small=squeeze(abs(RMD238_Sc3_rare(2,25:217,41:233)));

%% Display image
figure,imagesc(rare);
hold on
plot(csi_x'*256,256-csi_y'*256 - 8,'w');
colormap gray
axis image off
xlim([33 239]);
ylim([26 232]);