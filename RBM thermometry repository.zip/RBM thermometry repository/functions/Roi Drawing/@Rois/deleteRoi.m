%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


function obj = deleteRoi(obj,roi_num)
    obj.length = obj.length - 1;
    temp = Roi.empty(obj.length,0);
    temp(1:roi_num - 1) = obj.rois(1:roi_num - 1);
    if roi_num < max(size(obj.rois))
        temp(roi_num:obj.length) = obj.rois(roi_num + 1:obj.length + 1);
    end

    clear obj.rois;
    obj.rois = temp;
end