%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


function drawContour(obj,varargin)
invar = struct('axes_h',gca,'width',1,'color','b','style','-');
argin = varargin;
invar = generateArgin(invar,argin);
axes(invar.axes_h)
line(obj.col_points,obj.row_points,'linewidth',invar.width,'color',invar.color,'linestyle',invar.style);
if obj.isContourClosed
    num_pixels = size(obj.row_points,1);
    line([obj.col_points(1) obj.col_points(num_pixels)],[obj.row_points(1) obj.row_points(num_pixels)],'linewidth',invar.width,'color',invar.color,'linestyle',invar.style);
end