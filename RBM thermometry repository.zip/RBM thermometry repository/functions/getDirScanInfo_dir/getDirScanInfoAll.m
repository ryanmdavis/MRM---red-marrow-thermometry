%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


%'Method','ACQ_size','PVM_Nucleus1'

function getDirScanInfoAll(exp_name_full,varargin)
% default_fields = {'Method','Exp_type'};
% fields_cell = cat(2,default_fields,varargin);
fields = struct;

exp_name_full_nodot = rmDot(exp_name_full);

DATA_PATH = loadDataPath;
directory = searchForFolderInPath(DATA_PATH,exp_name_full);

% directory = strcat('C:\Users\Ryan2\Documents\Warren Lab Work\Bruker 7T Data\',exp_name_full,'\');
datasets = load(strcat('C:\Users\Ryan2\Documents\MATLAB\functions\getDirScanInfo_dir\files_data\',exp_name_full_nodot,'.mat'));
datasets_fields = fieldnames(datasets);

exp_name = findExpName(directory);
d = dir(directory);
for folder_num = 1:max(str2double({d.name}))
    if ~isempty(strmatch(strcat('s',num2str(folder_num)),datasets_fields,'exact'))
        if nargin == 2
            if ~isempty(strfind(datasets.(strcat('s',num2str(folder_num))){1},varargin{1}))
                display(datasets.(strcat('s',num2str(folder_num))){1});
            end
        else display(datasets.(strcat('s',num2str(folder_num))){1});
        end
    end
end

% save(strcat('C:\Users\Ryan\Documents\MATLAB\functions\getDirScanInfo_dir\files_data\',exp_name_full_nodot,'.mat'),'-struct','datasets');

function exp_name = findExpName(directory)
i = strfind(directory,'.');
last_dot_ind = i(end);
slash_ind = strfind(directory(1:last_dot_ind),'\');
last_slash_ind = slash_ind(end);
exp_name = directory(last_slash_ind+1:last_dot_ind-1);

function s = rmDot(exp_name_full)
i = strfind(exp_name_full,'.');
if ~isempty(i) s = exp_name_full(1:(i-1));
else s = exp_name_full;
end