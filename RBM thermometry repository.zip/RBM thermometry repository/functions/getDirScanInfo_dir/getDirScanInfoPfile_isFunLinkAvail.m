%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


function fun_link_text = getDirScanInfoPfile_isFunLinkAvail(directory,exp_name,file_name)

file_path = strcat(directory,file_name,'_header.txt');

if ~exist(file_path)
    rdgehdr_dos_cmd = strcat({'C:\Users\Ryan2\Downloads\rdgehdr\rdgehdr "'},strcat(directory,file_name),{'" > "'},strcat(file_path,'"'));
    dos(rdgehdr_dos_cmd{:});
end

fields = struct('Series_description',' ','User_variable_42',' ','User_variable_47',0,'User_variable_48',0,'yres',16);
fields = getGeHdrEntry(file_path,fields);
spect_flag=fields.User_variable_42;
tau=fields.User_variable_48;
tau_max=fields.User_variable_48;
opyres=fields.yres;

switch fields.Series_description
case {'HOT','hot'}
    if spect_flag==1
        start_to_exc_1 = {'<a href="matlab: '};
        expressions_to_exc_1 = {strcat('[',exp_name,'_s,',exp_name,'_td] = getDirScanInfo_reconSpectrumPfile(''',directory,file_name,''');')};
        end_to_exc_1 = {strcat({'">Scan '},exp_name,{' (Spectrum):</a>'},{'    '})};
        fun_link_text_cell = strcat(start_to_exc_1,expressions_to_exc_1{1},end_to_exc_1{1});
    else
        start_to_exc_2 = {'<a href="matlab: '};
        expressions_to_exc_2 = {strcat('[',exp_name,'_im,',exp_name,'_k,',exp_name,'_t] = getDirScanInfo_reconImagePfile(''',directory,file_name,''');')};
        end_to_exc_2 = {strcat({'">Scan '},exp_name,{' (Image):</a>'},{'    '})};
        fun_link_text_cell = strcat(start_to_exc_2,expressions_to_exc_2{1},end_to_exc_2{1});
    end
    fun_link_text = fun_link_text_cell{1};   
otherwise
    fun_link_text='';
end