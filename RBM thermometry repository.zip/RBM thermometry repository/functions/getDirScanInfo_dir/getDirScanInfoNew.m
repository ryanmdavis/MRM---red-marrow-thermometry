%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


%'Method','ACQ_size','PVM_Nucleus1'

function getDirScanInfoNew(exp_name_full,varargin)
default_fields = {'Method','Exp_type'};
fields_cell = cat(2,default_fields,varargin);
fields = struct;

exp_name_full_nodot = rmDot(exp_name_full);

DATA_PATH = loadDataPath;
directory = searchForFolderInPath(DATA_PATH,exp_name_full);

datasets = load(strcat('C:\Users\Ryan2\Documents\MATLAB\functions\getDirScanInfo_dir\files_data\',exp_name_full_nodot,'.mat'));
datasets_fields = fieldnames(datasets);

exp_name = findExpName(directory);

% for default_field_num = 1:size(default_fields,2)
%     fields.(default_fields{default_field_num}) = [];
% end

for field_num = 1:size(fields_cell,2)
    fields.(fields_cell{field_num}) = [];
end

d = dir(directory);
% datasets = struct;

folders_only(1) = d(1);
folder_only_index = 1;
folders_only_cell = {};
for d_field_num = 1:size(d,1)
    if d(d_field_num).isdir && exist([directory '\' d(d_field_num).name '\method'],'file') && exist([directory '\' d(d_field_num).name '\acqp'],'file')
        folders_only(folder_only_index) = d(d_field_num);
        folders_only_cell{folder_only_index} = strcat('s',d(d_field_num).name);
        folder_only_index = folder_only_index + 1;

    end
end

for folder_num = 1:max(str2double({d.name}))
    if isempty(strmatch(strcat('s',num2str(folder_num)),datasets_fields,'exact')) && ~isempty(strmatch(strcat('s',num2str(folder_num)),folders_only_cell','exact'))
        fields = getPVEntry3([directory '\' num2str(folder_num) '\acqp'],fields);
        fields = getPVEntry3([directory '\' num2str(folder_num) '\method'],fields);
        display_string = getDirScanInfo_isFunLinkAvail(directory,fields,num2str(folder_num),exp_name);
        if isempty(display_string)
            display_string = strcat('Scan',{' '},num2str(folder_num),{':    '});
        else
            display_string = strcat(display_string,{'    '});
        end
        for entry_num = 1:size(fields_cell,2)%%chagnge this to include default entries
            display_string = strcat(display_string,fields_cell{entry_num},{': '},num2str(fields.(fields_cell{entry_num})),{'    '});
        end
        datasets.(strcat('s',num2str(folder_num))) = display_string;
        display(display_string{1:end});
    end
end

save(strcat('C:\Users\Ryan2\Documents\MATLAB\functions\getDirScanInfo_dir\files_data\',exp_name_full_nodot,'.mat'),'-struct','datasets');

function exp_name = findExpName(directory)
i = strfind(directory,'.');
last_dot_ind = i(end);
slash_ind = strfind(directory(1:last_dot_ind),'\');
last_slash_ind = slash_ind(end);
exp_name = directory(last_slash_ind+1:last_dot_ind-1);

function s = rmDot(exp_name_full)
s = exp_name_full;
i = strfind(exp_name_full,'.');
if ~isempty(i)
    s = strcat(exp_name_full(1:(i-1)),'_',exp_name_full(i+1:end));
end