%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


function full_dir = getFullDirFromExpNum(exp_name,varargin)
if nargin == 2
    parent_directory = varargin{1};
else
    parent_directory = 'C:\Ryan MR Data\Data';
end
experiments = dir(parent_directory);
full_dir = '';
%%% Search through parent directory for exp_name and return full directory:
for exp_num = 1:size(experiments,1) 
    if strfind(experiments(exp_num).name,exp_name) full_dir = strcat(parent_directory,'\',experiments(exp_num).name,'\'); end
end