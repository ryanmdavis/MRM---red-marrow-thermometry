%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


function [spectra,kspace] = getDirScanInfo_HOTSLI(folder)

p_meth = struct('tau_inc',[]);
p_meth = getPVEntry3([folder '\method'],p_meth);

if p_meth.tau_inc == 1
    [spectra,kspace] = reconstructHOTSLI(folder,'recon_mat_size',256);
elseif p_meth.tau_inc == 2
    %%% the images returned by this are (window,coherence type,phase,read)
    %%% where coherence type is 1) f-w iZQC, 2) DC contamination
    [spectra,kspace] = reconstructHOT2DSLI(folder,'recon_mat_size',256);
    spectra_temp = spectra;
    spectra(:,1,:,:) = spectra_temp(:,1,:,:) - spectra_temp(:,2,:,:); %%f-w iZQC
    spectra(:,2,:,:) = spectra_temp(:,1,:,:) + spectra_temp(:,2,:,:); %%DC contamination image
end