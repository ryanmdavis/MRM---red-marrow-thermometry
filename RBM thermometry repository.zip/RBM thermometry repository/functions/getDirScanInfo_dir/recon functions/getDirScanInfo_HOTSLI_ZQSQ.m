%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  This function calls reconstructHOT2DSLI, which reconstructs the raw 
%  Bruker fid file into a 5D matrix = (repetitions, t1 delay, echo number,
%  phase encode step, read encode step).  The large if/elseif structure
%  (line 14) just formats or displays the data differently based on if the data is an
%  image, 2D spectrum, chemical shift image, etc...  The if statement
%  determines the type of experiment (spectrum/image) based on the size of
%  the kspace data returned from reconstructHOT2DSLI.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [images,kspace,temperature_data] = getDirScanInfo_HOTSLI_ZQSQ(directory)
recon_mat_size = 1024;
[images,kspace,hz1,hz2] = reconstructHOT2DSLI(directory);
p_m = struct('Exp_type',[],'t1',[],'tau_min',[],'tau_max',[]);
p_m = getPVEntry3([directory '\method'],p_m);
if size(kspace,2) > 4 && size(kspace,3) == 2 && size(kspace,4) == 1 %i.e. if I am trying to make an 2 window iMQC spectrum
    kspace = permute(squeeze(kspace),[2 1 3]);
    kspace(:,:,1) = 0;
    images = flipdim(flipdim(fftshift(fftshift(fft(fft(kspace,recon_mat_size,2),recon_mat_size,3),2),3),2),3);
    bw_f1 = max(hz1) - min(hz1);
    bw_f2 = max(hz2) - min(hz2);
    t_f1 = 0:(1/bw_f1):(size(kspace,2)/bw_f1);
    t_f2 = 0:(1/bw_f2):(size(kspace,3)/bw_f2);
    exp_name = findExpName(directory);
%     displayHot2DSpectraB(images,bw_f1,0,4000,bw_f2,0,4000);
%     set(gcf,'Name',exp_name);
%     displayHot2DFidsB(abs(kspace),max(t_f1)*1000,mean(t_f1)*1000,max(t_f1)*1000,max(t_f2)*1000,mean(t_f2)*1000,max(t_f2)*1000);
%     subplot(1,2,1);
%     title('abs - iZQC','FontSize',15);
%     subplot(1,2,2);
%     title('abs - SQC','FontSize',15);
%     set(gcf,'Name',exp_name);
    temperature_data = 0;
elseif size(kspace,2) > 4 && size(kspace,3) == 1
    kspace = squeeze(kspace);
    images = flipdim(flipdim(fftshift(fftn(kspace,[recon_mat_size recon_mat_size])),2),3);
    bw_f1 = max(hz1) - min(hz1);
    bw_f2 = max(hz2) - min(hz2);
    t_f1 = 0:(1/bw_f1):(size(kspace,1)/bw_f1);
    t_f2 = 0:(1/bw_f2):(size(kspace,2)/bw_f2);
    figure,subplot(1,2,1);
    display2DSpectrumB(images,bw_f1,0,4000,bw_f2,0,4000);
    set(gcf,'Name',strcat('images - ',directory));
    subplot(1,2,2);
    display2DFidsB(real(kspace),max(t_f1)*1000,mean(t_f1)*1000,max(t_f1)*1000,max(t_f2)*1000,mean(t_f2)*1000,max(t_f2)*1000);
    set(gcf,'Name',strcat('fids - ',directory));
    temperature_data = 0;
elseif size(kspace,2) == 3  && size(kspace,3) <= 2
    temperature_data = calcTemp3DelayCycleHOTSLIc(directory,kspace,'add_pi',pi,'gaussian_filter',[3 3],'recon_size',64);
elseif size(kspace,3) <= 2 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%this condition executes if doing a single ZQSQ image, no CSI, no
    %%multi-echo encoding
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    kspace(:,:,1,:,1)=0;
    kspace(:,:,1,16,:)=0;
    kspace=flipdim(kspace,5);
    kspace=makeKSpaceMatSquare(kspace);
    [max_row,max_col] = maxRowColIndex(squeeze(kspace(1,1,2,:,:)));
    f_surf_norm = reshape(makeFermiSurface([size(kspace,4) size(kspace,5)],[5 5],[1 1],[max_row max_col]),1,1,1,size(kspace,4),size(kspace,5));
    for delay_number = 1:size(kspace,2)
        for time_point = 1:size(kspace,1)
            kspace(time_point,delay_number,1,:,:) = kspace(time_point,delay_number,1,:,:).*f_surf_norm;
        end
    end
    kspace(:,:,1,:,:)=kspace(:,:,1,:,:);
    images = fftshift(fftshift(fft(fft(ifftshift(ifftshift(kspace,4),5),[],4),[],5),4),5);
    images = artificialFourierUpsample(images,4);
    [temperature_data,frequency_data] = imagesToTempNT(images,p_m.t1+p_m.tau_min,'dir',directory);
    
    temperature_data=frequency_data;
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% if we are making a multi echo 2D spectrum:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
elseif size(kspace,3) > 2 && size(kspace,4) == 1
    if strcmp(p_m.Exp_type,'HOT_2D_RARE_ZQSQ2 ')
       kspace = resortHOTRARE2windows(kspace);
    end
    num_echoes = size(kspace,3)/2;
    %dimensions are rep,delay,window,phase,read
%     kspace(1,1,1,1,1) = 0;
    kspace(:,:,:,:,1:2) = 0;
%     kspace(:,:,2:2:end,:,:) = conj(kspace(:,:,2:2:end,:,:));
        kspace(abs(kspace) > 2^19) = 0;
    kspace_unpadded = permute(kspace,[1 4 3 2 5]);
    kspace = zeroPadImage5D(kspace_unpadded,[recon_mat_size recon_mat_size]);
%     images = fftshift(fftshift(fft(fft(kspace,[],4),[],5),4),5);
    images = fftshift(fftshift(fft(fft(ifftshift(ifftshift(kspace,4),5),[],4),[],5),4),5);
    bw_f1 = max(hz1) - min(hz1);
    bw_f2 = max(hz2) - min(hz2);
    t_f1 = 0:(1/bw_f1):(size(kspace_unpadded,4)/bw_f1);
    t_f2 = 0:(1/bw_f2):(size(kspace_unpadded,5)/bw_f2);
    hz_f1 = -0.5*bw_f1:bw_f1/(size(kspace,4)-1):0.5*bw_f1;
    hz_f2 = -0.5*bw_f2:bw_f1/(size(kspace,5)-1):0.5*bw_f2;
    f_s = figure;
    f_k = figure;

    for echo_num = 0:size(kspace,3)/2-1
        figure(f_s)
        subplot(4,num_echoes/2,echo_num+1)
        imagesc(abs(squeeze(images(1,1,echo_num+1,:,:))))
        title(strcat('echo ',num2str(echo_num+1),' - iZQC - abs'),'FontSize',15)
        set(gca,'FontSize',15);
        axis square off
        subplot(4,num_echoes/2,echo_num+1+num_echoes)
        imagesc(abs(squeeze(images(1,1,echo_num+1+num_echoes,:,:))))
        title(strcat('echo ',num2str(echo_num+5),' - SQC'),'FontSize',15)
        set(gca,'FontSize',15);
        axis square off
        figure(f_k)
        subplot(4,num_echoes/2,echo_num+1)
        imagesc(imag(squeeze(kspace_unpadded(1,1,echo_num+1,:,:))));
        title(strcat('echo ',num2str(echo_num+1),' - iZQC - imag'),'FontSize',15)
        set(gca,'FontSize',15);
        axis square off
        subplot(4,num_echoes/2,echo_num+1+num_echoes)
        imagesc(abs(squeeze(kspace_unpadded(1,1,echo_num+1+num_echoes,:,:))));
        title(strcat('echo ',num2str(echo_num+5),' - SQC'),'FontSize',15)
        set(gca,'FontSize',15);
        axis square off
    end
    kspace = kspace_unpadded;
    temperature_data = 1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% If this is a multi-echo image (RARE)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
elseif strcmp(p_m.Exp_type,'HOT_2D_RARE_ZQSQ ') || strcmp(p_m.Exp_type,'HOT_2D_RARE_ZQSQ2 ')
    
    %if this is ZQSQ2 then put ZQ as the first N/2 windows and SQ as the
    %second N/2 windows:
    if strcmp(p_m.Exp_type,'HOT_2D_RARE_ZQSQ2 ')
       kspace = resortHOTRARE2windows(kspace);
    end
    kspace = gaussianFilterKspaceND(kspace,6,6,'recompute_k0','off','reference_image_5D',[1 1 2]);
    kspace_raw = kspace;
    kspace_pad = zeroPadImage5D(kspace,[recon_mat_size recon_mat_size]);
    images = fftshift(fftshift(fft(fft(ifftshift(ifftshift(kspace_pad,4),5),[],4),[],5),4),5);
    f_i = figure;
    f_k = figure;
%     max_iZQC = max(max(max(squeeze(abs(images(1,1,1:4,:,:))))));
%     max_SQC = max(max(max(squeeze(abs(images(1,1,5:8,:,:))))));
%     max_iZQC_k = max(max(max(squeeze(abs(kspace(1,1,1:4,:,:))))));
%     max_SQC_k = max(max(max(squeeze(abs(kspace(1,1,5:8,:,:))))));
    for echo_num = 0:size(images,3)-1
        figure(f_i);
        subplot(2,4,echo_num+1)
        imagesc(abs(squeeze(images(1,1,echo_num+1,:,:))));%,[0  15]);
        title(strcat('echo ',num2str(echo_num+1),' - iZQC'),'FontSize',15)
        set(gca,'FontSize',15);
        axis square off
%         subplot(2,4,echo_num+5)
%         imagesc(abs(squeeze(images(1,1,echo_num+5,:,:))));%,[0 15]);
%         title(strcat('echo ',num2str(echo_num+5),' - SQC'),'FontSize',15)
%         set(gca,'FontSize',15);
%         axis square off
        figure(f_k);
        subplot(2,4,echo_num+1)
        imagesc(abs(squeeze(kspace_raw(1,1,echo_num+1,:,:))));%,[0 max_iZQC_k]);
        title(strcat('echo ',num2str(echo_num+1),' - iZQC'),'FontSize',15)
        set(gca,'FontSize',15);
        axis square off
%         subplot(2,4,echo_num+5)
%         imagesc(abs(squeeze(kspace_raw(1,1,echo_num+5,:,:))));%,[0 max_SQC_k]);
%         title(strcat('echo ',num2str(echo_num+5),' - SQC'),'FontSize',15)
%         set(gca,'FontSize',15);
%         axis square off
    end
    temperature_data = 1;
end

function exp_name = findExpName(directory)
    ii = strfind(directory,'RMD');
    
    exp_name = directory(ii:end);
    