%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


function [im,k,t] = getDirScanInfo_reconImagePfile(directory)

[im,k,t] = reconGeHotTemp(directory,'shift',[0 0]);

figure
subplot(1,3,1);
imagesc(squeeze(abs(im(1,1,1,:,:))));
axis image off
title('Zero Quantum Window','FontSize',15);
subplot(1,3,2);
imagesc(squeeze(abs(im(1,1,2,:,:))))
axis image off
title('Spin Echo Window','FontSize',15);
subplot(1,3,3);
imagesc(squeeze(abs(t)),[20 45])
axis image off
title('Temperature','FontSize',15);
colorbar
pos=get(gcf,'OuterPosition');
scale_figure=2.5;
new_pos=[0 0 scale_figure*pos(3) pos(4)];
set(gcf,'OuterPosition',new_pos);