%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


function fun_link_text = getDirScanInfoGE_isFunLinkAvail(directory,scan_data,exp_num,exp_name)
switch scan_data.SeriesDescription
    case '3Plane Loc SSFSE'
        fun_link_text = [];
    case 'crazed'
        sub_d = dir(strcat(directory,exp_num));
        i = [];
        sub_d_index = 0;
        dicom_file_num = 1;
        dicom_file_locations = cell(1,4);
        while ((dicom_file_num <= 4) && (sub_d_index < size(sub_d,1)))
            sub_d_index = sub_d_index + 1;
            i = strfind(sub_d(sub_d_index).name,'.dcm');
            if ~isempty(i)
                dicom_file_locations{dicom_file_num} = strcat(directory,exp_num,'\',sub_d(sub_d_index).name);
                dicom_file_num = dicom_file_num + 1;
            end
        end
        if (dicom_file_num == 5)
            start_to_exc = {'<a href="matlab: '};
            mag_to_exec = {strcat(exp_num,'_m = dicomread(''',dicom_file_locations(1),''');')};
            phase_to_exec = {strcat(exp_num,'_p = dicomread(''',dicom_file_locations(2),''');')};
            real_to_exec = {strcat(exp_num,'_r = dicomread(''',dicom_file_locations(3),''');')};
            imag_to_exec = {strcat(exp_num,'_i = dicomread(''',dicom_file_locations(4),''');')};
            info_to_exec = {strcat(exp_num,'_info = dicominfo(''',dicom_file_locations(1),''');')};

            end_to_exc_mag = {strcat({'">m '},{'</a>'},{' '})};
            end_to_exc_phase = {strcat({'">p '},{'</a>'},{' '})};
            end_to_exc_real = {strcat({'">r '},{'</a>'},{' '})};
            end_to_exc_imag = {strcat({'">i '},{'</a>'},{' '})};
            end_to_exc_info = {strcat({'">info'},{'</a>'},{' '})};

            mag = strcat(start_to_exc{1},mag_to_exec{1},end_to_exc_mag{1});
            phase = strcat(start_to_exc{1},phase_to_exec{1},end_to_exc_phase{1});
            imag = strcat(start_to_exc{1},imag_to_exec{1},end_to_exc_imag{1});
            real = strcat(start_to_exc{1},real_to_exec{1},end_to_exc_real{1});
            info = strcat(start_to_exc{1},info_to_exec{1},end_to_exc_info{1});

            fun_link_text = strcat(mag{1},phase{1},real{1},imag{1},info{1});
        else
            fun_link_text = [];
        end
    otherwise
        fun_link_text = [];
end