%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


%%%this function is if time domain is last dimension

function varargout = displayCSIb(im)

spectral_bin_size = 2;

[csi_width,csi_length] = size(squeeze(im(:,:,1)));  %csi_width/length are the width of the csi image in voxels
max_spectrum_height = max(max(max(im)));

outer_margin = 0.05; %as a fraction of figure size; from 0 to 1
margin_btw_plots = 0.005;

subplot_square_side_length = (1 - 2 * outer_margin - csi_length * margin_btw_plots)/csi_length;

begin_spectrum_column = outer_margin + margin_btw_plots/2:margin_btw_plots + subplot_square_side_length:1 - outer_margin - margin_btw_plots/2;
begin_spectrum_row = begin_spectrum_column;

x_position = zeros(csi_length*csi_width,floor(size(im,3)/spectral_bin_size));
y_position = x_position;
try
for row_pixel_index = 1:csi_length %pixel indecies refer to the row(l
    for column_pixel_index = 1:csi_width    
        x_position(column_pixel_index + csi_width*(row_pixel_index - 1),:) = squeeze(abs(reshape(begin_spectrum_column(column_pixel_index):spectral_bin_size*subplot_square_side_length/size(im,3):begin_spectrum_column(column_pixel_index)+subplot_square_side_length*(size(im,3) - 1)/size(im,3),1,1,floor(size(im,3)/spectral_bin_size))));
%         y_position(column_pixel_index + csi_width*(row_pixel_index - 1),:) = abs(im(:,row_pixel_index,column_pixel_index))./(max_spectrum_height * csi_length) + begin_spectrum_row(row_pixel_index);
        intensity = im(column_pixel_index,row_pixel_index,:);
        binned_intensity = max(reshape(intensity,spectral_bin_size,size(im,3)/spectral_bin_size));
        y_position(column_pixel_index + csi_width*(row_pixel_index - 1),:) = squeeze(abs(binned_intensity))./(max_spectrum_height * csi_length) + begin_spectrum_row(row_pixel_index);
    end
end
catch
    keyboard;
end


varargout{1} = x_position;
varargout{2} = y_position;
if nargout == 3
    varargout{3} = begin_spectrum_column;
end