%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


function varargout = reconstructBruker1Db(file,varargin)

invar = struct('recon_mat_size',512);
argin = varargin;
invar = generateArgin(invar,argin);

fid=fopen([file '\fid'],'r','l'); %opens the data file
if fid == -1
    fid = fopen([file '\ser'],'r','l');
end

p_acqp = struct('ACQ_size',[]);
if exist([file '\acqp']) 
    p_acqp = struct('ACQ_size',[]);
    p_acqp = getPVEntry3([file '\acqp'],p_acqp);
    Npoint = max(p_acqp.ACQ_size)/2;
else exist([file '\acqus'])
    p_acqp = struct('TD',[]);
    p_acqp = getPVEntry3([file '\acqus'],p_acqp);
    Npoint = max(p_acqp.TD)/2;
end

recon_mat_size = max([invar.recon_mat_size Npoint]);

rawbuf=fread(fid,Npoint*2,'int32');  %reads data as a single line

fidmix=reshape(rawbuf,2,Npoint);    %reshapes the data in real and imaginary data

reall=fidmix(1,:);   %real is first Npoint points of data
imagg=fidmix(2,:);   %imag is second Npoint points of data

%Output plot of real and imaginary data (imaginary in red)
%figure; plot(real); hold on; plot(imag, '-r'); title(file);ylim([-6.2e4 6.2e5]);

fidcom=reall + 1i*imagg;   %Combines real and imaginary data
fidcom_abs = abs(fidcom);
spectrum_complex = zeros(size(fidcom,2),2);
spect = fftshift(fft(fftshift(fidcom),recon_mat_size));   %Fourier Transform of combined data
% spectrum_complex(:,1) = real(spect);
% spectrum_complex(:,2) = imag(spect);

%Output spectrum of combined data with x-axis
% figure;plot(dir_swaxis,spectrum); xlim([dir_swaxis(1) dir_swaxis(end)]);ylim([0 max(spectrum)]);title(file)
% set(gca,'XDir','reverse');  %Reverses the x-axis to match spectrometer (i.e., positive to negative from left to right)
fclose(fid);
varargout{1} = spect;
if nargout >= 2
    varargout{2} = fidcom;
end
if nargout ==3
    varargout{3} = spect;
end