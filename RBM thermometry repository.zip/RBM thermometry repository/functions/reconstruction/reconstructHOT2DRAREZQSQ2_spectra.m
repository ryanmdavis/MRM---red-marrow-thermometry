%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


function [spectra,td,t] = reconstructHOT2DRAREZQSQ2_spectra(directory)

recon_mat_size = [];

p_m = struct('Exp_type',[],'RARE_mode',[],'RARE_encoding_scheme',[]);
p_m = getPVEntry3([directory '\method'],p_m);

%read and order raw data.  ordering involves putting all zq windows into
%k(:,:,1-size/2,:,:) and all sq into k(:,:,size/2+1:end,:,:)
[spectra,td,hz1,hz2] = reconstructHOT2DSLI(directory);
% k = resortHOTRARE2windows(k);

%sort data so that phase encoding in in 4th dim and coherence order is in
%3rd dim
% keyboard;
td = resortHOTRARE2windows(td);

td(:,:,:,:,1) = 0;

%correct the complex conjugate nature of odd echoes
% td(:,:,1:2:end,:,:) = td(:,:,1:2:end,:,:);



spectra = fftshift(fftshift(fft(fft(ifftshift(ifftshift(td,2),5),recon_mat_size,2),recon_mat_size,5),2),5);
t=1;

function exp_dir =  getExpDirectory(directory)

ii = strfind(directory,'RMD');
ii_slash = strfind(directory(ii:end),'\');
exp_dir = directory(1:(ii+ii_slash(1) - 2));
