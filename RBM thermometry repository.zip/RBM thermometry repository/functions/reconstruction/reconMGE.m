%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


%Written by Ryan M Davis on 01/09/2014
%Reconstruction for MGE_bas ParaVision method

%input: 
%   directory is the parent directory that contains the method and fid
%   files
%output:
%   im is the complex image data, whith indecies (slice,echo
%   number,phase,read)
function varargout=reconMGE(directory)

fid=fopen([directory '\fid'],'r','l'); %opens the data file

%read in raw data and scan parameters
p_meth = struct('PVM_Fov',[],'PVM_Matrix',[],'PVM_NEchoImages',[],'PVM_SPackArrNSlices',[],'PVM_SPackArrPhase1Offset',[],'PVM_SpatDimEnum',[]);
p_meth = getPVEntry3([directory '\method'],p_meth);
raw=fread(fid,inf,'int32');  %reads data as a single line
raw_complex=raw(1:2:end)+1i*raw(2:2:end); clear raw

%calculate number of complex samples per view
if strcmp(p_meth.PVM_SpatDimEnum,'2D ') %%if 2D spatial encoding
    n_samples=size(raw_complex,1)/(p_meth.PVM_SPackArrNSlices*p_meth.PVM_NEchoImages*p_meth.PVM_Matrix(2));
    %sort the data into im(slice,echo,phase,read)
    k=reshape(raw_complex,n_samples,p_meth.PVM_NEchoImages,p_meth.PVM_SPackArrNSlices,p_meth.PVM_Matrix(2));clear raw_complex
    k=permute(k,[3 2 4 1]);
    k=makeKSpaceMatSquare(k); 
    im=fftshift(fftshift(ifft(ifft(fftshift(fftshift(k,3),4),[],3),[],4),3),4);
else %%if 3D spatial encoding
    n_samples=size(raw_complex,1)/(p_meth.PVM_Matrix(2)*p_meth.PVM_NEchoImages*p_meth.PVM_Matrix(3));
    k=reshape(raw_complex,n_samples,p_meth.PVM_NEchoImages,p_meth.PVM_Matrix(2),p_meth.PVM_Matrix(3));clear raw_complex
%     k=reshape(raw_complex,n_samples,p_meth.PVM_Matrix(2),p_meth.PVM_NEchoImages,p_meth.PVM_Matrix(3));
    k=permute(k,[4 2 3 1]);
    k=k(:,:,:,1:p_meth.PVM_Matrix(1));
    k=makeKSpaceMatSquare(k);
    im=fftshift(fftshift(fftshift(ifft(ifft(ifft(fftshift(fftshift(fftshift(k,3),4),1),[],3),[],4),[],1),3),4),1);
end
%shift data in case of a phase encode offset:
shift_pe_voxels=round(size(im,3)*p_meth.PVM_SPackArrPhase1Offset/p_meth.PVM_Fov(2));
im=circshift(im,[0 0 shift_pe_voxels 0]);

varargout{1}=im;
if nargout ==2
    varargout{2}=k;
end