%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


%%make i into a matrix with size = mat_size
%%%% works with 4D data, as long as last two dims are row and column

function i_out = zeroPadImageC(i,mat_size)

num_dim = max(size(size(i)));

i_out_size = size(i);
i_out_size(end-1) = mat_size(1);
i_out_size(end) = mat_size(2);

i_out = zeros(i_out_size);
row_start = (size(i_out,num_dim-1) - size(i,num_dim-1))/2 + 1;
col_start = (size(i_out,num_dim) - size(i,num_dim))/2 + 1;

if max(size(size(i_out)))==4
    i_out(:,:,row_start:row_start + size(i,num_dim-1) - 1,col_start:col_start + size(i,num_dim) - 1) = i;
elseif max(size(size(i_out)))==3
    i_out(:,row_start:row_start + size(i,num_dim-1) - 1,col_start:col_start + size(i,num_dim) - 1) = i;
elseif max(size(size(i_out)))==5
    i_out(:,:,:,row_start:row_start + size(i,num_dim-1) - 1,col_start:col_start + size(i,num_dim) - 1) = i;
end