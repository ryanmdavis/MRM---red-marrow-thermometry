%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


function phase_correction = phaseWrapCorrHotImage(freq_est,phase_img_tot,evolution_time)

if max(size(size(phase_img_tot))) == 2
    phase_img_tot=reshape(phase_img_tot,[1 size(phase_img_tot)]);
end
if (max(size(size(phase_img_tot))) == 3)|(max(size(size(phase_img_tot))) == 2)
    phase_correction = zeros(size(phase_img_tot));
    for time_point = 1:size(phase_img_tot,1)
        for row = 1:size(phase_img_tot,2)
            for col = 1:size(phase_img_tot,3)
                phase_correction(time_point,row,col) = phaseWrapCorrHot(freq_est,phase_img_tot(time_point,row,col),evolution_time);
            end
        end
    end
elseif max(size(size(phase_img_tot))) == 4
    phase_correction = zeros(size(phase_img_tot));
    for time_point = 1:size(phase_img_tot,1)
        for delay_number=1:size(phase_img_tot,2)
            for row = 1:size(phase_img_tot,3)
                for col = 1:size(phase_img_tot,4)
                    phase_correction(time_point,delay_number,row,col) = phaseWrapCorrHot(freq_est,phase_img_tot(time_point,delay_number,row,col),evolution_time);
                end
            end
        end
    end
elseif max(size(size(phase_img_tot))) == 5
    phase_correction = zeros(size(phase_img_tot));
    for time_point = 1:size(phase_img_tot,1)
        for delay_number=1:size(phase_img_tot,2)
            for echo_number=1:size(phase_img_tot,3)
                for row = 1:size(phase_img_tot,4)
                    for col = 1:size(phase_img_tot,5)
                        phase_correction(time_point,delay_number,echo_number,row,col) = phaseWrapCorrHot(freq_est,phase_img_tot(time_point,delay_number,echo_number,row,col),evolution_time);
                    end
                end
            end
        end
    end
else
    error('input must be 3D: (time,row,column)');
end


% phase_correction=squeeze(phase_correction);