%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


function [masks_return,ir_return] = makeRadialMasksC(center_row,center_col,r_inc,r_max,im_size,r_init,tumor_mask)  %ir is inner radius

rows = zeros(im_size);
cols = zeros(im_size);

for row = 1:im_size(1)
    rows(row,:) = row;
end
for col = 1:im_size(2)
    cols(:,col) = col;
end

rows = rows - center_row;
cols = cols - center_col;

distance_to_center = (rows.^2 + cols.^2).^.5;

radii_values = r_init:r_inc:r_max;
circles = zeros(size(radii_values,2),im_size(1),im_size(2));

for circ_num = 1:size(radii_values,2)
    circles(circ_num,:,:) = double(distance_to_center < radii_values(circ_num));
end
masks = zeros(size(circles,1)-1,size(circles,2),size(circles,3));    
for mask_num = size(radii_values,2)-1:-1:1
    masks(mask_num,:,:) = circles(mask_num+1,:,:) - circles(mask_num,:,:);
end

index = 1;

while index < size(masks,1) && sum(sum(tumor_mask.*squeeze(masks(index,:,:)))) ~= 0
    masks(index,:,:) = reshape(tumor_mask.*squeeze(masks(index,:,:)),1,im_size(1),im_size(2));
    index = index + 1;
end

masks_return = masks(1:index-1,:,:);
ir_return = radii_values(1:index-1);