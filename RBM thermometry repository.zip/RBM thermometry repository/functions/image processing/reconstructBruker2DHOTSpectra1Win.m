%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


function varargout = reconstructBruker2DHOTSpectra1Win(folder)

zero_fill_factor_f1 = 8;
zero_fill_factor_f2 = 8;
omit_initial_samples = 15; %somtimes there is a spike at the beginning of the acquisition, and this helps remove it.

% BRUKER_FILE='C:\Users\Ryan\Documents\Duke Work\Bruker 7T data\RMD11\17\fid';  %This is the FID (or SER) file from the spectrometer

%*************************************************************************
p_acqp = struct('ACQ_size',[],'SW_h',[],'NR',[]);
p_acqp = getPVEntry3([folder '\acqp'],p_acqp);
p_meth = struct('tau_inc',[],'tau_min',[],'tau_max',[]);
p_meth = getPVEntry3([folder '\method'],p_meth);
num_fid = p_meth.tau_inc;
spectral_width = p_acqp.SW_h;
num_windows = 1;

acq_time = (p_meth.tau_max - p_meth.tau_min)/1000;
spectral_resolution = 1/(acq_time*zero_fill_factor_f1);
spectral_width_f1 = (p_meth.tau_inc* zero_fill_factor_f1 - 1)*spectral_resolution;
%calculate spectral res & width


fid=fopen([folder '\fid'],'r','l'); %opens the data file
if fid == -1
    fid=fopen([folder '\ser'],'r','l'); %opens the data file
end
rawbuf=fread(fid,inf,'int32');  %reads data as a single line
num_samples_actual = size(rawbuf,1)/(num_fid*num_windows);
num_samples_nominal = p_acqp.ACQ_size(1);
samples_buffered = num_samples_actual - num_samples_nominal;
fids = zeros(num_windows*num_fid,zero_fill_factor_f2*num_samples_nominal/2);
spectra = zeros(num_windows,zero_fill_factor_f1*p_meth.tau_inc,zero_fill_factor_f2*num_samples_nominal/2);

dir_fres=spectral_width/(zero_fill_factor_f2*num_samples_nominal/2-1);               
hz_f2 = (-.5*spectral_width):dir_fres:(.5*spectral_width);
hz_f1 = (-.5*spectral_width_f1):spectral_resolution:(.5*spectral_width_f1);
hz_f1_cell = cell(1,size(hz_f1,2));
hz_f2_cell = cell(1,size(hz_f2,2));

for ii = 1:size(hz_f1,2)
    hz_f1_cell{ii} = hz_f1(ii);
end

for ii = 1:size(hz_f2,2)
    hz_f2_cell{ii} = hz_f2(ii);
end

for fid_num = 1:num_fid*num_windows
%     for window_num = 1:num_windows
        fid_start = (fid_num-1) * num_samples_actual + 1;
        fid_this = rawbuf(fid_start:fid_start + num_samples_nominal - 1);

        fidmix=reshape(fid_this,2,num_samples_nominal/2);    %reshapes the data in real and imaginary data

        re=fidmix(1,:);   %real is first Npoint points of data
        im=fidmix(2,:);   %imag is second Npoint points of data

        fidcom=re + i*im;   %Combines real and imaginary data
    %     fidcom_abs = abs(fidcom);

        fids(fid_num,omit_initial_samples:num_samples_nominal/2) = fidcom(omit_initial_samples:num_samples_nominal/2);   %Fourier Transform of combined data
%     end
end
clear rawbuff
fids_sorted = zeros(num_windows,zero_fill_factor_f1*size(fids,1)/num_windows,size(fids,2));
for window_num = 1:num_windows
    fids_sorted(window_num,1:size(fids,1)/num_windows,:) = reshape(fids(window_num:num_windows:end,:),1,size(fids,1)/num_windows,size(fids_sorted,3));
    fids_sorted(abs(fids_sorted) > 1e6) = 0;
%     temp = zeros(size(fids_sorted,1),zero_fill_factor_f1*size(fids_sorted,2),size(fids_sorted,3));
%     temp(:,1:size(fids_sorted,2),:) = fids_sorted;
%     fids_sorted = temp;
    spectra(window_num,:,:) = reshape(flipud(fftshift(fft2(reshape(fids_sorted(window_num,:,:),size(fids_sorted,2),size(fids_sorted,3))))),1,size(fids_sorted,2),size(fids_sorted,3));
end
varargout{1} = squeeze(spectra);
if nargout>=2
%     varargout{2} = hz_f1_cell;
    varargout{2} = fids;
    if nargout>=3
%         varargout{3} = hz_f2_cell;
        varargout{3} = hz_f1;
        if nargout>=4
            varargout{4} = hz_f2;
        end
    end
end
