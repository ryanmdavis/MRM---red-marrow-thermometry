%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


%%%this function makes a centered gaussian, then circshifts it to overlap
%%%with the frequency data
%%%k_space_center is the center of kspase that this gaussian will filter.
%%%The function shifts the gaussian to overlap with the center of kspace
%%%kT is a 1x2 giving the kT of row and column
%%%Ef is the fermi energy, in this case it is the row/col where the function
%%%begins to "activate". 1x2 vector.  Also, Ef is referenced to the center
%%%of 

function f_surf_norm = makeFermiSurface(mat_size,Ef,kT,center)

rows = zeros(mat_size);
cols = zeros(mat_size);

for row = 1:mat_size(1)
    rows(row,:) = row;
end
for col = 1:mat_size(2)
    cols(:,col) = col;
end

rows = abs(rows - center(1)) - Ef(1);
cols = abs(cols - center(2)) - Ef(2);

fermi_row = 1./(exp(rows/kT(1)) + 1);
fermi_col = 1./(exp(cols/kT(2)) + 1);

f_surf_norm = fermi_row.*fermi_col;

