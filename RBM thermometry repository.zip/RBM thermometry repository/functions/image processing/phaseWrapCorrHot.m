%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


function phase_correction = phaseWrapCorrHot(freq_est,total_phase_wrapped,evolution_time)

corr_values = -4*pi:2*pi:20*pi;
corr_freqs = (total_phase_wrapped + corr_values)/(2*pi*evolution_time);
diff_abs = abs(freq_est - corr_freqs);
[y,corr_num] = min(diff_abs);
phase_correction = corr_values(corr_num);