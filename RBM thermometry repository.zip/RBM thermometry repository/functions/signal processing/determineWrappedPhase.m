%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


%%%freq_est in kHz, tau values in ms
%%%this function attempts to estimate when the phase of a fat-water iZQC
%%%will wrap, given an estimation of the frequency (freq_est).  The
%%%estimation of the number of phase wraps is given for each tau_value that
%%%is passed in the variable (tau_values)
function wrapped_phase = determineWrappedPhase(freq_est,tau_values)

period_est = 1/abs(freq_est);
phase_wrap_times = (period_est:period_est:(max(tau_values) + 2*period_est)) - period_est/2;
wrapped_phase = zeros(size(tau_values));
for i = 1:size(tau_values,2)
    wrap_minus_tau = phase_wrap_times - tau_values(i);
    wrap_minus_tau(wrap_minus_tau > 0) = -inf;
    [y,num_wraps] = max(wrap_minus_tau);
    wrapped_phase(i) = sign(freq_est)*(2*pi*(num_wraps - 1));  
end