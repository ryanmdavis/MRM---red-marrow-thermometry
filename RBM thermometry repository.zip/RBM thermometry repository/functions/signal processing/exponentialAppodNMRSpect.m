%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


%%Line broadening for NMR spectra:
%%spectral_width is the spectral width of the aqcuired NMR spectrum, in hertz
%%linewidth is the linewidth of broadening (appodization with an
%%exponential with argument -1/T2 in the time domain is mathematically equivalent to
%%convolution with a lorentzian with linewitdh = 1/(pi*linewidth) in frequency domain)



function spectrum_appod = exponentialAppodNMRSpect(spectrum,spectral_width,linewidth)

fid = fliplr(fftshift(fft(fftshift(spectrum))));
t2 = 1/(pi*linewidth);
time_between_samples = 1/spectral_width;
appodizationFunction = @(t) exp(-t/t2);

spectrum_appod = zeros(size(spectrum));
fid_appod = zeros(size(spectrum));
for sample_num = 1:max(size(spectrum))
    fid_appod(sample_num) = fid(sample_num) * appodizationFunction((sample_num - 1) * time_between_samples);
end
spectrum_appod = fliplr(fftshift(ifft(fftshift(fid_appod))));