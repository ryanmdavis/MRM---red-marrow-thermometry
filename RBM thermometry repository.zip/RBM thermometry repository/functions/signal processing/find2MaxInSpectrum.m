%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function was originally downloaded from:
% https://github.com/ryanmdavis/MRM---red-marrow-thermometry
%
% This function is used during data recon/processing of the
% following manuscript:
%
% Davis RM, Warren WS.  Intermolecular zero quantum coherences enable 
% accurate temperature imaging in red bone marrow. Magnetic Resonance in
% Medicine 2014.  Issue and page numbers TBD
%
% Ryan M Davis.             rmd12@duke.edu                       06/30/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


function [hz1,hz2] = find2MaxInSpectrum(spectrum,range1,range2,varargin) %optional variable is hz bins

[y,i_s1_max] = max(spectrum(range1(1):range1(end)));
[y,i_s2_max] = max(spectrum(range2(1):range2(end)));

i_s1_max=i_s1_max+range1(1)-1;
i_s2_max=i_s2_max+range2(1)-1;

if nargin == 4
    hz=varargin{1};
    hz1=hz(i_s1_max);
    hz2=hz(i_s2_max);
else
    hz1=i_s1_max;
    hz2=i_s2_max;
end